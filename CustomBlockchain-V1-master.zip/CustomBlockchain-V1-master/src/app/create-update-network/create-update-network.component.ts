import { faPlus } from '@fortawesome/free-solid-svg-icons';
import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { FormBuilder, FormGroup, Validators ,FormsModule} from '@angular/forms';
import { HttpClient ,HttpHeaders } from '@angular/common/http';
import { NgbModalConfig, NgbModal } from '@ng-bootstrap/ng-bootstrap';

import * as $ from 'jquery';

@Component({
  selector: 'app-create-update-network',
  templateUrl: './create-update-network.component.html',
  styleUrls: ['./create-update-network.component.css'],
  providers: [NgbModalConfig, NgbModal,FormsModule],
  encapsulation: ViewEncapsulation.None
})


export class CreateUpdateNetworkComponent implements OnInit {
  faPlus = faPlus;

  // appendedHtml: string = '<div class="alert alert-success" role="alert"><strong>Success !!</strong> You successfully read this important alert message.</div>';

  // convenience getter for easy access to form fields
  get f() { return this.registerFormForGenerateCertificate.controls; }

  title = 'BlockchainFramework';

  registerFormForGenerateCertificate: FormGroup;

  submitted = false;

  // table varibales
  containers ;
  isShowTable = true;
  isOkModal = true;
  isSpinner = true;
  isSpinnerModal = false;

  constructor(private formBuilder: FormBuilder,private http: HttpClient, config: NgbModalConfig, private modalService: NgbModal) {

    // customize default values of modals used by this component tree
    config.backdrop = 'static';
    config.keyboard = false;

    this.registerFormForGenerateCertificate = this.formBuilder.group({
      // ordererName: ['', Validators.required],
      // domainName: ['', Validators.required],
      // hostName: ['', Validators.required],
      // peerName: ['', Validators.required],
      // peerdomainName: ['', Validators.required],
      // userscount: ['', Validators.required],
      // channelName: ['', Validators.required]

      hostName: ['', Validators.required],
      ordererName: ['', Validators.required],
      ordererportNo: ['', Validators.required],
      orgName_org1: ['', Validators.required],
      mspId_org1: ['', Validators.required],
      caName_org1: ['', Validators.required],
      caPortNo_org1: ['', Validators.required],
      peerName_org1: ['', Validators.required],
      peerPortNo_org1: ['', Validators.required],

    });

  }

  openModal(content) {
    this.modalService.open(content);
    // setTimeout(function () {
    //   $(".modal-body").append('<div class="alert alert-success" role="alert"><strong>Success !!</strong> You successfully read this important alert message.</div>');
    // }, 3000);
  }

  ngOnInit() {
   //this.systemCheck();
  }

  delay(ms: number) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  onReset() {
    this.submitted = false;
    this.registerFormForGenerateCertificate.reset();
  }

 systemCheck() {
  this.http.post('/systemCheck', {}).subscribe(
    data => {
      console.log("POST Request is successful ", data);
      let rec = JSON.parse(JSON.stringify(data))
      alert(rec.stdout);
    },
    error => {
      console.log("Error", error);
      alert("Error"+ error);
    }
  );
}

  // Create orderer using user data
  async onSubmitGenerateCertificate() {
    
    

    this.submitted = true;

    // stop here if form is invalid
    if (this.registerFormForGenerateCertificate.invalid) {
      return;
    }

    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    };

    $("#openModal").click();

    let OrdererObjectUserData = this.registerFormForGenerateCertificate.value;

    // template orderer orgnaization.
    let OrdererObject = {
      "OrdererOrgs": [
        {
          "Name": OrdererObjectUserData.ordererName,
          "Domain": OrdererObjectUserData.domainName,
          "Specs": [
            {
              "Hostname": OrdererObjectUserData.hostName
            }
          ]
        }
      ]
    }

    this.http.post('/network/CreateOrderer', { OrdererObject })

      .subscribe(
        data => {
          console.log("POST Request is successful ", data);
         // $(".modal-body").append('<div class="alert alert-success" role="alert"><strong>Success !!</strong> ' + JSON.stringify(data) + '</div>');
          // alert(JSON.stringify(data));
        },
        error => {
          console.log("Error", error);
          alert(JSON.stringify(error));
        }
      );

    await this.delay(2000);

    let peersObject = {
      "PeerOrgs": [
        {
          "Name": OrdererObjectUserData.peerName,
          "Domain": OrdererObjectUserData.peerdomainName,
          "EnableNodeOUs": true,
          "Template": {
            "Count": 1
          },
          "Users": {
            "Count": +(OrdererObjectUserData.userscount)
          }
        }
      ]
    }

    this.http.post('/network/CreatePeers', { peersObject }).subscribe(
      data => {
        console.log("POST Request is successful ", data);
        //$(".modal-body").append('<div class="alert alert-success" role="alert"><strong>Success !!</strong> ' + JSON.stringify(data) + '</div>');
        // alert(JSON.stringify(data));
      },
      error => {
        console.log("Error", error);
        alert(JSON.stringify(error));
      }
    );


    await this.delay(2000);

    let configtxObject = {

      "Organizations": [
        {
          "Name": OrdererObjectUserData.ordererName + "Org",
          "ID": OrdererObjectUserData.ordererName + "MSP",
          "MSPDir": "crypto-config/ordererOrganizations/" + OrdererObjectUserData.domainName + "/msp"
        },
        {
          "Name": OrdererObjectUserData.peerName + "MSP",
          "ID": OrdererObjectUserData.peerName + "MSP",
          "MSPDir": "crypto-config/peerOrganizations/" + OrdererObjectUserData.peerdomainName + "/msp",
          "AnchorPeers": [
            {
              "Host": "peer0." + OrdererObjectUserData.peerdomainName,
              "Port": 7051
            }
          ]
        }
      ],
      "Capabilities": {
        "Channel": {
          "V2_0": true
        },
        "Orderer": {
          "V2_0": true
        },
        "Application": {
          "V2_0": true
        }
      },
      "Application": {
        "Organizations": null,
        "Capabilities": {
          "V2_0": true
        }
      },
      "Orderer": {
        "OrdererType": "solo",
        "Addresses": [
          "orderer." + OrdererObjectUserData.domainName + ":7050"
        ],
        "BatchTimeout": "2s",
        "BatchSize": {
          "MaxMessageCount": 10,
          "AbsoluteMaxBytes": "99 MB",
          "PreferredMaxBytes": "512 KB"
        },
        "Organizations": null
      },
      "Channel": {
        "Capabilities": {
          "V2_0": true
        }
      },
      "Profiles": {
        "OneOrgOrdererGenesis": {
          "Capabilities": {
            "V2_0": true
          },
          "Orderer": {
            "OrdererType": "solo",
            "Addresses": [
              "orderer." + OrdererObjectUserData.domainName + ":7050"
            ],
            "BatchTimeout": "2s",
            "BatchSize": {
              "MaxMessageCount": 10,
              "AbsoluteMaxBytes": "99 MB",
              "PreferredMaxBytes": "512 KB"
            },
            "Organizations": [
              {
                "Name": OrdererObjectUserData.ordererName + "Org",
                "ID": OrdererObjectUserData.ordererName + "MSP",
                "MSPDir": "crypto-config/ordererOrganizations/" + OrdererObjectUserData.domainName + "/msp"
              }
            ],
            "Capabilities": {
              "V2_0": true
            }
          },
          "Consortiums": {
            "SampleConsortium": {
              "Organizations": [
                {
                  "Name": OrdererObjectUserData.peerName + "MSP",
                  "ID": OrdererObjectUserData.peerName + "MSP",
                  "MSPDir": "crypto-config/peerOrganizations/" + OrdererObjectUserData.peerdomainName + "/msp",
                  "AnchorPeers": [
                    {
                      "Host": "peer0." + OrdererObjectUserData.peerdomainName + "",
                      "Port": 7051
                    }
                  ]
                }
              ]
            }
          }
        },
        "OneOrgChannel": {
          "Consortium": "SampleConsortium",
          "Capabilities": {
            "V2_0": true
          },
          "Application": {
            "Organizations": [
              {
                "Name": OrdererObjectUserData.peerName + "MSP",
                "ID": OrdererObjectUserData.peerName + "MSP",
                "MSPDir": "crypto-config/peerOrganizations/" + OrdererObjectUserData.peerdomainName + "/msp",
                "AnchorPeers": [
                  {
                    "Host": "peer0." + OrdererObjectUserData.peerdomainName,
                    "Port": 7051
                  }
                ]
              }
            ],
            "Capabilities": {
              "V2_0": true
            }
          }
        }
      }
    }

    this.http.post('/network/CreateConfigTx', { configtxObject }).subscribe(
      data => {
        console.log("POST Request is successful ", data);
        $(".modal-body").append('<div class="alert alert-success" role="alert"><strong>Success !!</strong> network configuration files created.</div>');
        // alert(JSON.stringify(data));
      },
      error => {
        console.log("Error", error);
        alert(JSON.stringify(error));
      }
    );

    await this.delay(2000);

    let channelName = OrdererObjectUserData.channelName;

    this.http.post('/network/GenerateCertificate', { channelName }).subscribe(
      data => {
        console.log("POST Request is successful ", data);
        let result = JSON.parse(JSON.stringify(data));
        if (result.success == true)
          $(".modal-body").append('<div class="alert alert-success" role="alert"><strong>Success !!</strong> Successfully certificates generated for orderer and peers.</div>');
        // alert(JSON.stringify(data));
      },
      error => {
        console.log("Error", error);
        alert(JSON.stringify(error));
      }
    );

    await this.delay(2000);

    // create docker compose file
    let CA_Object = this.CreateCATemplate();
    let Orderer_Object = this.CreateOrdererTemplate();
    let CouchDB_Object = this.CreatCouchDBTemplete();
    let Peer_Object = this.CreatePeerTemplate();

    let data = {
      "CA_Object": CA_Object,
      "Orderer_Object": Orderer_Object,
      "CouchDB_Object": CouchDB_Object,
      "Peer_Object": Peer_Object
    }

    this.http.post('/network/CreateDockerComposeYAML', { data }).subscribe(
      data => {
        console.log("POST Request is successful ", data);
        let result = JSON.parse(JSON.stringify(data));
      //  if (result.success == true)
        //  $(".modal-body").append('<div class="alert alert-success" role="alert"><strong>Success !! </strong>Successfully created docker-copmose.yaml.</div>');
        // alert(JSON.stringify(data));
      },
      error => {
        console.log("Error", error);
        alert(JSON.stringify(error));
      }
    );

   await this.delay(2000);

    let BringUPNetworkObjData = {}

    this.http.post('/network/BringUPNetwork', { BringUPNetworkObjData }).subscribe(
      data => {
        console.log("POST Request is successful ", data);
        let result = JSON.parse(JSON.stringify(data));
        if (result.success == true)
          $(".modal-body").append('<div class="alert alert-success" role="alert"><strong>Success !! Network is up </strong>Docker containers created.</div>');
          this.isOkModal = false;
          this.isSpinnerModal = true;
        // alert(JSON.stringify(data));
      },
      error => {
        console.log("Error", error);
        alert(JSON.stringify(error));
      }
    );

   await this.delay(5000);

   //this.RefreshAndShowContainersStatus();

  }

  

  // create ca templete for docker-compose.yaml
   CreateCATemplate () : any {

    let data = {
      "version": '2',
      "networks": {
        "basic": null
      },
      "services": {
        "ca.example.com": {
          "image": "hyperledger/fabric-ca",
          "environment": [
            "FABRIC_CA_HOME=/etc/hyperledger/fabric-ca-server",
            "FABRIC_CA_SERVER_CA_NAME=ca.example.com",
            "FABRIC_CA_SERVER_CA_CERTFILE=/etc/hyperledger/fabric-ca-server-config/ca.org1.example.com-cert.pem",
            "FABRIC_CA_SERVER_CA_KEYFILE=/etc/hyperledger/fabric-ca-server-config/${CA1_PRIVATE_KEY}"
          ],
          "ports": [
            "7054:7054"
          ],
          "command": "sh -c 'fabric-ca-server start -b admin:adminpw'",
          "volumes": [
            "./crypto-config/peerOrganizations/org1.example.com/ca/:/etc/hyperledger/fabric-ca-server-config"
          ],
          "container_name": "ca.example.com",
          "networks": [
            "basic"
          ]
        }
      }
    }

    return data;
  }

  // create orderer templete for docker-compose.yaml
  CreateOrdererTemplate() {

    let data = {
      "version": '2',
      "networks": {
        "basic": null
      },
      "services": {
        "orderer.example.com": {
          "container_name": "orderer.example.com",
          "image": "hyperledger/fabric-orderer",
          "environment": [
            "FABRIC_LOGGING_SPEC=info",
            "ORDERER_GENERAL_LISTENADDRESS=0.0.0.0",
            "ORDERER_GENERAL_BOOTSTRAPMETHOD=file",
            "ORDERER_GENERAL_BOOTSTRAPFILE=/etc/hyperledger/configtx/genesis.block",
            "ORDERER_GENERAL_LOCALMSPID=OrdererMSP",
            "ORDERER_GENERAL_LOCALMSPDIR=/etc/hyperledger/msp/orderer/msp"
          ],
          "working_dir": "/opt/gopath/src/github.com/hyperledger/fabric/orderer",
          "command": "orderer",
          "ports": [
            "7050:7050"
          ],
          "volumes": [
            "./config/:/etc/hyperledger/configtx",
            "./crypto-config/ordererOrganizations/example.com/orderers/orderer.example.com/:/etc/hyperledger/msp/orderer",
            "./crypto-config/peerOrganizations/org1.example.com/peers/peer0.org1.example.com/:/etc/hyperledger/msp/peerOrg1"
          ],
          "networks": [
            "basic"
          ]
        }
      }
    }

    return data;
  }

  // create couchdb templete for docker-compose.yaml
  CreatCouchDBTemplete() {

    let data = {
      "version": '2',
      "networks": {
        "basic": null
      },
      "services": {
        "couchdb": {
          "container_name": "couchdb",
          "image": "couchdb:2.3",
          "environment": [
            "COUCHDB_USER=",
            "COUCHDB_PASSWORD="
          ],
          "ports": [
            "5984:5984"
          ],
          "networks": [
            "basic"
          ]
        }
      }
    }

    return data;
  }

  // create peer templete for docker-compose.yaml
  CreatePeerTemplate() {

    let data = {
      "version": '2',
      "networks": {
        "basic": null
      },
      "services": {
        "peer0.org1.example.com": {
          "container_name": "peer0.org1.example.com",
          "image": "hyperledger/fabric-peer",
          "environment": [
            "CORE_VM_ENDPOINT=unix:///host/var/run/docker.sock",
            "CORE_PEER_ID=peer0.org1.example.com",
            "FABRIC_LOGGING_SPEC=info",
            "CORE_CHAINCODE_LOGGING_LEVEL=info",
            "CORE_PEER_LOCALMSPID=Org1MSP",
            "CORE_PEER_MSPCONFIGPATH=/etc/hyperledger/msp/peer/",
            "CORE_PEER_ADDRESS=peer0.org1.example.com:7051",
            "CORE_VM_DOCKER_HOSTCONFIG_NETWORKMODE=net_basic",
            "CORE_LEDGER_STATE_STATEDATABASE=CouchDB",
            "CORE_LEDGER_STATE_COUCHDBCONFIG_COUCHDBADDRESS=couchdb:5984",
            "CORE_LEDGER_STATE_COUCHDBCONFIG_USERNAME=",
            "CORE_LEDGER_STATE_COUCHDBCONFIG_PASSWORD="
          ],
          "working_dir": "/opt/gopath/src/github.com/hyperledger/fabric",
          "command": "peer node start",
          "ports": [
            "7051:7051",
            "7053:7053"
          ],
          "volumes": [
            "/var/run/:/host/var/run/",
            "./crypto-config/peerOrganizations/org1.example.com/peers/peer0.org1.example.com/msp:/etc/hyperledger/msp/peer",
            "./crypto-config/peerOrganizations/org1.example.com/users:/etc/hyperledger/msp/users",
            "./config:/etc/hyperledger/configtx"
          ],
          "networks": [
            "basic"
          ]
        }
      }
    }
    return data;
    //export CA1_PRIVATE_KEY=$(cd crypto-config/peerOrganizations/org1.example.com/ca && ls *_sk)

  }




}
