import { Component, OnInit, ElementRef } from '@angular/core';
import SwaggerUI from 'swagger-ui';

@Component({
  selector: 'app-custom-swagger-api',
  templateUrl: './custom-swagger-api.component.html',
  styleUrls: ['./custom-swagger-api.component.css']
})
export class CustomSwaggerApiComponent implements OnInit {

  constructor(private el: ElementRef) { }

  ngOnInit() {
    const ui = SwaggerUI({
      url: 'http://petstore.swagger.io/v2/swagger.json',
      domNode: this.el.nativeElement.querySelector('.swagger-container'),
      deepLinking: true,
      presets: [
        SwaggerUI.presets.apis
      ],
    });
  }

}
