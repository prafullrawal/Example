import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { HttpHeaders } from '@angular/common/http';
import { NgbModalConfig, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import * as $ from 'jquery';


interface Containers {
  CONTAINER_ID: string;
  NAMES: string;
  IMAGE: string;
  STATUS: string;
  PORTS: string;
}

@Component({
  selector: 'app-docker-container-logs',
  templateUrl: './docker-container-logs.component.html',
  styleUrls: ['./docker-container-logs.component.css'],
  providers: [NgbModalConfig, NgbModal],
})
export class DockerContainerLogsComponent implements OnInit {

  containers;
  isShowTable = true;
  isOkModal = true;
  isSpinner = true;
  isSpinnerModal = false;

  
  constructor(private http: HttpClient, config: NgbModalConfig, private modalService: NgbModal ) {
    // customize default values of modals used by this component tree
    config.backdrop = 'static';
    config.keyboard = false;
    
}

  ngOnInit() {
  }

  RefreshAndShowContainersStatus(){

    // showing table
    this.isShowTable = false;
    this.isSpinner = false;

    this.http.post('/RefreshAndShowContainersStatus', null).subscribe(
      data => {
        let table = JSON.parse(JSON.stringify(data));
        console.log("POST Request is successful Table data", table);
        var CONTAINER : Containers [] = table;
        this.containers = CONTAINER;
        this.isSpinner = true;
      },
      error => {
        console.log("Error", error);
        alert(JSON.stringify(error));
      }
    );
  }

getContainerLogs(container_id) {

let  data = {"container_id":container_id};

  this.http.post('/getContainerLogs', {data}).subscribe(
      data => {
        let logs = JSON.parse(JSON.stringify(data));
        $('#showXlModal').click();
        console.log(logs);
        $('#dockerContainerLogs').append(logs.stderr);
      },
      error => {
        console.log("Error", error);
        alert(JSON.stringify(error));
      }
    );
}

// XL modal for docker logs
openXlModalLog(content) { this.modalService.open(content, { scrollable: true ,size: 'xl'}); }


}
