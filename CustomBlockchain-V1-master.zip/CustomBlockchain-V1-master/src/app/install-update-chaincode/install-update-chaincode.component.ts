import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-install-update-chaincode',
  templateUrl: './install-update-chaincode.component.html',
  styleUrls: ['./install-update-chaincode.component.css']
})
export class InstallUpdateChaincodeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
