import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-custom-explorer',
  templateUrl: './custom-explorer.component.html',
  styleUrls: ['./custom-explorer.component.css']
})
export class CustomExplorerComponent implements OnInit {
  nodes: number;
  totalBlocks: number;
  totalTxns: number;
  chaincode: number;
  currentBlockNo: number;
  txnMsg: number;
  txnCreator: number;
  txnId: number;
  currentBlockHash: number;
  previousBlockHash: number;

  constructor() { }

  ngOnInit() {
  }

}
