import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-create-identities',
  templateUrl: './create-identities.component.html',
  styleUrls: ['./create-identities.component.css']
})
export class CreateIdentitiesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
