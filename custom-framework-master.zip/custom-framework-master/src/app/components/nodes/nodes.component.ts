import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nodes',
  templateUrl: './nodes.component.html',
  styleUrls: ['./nodes.component.css']
})
export class NodesComponent implements OnInit {
  showCAModal: boolean;
  showPeerModal: boolean;
  showOrdererModal: boolean;
  showCustomPeerForm: boolean;
  showCustomCAForm: boolean;
  showCustomOrdererForm: boolean;

  constructor() { }

  ngOnInit(): void {
    this.showCAModal = false;
    this.showPeerModal = false;
    this.showOrdererModal = false;
    this.showCustomCAForm = false;
    this.showCustomPeerForm = false;
    this.showCustomOrdererForm = false;
  }

  peerInfo() {
    this.showPeerModal = true;
  }

  caInfo() {
    this.showCAModal = true;
  }

  ordererInfo() {
    this.showOrdererModal = true;
  }

  closePeerModal() {
    this.showPeerModal = false;
  }

  closeCAModal() {
    this.showCAModal = false;
  }

  closeOrdererModal() {
    this.showOrdererModal = false;
  }

  createPeer() {

  }

  createCA() {

  }

  createOrderer() {

  }

  showCustomCAFields() {
    this.showCustomCAForm = true;
  }

  showCustomPeerFields() {
    this.showCustomPeerForm = true;
  }

  showCustomOrdererFields() {
    this.showCustomOrdererForm = true;
  }

  hideCustomCAFields() {
    this.showCustomCAForm = false;
  }

  hideCustomPeerFields() {
    this.showCustomPeerForm = false;
  }

  hideCustomOrdererFields() {
    this.showCustomOrdererForm = false;
  }
}
