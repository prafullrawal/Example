import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-smartcontracts',
  templateUrl: './smartcontracts.component.html',
  styleUrls: ['./smartcontracts.component.css']
})
export class SmartcontractsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
