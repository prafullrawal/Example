package com.cts.integration.unitTest.client;

import com.cts.integration.dto.ComplexRequestDTO;
import com.cts.integration.util.FileUtil;
import com.cts.integration.util.SFTPUtil;
import org.apache.log4j.Logger;

public class SFTPClient implements IJunitClient {
  static Logger log = Logger.getLogger(SFTPClient.class.getName());
  
  public void put(ComplexRequestDTO complexRequestDTO) throws Exception {
    log.info("Putting file in SFTP ");
    SFTPUtil.sftpPut(complexRequestDTO);
  }
  
  public void get(ComplexRequestDTO complexRequestDTO) throws Exception {
    log.info("Fetching file file from SFTP");
    String latestFile = null;
    if ("TRUE".equalsIgnoreCase(complexRequestDTO.getFtpRemoteDelete())) {
      log.info("Looking for existence of matching file");
      latestFile = SFTPUtil.getLatestMatchingSFTPFile(complexRequestDTO);
    } else {
      log.info("Looking for  existence of matching file obtained after intitation of test case");
      latestFile = SFTPUtil.getLatestMatchingSFTPFileAfterTestIntiation(complexRequestDTO);
    } 
    if (latestFile == null && System.currentTimeMillis() < complexRequestDTO.getRequestTimeInMS() + complexRequestDTO.getFileftpWaitInterval()) {
      log.info("No Matching file in SFTP .. retrying");
      Thread.sleep(complexRequestDTO.getFilePollInterval());
      get(complexRequestDTO);
    } else {
      log.info("Finished Polling");
      if (latestFile != null) {
        log.info("downloading file");
        SFTPUtil.sftpGet(complexRequestDTO);
        complexRequestDTO.setResponse(FileUtil.readFileAsString(complexRequestDTO.getTestOutputFileLocation()));
      } else {
        throw new Exception("No matching file created after initiation of test");
      } 
    } 
  }
  
  public void cleanResponseContainer(ComplexRequestDTO complexRequestDTO) throws Exception {
    if ("TRUE".equalsIgnoreCase(complexRequestDTO.getFtpRemoteDelete())) {
      log.info("deleting matching files in SFTP before execution of Test case ");
      System.out.println("Files matching with " + complexRequestDTO.getRemoteFileName() + " will be deleted from SFTP location before executing the Test ");
      SFTPUtil.deleteMatchingSFTPFile(complexRequestDTO);
    } 
  }
  
  public void synchCall(ComplexRequestDTO complexRequestDTO) throws Exception {}
}
