package com.cts.integration.dto;

import java.io.File;
import java.util.Properties;

public class DigitalSignatureDTO {
  String inputFile;
  
  String signedFile;
  
  String referenceElement = "";
  
  String digestMethod = "http://www.w3.org/2000/09/xmldsig#sha1";
  
  String signatureMethod = "http://www.w3.org/2000/09/xmldsig#rsa-sha1";
  
  String signatureType = "http://www.w3.org/2000/09/xmldsig#enveloped-signature";
  
  String canonicalizationMethod = "http://www.w3.org/TR/2001/REC-xml-c14n-20010315";
  
  String keystoreFileLocation;
  
  String keyStoreType = "JKS";
  
  String keyStorePassword;
  
  String keyAlias;
  
  String keyPassword;
  
  public String getInputFile() {
    return this.inputFile;
  }
  
  public void setInputFile(String inputFile) {
    this.inputFile = inputFile;
  }
  
  public String getSignedFile() {
    return this.signedFile;
  }
  
  public void setSignedFile(String signedFile) {
    this.signedFile = signedFile;
  }
  
  public String getReferenceElement() {
    return this.referenceElement;
  }
  
  public void setReferenceElement(String referenceElement) {
    this.referenceElement = referenceElement;
  }
  
  public String getDigestMethod() {
    return this.digestMethod;
  }
  
  public void setDigestMethod(String digestMethod) {
    this.digestMethod = digestMethod;
  }
  
  public String getSignatureMethod() {
    return this.signatureMethod;
  }
  
  public void setSignatureMethod(String signatureMethod) {
    this.signatureMethod = signatureMethod;
  }
  
  public String getSignatureType() {
    return this.signatureType;
  }
  
  public void setSignatureType(String signatureType) {
    this.signatureType = signatureType;
  }
  
  public String getCanonicalizationMethod() {
    return this.canonicalizationMethod;
  }
  
  public void setCanonicalizationMethod(String canonicalizationMethod) {
    this.canonicalizationMethod = canonicalizationMethod;
  }
  
  public String getKeystoreFileLocation() {
    return this.keystoreFileLocation;
  }
  
  public void setKeystoreFileLocation(String keystoreFileLocation) {
    this.keystoreFileLocation = keystoreFileLocation;
  }
  
  public String getKeyStoreType() {
    return this.keyStoreType;
  }
  
  public void setKeyStoreType(String keyStoreType) {
    this.keyStoreType = keyStoreType;
  }
  
  public String getKeyStorePassword() {
    return this.keyStorePassword;
  }
  
  public void setKeyStorePassword(String keyStorePassword) {
    this.keyStorePassword = keyStorePassword;
  }
  
  public String getKeyAlias() {
    return this.keyAlias;
  }
  
  public void setKeyAlias(String keyAlias) {
    this.keyAlias = keyAlias;
  }
  
  public String getKeyPassword() {
    return this.keyPassword;
  }
  
  public void setKeyPassword(String keyPassword) {
    this.keyPassword = keyPassword;
  }
  
  public void setValueFromProperties(Properties properties, TestCaseDTO testCase) {
    this.inputFile = testCase.getInput();
    this.referenceElement = (properties.getProperty("reference.element") != null && properties.getProperty("reference.element").trim().length() > 0) ? properties.getProperty("reference.element").trim() : "";
    this.digestMethod = (properties.getProperty("digest.method") != null && properties.getProperty("digest.method").trim().length() > 0) ? properties.getProperty("digest.method").trim() : "http://www.w3.org/2000/09/xmldsig#sha1";
    this.signatureMethod = (properties.getProperty("signature.method") != null && properties.getProperty("signature.method").trim().length() > 0) ? properties.getProperty("signature.method").trim() : "http://www.w3.org/2000/09/xmldsig#rsa-sha1";
    this.signatureType = (properties.getProperty("signature.type") != null && properties.getProperty("signature.type").trim().length() > 0) ? properties.getProperty("signature.type").trim() : "http://www.w3.org/2000/09/xmldsig#enveloped-signature";
    this.canonicalizationMethod = (properties.getProperty("canonical.method") != null && properties.getProperty("canonical.method").trim().length() > 0) ? properties.getProperty("canonical.method").trim() : "http://www.w3.org/TR/2001/REC-xml-c14n-20010315";
    this.keystoreFileLocation = (properties.getProperty("keystore.location") != null && properties.getProperty("keystore.location").trim().length() > 0) ? properties.getProperty("keystore.location").trim() : null;
    this.keyStoreType = (properties.getProperty("keystore.type") != null && properties.getProperty("keystore.type").trim().length() > 0) ? properties.getProperty("keystore.type").trim() : "JKS";
    this.keyStorePassword = (properties.getProperty("keystore.password") != null && properties.getProperty("keystore.password").trim().length() > 0) ? properties.getProperty("keystore.password").trim() : "changeit";
    this.keyAlias = (properties.getProperty("keystore.alias") != null && properties.getProperty("keystore.alias").trim().length() > 0) ? properties.getProperty("keystore.alias").trim() : "digitalsignature";
    this.keyPassword = (properties.getProperty("key.password") != null && properties.getProperty("key.password").trim().length() > 0) ? properties.getProperty("key.password").trim() : "keyStorePassword";
    File certFile = new File(this.keystoreFileLocation);
    String certPath = null;
    String digitalSignatureFilePath = testCase.getDigitalSignatureInfo();
    int lastInd = digitalSignatureFilePath.lastIndexOf(File.separator);
    String dir = digitalSignatureFilePath.substring(0, lastInd);
    if (!certFile.isAbsolute()) {
      certPath = String.valueOf(dir) + File.separator + this.keystoreFileLocation;
      this.keystoreFileLocation = certPath;
    } 
    this.signedFile = String.valueOf(dir) + File.separator + testCase.getTestCase() + "SignedFile";
  }
}
