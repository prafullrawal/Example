package com.cts.integration.security;

import com.cts.integration.dto.ComplexRequestDTO;
import com.cts.integration.dto.ISecurityDTO;
import com.sun.jndi.toolkit.chars.BASE64Encoder;

import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import javax.net.ssl.SSLContext;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.Credentials;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.client.HttpClient;
import org.apache.http.conn.socket.LayeredConnectionSocketFactory;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.ssl.SSLContextBuilder;
import org.apache.http.ssl.SSLContexts;
import org.apache.http.ssl.TrustStrategy;



public class HTTPBasicAuthSecurity implements IHTTPSecurity {
  public HttpClient registerSecurity(ComplexRequestDTO complexRequestDTO, ISecurityDTO securityDTO) throws Exception {
    BasicCredentialsProvider basicCredentialsProvider = new BasicCredentialsProvider();
    UsernamePasswordCredentials credentials = null;
  
    boolean isHttps = false;
    if (complexRequestDTO.getUrl().startsWith("https"))
      isHttps = true; 
    if (!complexRequestDTO.isLegacy()) {
      credentials = new UsernamePasswordCredentials(securityDTO.getUsername(), securityDTO.getPassword());
    } else {
      credentials = new UsernamePasswordCredentials(securityDTO.getLegacyUserName(), securityDTO.getLegacyPassword());
    } 
    basicCredentialsProvider.setCredentials(AuthScope.ANY, (Credentials)credentials);
    if (!isHttps)
      return (HttpClient)HttpClientBuilder.create().setDefaultCredentialsProvider((CredentialsProvider)basicCredentialsProvider).build(); 
    SSLContextBuilder builder = new SSLContextBuilder();
    builder.loadTrustMaterial(null, new TrustStrategy() {
          public boolean isTrusted(X509Certificate[] chain, String authType) throws CertificateException {
            return true;
          }
        });
    SSLConnectionSocketFactory sslSF = new SSLConnectionSocketFactory(builder.build(), 
        SSLConnectionSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER);
    SSLContext sslContext = SSLContexts.custom().build();
    return (HttpClient)HttpClientBuilder.create().setDefaultCredentialsProvider((CredentialsProvider)basicCredentialsProvider).setSSLSocketFactory((LayeredConnectionSocketFactory)sslSF).build();
  }
}
