package com.cts.integration.unitTest.testCase;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.util.Properties;

import junit.framework.TestCase;

import org.custommonkey.xmlunit.Diff;
import org.custommonkey.xmlunit.XMLAssert;
import org.custommonkey.xmlunit.XMLUnit;

import com.cts.integration.dto.IJunitTestCase;
import com.cts.integration.dto.RequestDTO;
import com.cts.integration.unitTest.client.XML2WaySSLHttpClient;

public class XMLHttpWebserviceTestCase extends TestCase {
	
	public void testXMLHttpWs() throws FileNotFoundException, Exception{
		FileInputStream propInputStream = null;
		FileOutputStream actualFOS = null;
	    OutputStreamWriter actualOSW = null;
	    FileOutputStream expectedFOS = null;
	    OutputStreamWriter expectedOSW = null;
	    Reader expectedXMLReader =null;
	
		try{
						
			
	    
	                 
	            RequestDTO request = new RequestDTO();
	            String requestXMLPath = IJunitTestCase.getTestCase().getInput();      
	  	        String expectedXMLPath = IJunitTestCase.getTestCase().getExpectedOutput();		    
	  	        String actualXMLPath = IJunitTestCase.getTestCase().getActualOutput();    
	  	        File securityPropertyfile = new File(IJunitTestCase.getTestCase().getSecurityInfo());
	  	        Properties securityProp = new Properties();
	  	        
	            request.setRequestPath(requestXMLPath);
	  	        request.setServiceURL(IJunitTestCase.getTestCase().getEndpoint().trim());
	  	        if(securityPropertyfile.exists()){
	  	        	request.setSecured(true);
	  	        	propInputStream = new FileInputStream(securityPropertyfile);
	  	        	securityProp.load(propInputStream);
	  	        	request.setSecurityType(securityProp.getProperty("type"));
	  	        	if(RequestDTO.SECURITY_TYPE_CERT.equalsIgnoreCase(securityProp.getProperty("type"))){
	  	        		String cert = securityProp.getProperty("CERTNAME");
		  	        	File certFile = new File(cert);
		  	        	String certPath = null;
		  	        	if(!certFile.isAbsolute()){
			  	        	if(IJunitTestCase.getTestCase().getInput().trim().startsWith(IJunitTestCase.getTestCase().getSource()+IJunitTestCase.getTestCase().getTestCase())){
			  	        		certPath = IJunitTestCase.getTestCase().getSource()+IJunitTestCase.getTestCase().getTestCase().trim()+File.separator+cert;
			  	  			}else{
			  	  				certPath = IJunitTestCase.getTestCase().getSource()+cert;
			  	  			}
		  	        	}else{
		  	        		certPath = cert;
		  	        	}
	  	        		request.setCertPath(certPath);
	  	        		request.setKeystoreType(securityProp.getProperty("KEYSTORETYPE"));
	  	        		request.setKeystorePass(securityProp.getProperty("KEYSTOREPASSWORD"));
	  	        	}else{
	  	        		request.setUserName(securityProp.getProperty("USERNAME"));
	  	        		request.setPassword(securityProp.getProperty("PASSWORD"));
	  	        	}
	  	        }
	  	        
	  	       	  	        
	  	        /*System.out.println("request "+requestXMLPath);
	  	        System.out.println("expectedXMLPath "+expectedXMLPath);
	  	        System.out.println("actualXMLPath "+actualXMLPath);*/
	  	        
		  	      final String encoding = "UTF-8";		    
			      
			      // Invoke the web service    
			      //String webServiceResponse = TestHttpClient.invokeWebService(wsURL,requestXMLPath);
		  	      String webServiceResponse = XML2WaySSLHttpClient.invokeService(request);
			      // Store the response in the disk    
			      File responseFile = new File(actualXMLPath);    
			      responseFile.createNewFile(); 
			      actualFOS = new FileOutputStream(responseFile);
			      actualOSW = new OutputStreamWriter(actualFOS,encoding); 
			      actualOSW.write(webServiceResponse);	    
			      actualOSW.flush();
			      actualFOS.flush();
			      //Retrieve expected file
			      String asIsURL = IJunitTestCase.getTestCase().getLegacyEndPont();
			      if(asIsURL == null || asIsURL.trim().length() ==0){
			    	  expectedXMLReader = new InputStreamReader(new FileInputStream(expectedXMLPath), encoding);    
			      }else{
			    	  request.setServiceURL(asIsURL);
			    	  if(securityPropertyfile.exists() 
			    			  && RequestDTO.SECURITY_TYPE_BASIC.equalsIgnoreCase(securityProp.getProperty("type")) 
			    			  && securityProp.getProperty("LEGACYUSERNAME")!=null 
			    			  && securityProp.getProperty("LEGACYUSERNAME").trim().length()>0){
			    		  request.setUserName(securityProp.getProperty("LEGACYUSERNAME"));
			    		  request.setPassword(securityProp.getProperty("LEGACYPASSWORD"));
			    	  }
			    	  String asisResponse = XML2WaySSLHttpClient.invokeService(request);
			    	  
			    	  File expectedFile = new File(expectedXMLPath);    
			    	  expectedFile.createNewFile(); 
				      expectedFOS = new FileOutputStream(expectedFile);
				      expectedOSW = new OutputStreamWriter(expectedFOS,encoding); 
				      expectedOSW.write(asisResponse);	    
				      expectedOSW.flush();
				      expectedFOS.flush();
				      expectedXMLReader = new InputStreamReader(new FileInputStream(expectedXMLPath), encoding);
			      }
			      //read back actaul response
			      Reader actualXMLReader = new InputStreamReader(new FileInputStream(actualXMLPath), encoding);    
			      
			      // Ignore the white space while comparing    
			      XMLUnit.setIgnoreWhitespace(true);		    
			      
			      // Diff object, which contains the differences, if any    
			      Diff xmlDiff = new Diff(expectedXMLReader, actualXMLReader);		    
			      
			      // "false" ignores the order of the users in the XMLs    
			      //System.out.println(" TestCase : "+testName);
			      XMLAssert.assertXMLEqual(xmlDiff,true); 
			      //System.out.println(" diff "+xmlDiff.identical());
			      //writer.println(testName+" : "+xmlDiff.identical());
	        
	     }catch(Exception e){
	    	
	        	//writer.println(e.getMessage());
	    	   	e.printStackTrace();
	        	throw e;
		}finally{
			if(propInputStream!=null){
				propInputStream.close();
			}
			if(actualOSW != null){
				//actualOSW.flush();    
			    actualOSW.close();  
			}
			if(actualFOS != null){
				//actualFOS.flush();
				actualFOS.close();
			}
			if(expectedOSW != null){
				//actualOSW.flush();    
				expectedOSW.close();  
			}
			if(expectedFOS != null){
				//actualFOS.flush();
				expectedFOS.close();
			}
			if(expectedXMLReader != null){
				expectedXMLReader.close();
			}
			
		}
        
        


	}

}
