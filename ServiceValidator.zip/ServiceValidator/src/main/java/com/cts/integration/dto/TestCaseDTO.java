package com.cts.integration.dto;

import com.cts.integration.factory.TestCaseFactory;
import java.io.Serializable;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

public class TestCaseDTO implements Serializable {
 
/**
	 * 
	 */
	private static final long serialVersionUID = 5913846554160198453L;

String source;
  
  String testCase;
  
  String description;
  
  String pattern;
  
  String sourceProtocol;
  
  String sourceFormat;
  
  String targetProtocol;
  
  String targetFormat;
  
  String securityInfo;
  
  String endpoint;
  
  String legacyEndPont;
  
  String sourceInfo;
  
  String targetInfo;
  
  String input;
  
  String expectedOutput;
  
  String actualOutput;
  
  String digitalSignatureInfo;
  
  boolean rerun = false;
  
  long executedAt;
  
  String rowNum;
  
  boolean passed;
  
  String reason;
  
  List<String> ignoreList = new ArrayList<String>();
  
  String exceptionName;
  
  String errorDescription;
  
  String isActive;
  
  String headerInfo;
  
  public TestCaseDTO() {}
  
  public TestCaseDTO(TestCaseDTO testCase) {
    this.source = testCase.getSource();
    this.testCase = testCase.getTestCase();
    this.description = testCase.getDescription();
    this.pattern = testCase.getPattern();
    this.sourceProtocol = testCase.getSourceProtocol();
    this.sourceFormat = testCase.getSourceFormat();
    this.targetProtocol = testCase.getTargetProtocol();
    this.targetFormat = testCase.getTargetFormat();
    this.securityInfo = testCase.getSecurityInfo();
    this.endpoint = testCase.getEndpoint();
    this.legacyEndPont = testCase.getLegacyEndPont();
    this.sourceInfo = testCase.getSourceInfo();
    this.targetInfo = testCase.getTargetInfo();
    this.input = testCase.getInput();
    this.expectedOutput = testCase.getExpectedOutput();
    this.actualOutput = testCase.getActualOutput();
    this.digitalSignatureInfo = testCase.getDigitalSignatureInfo();
    boolean rerun = testCase.isRerun();
    this.rowNum = testCase.getRowNum();
    this.passed = testCase.isPassed();
    this.reason = testCase.getReason();
    this.executedAt = testCase.executedAt;
    this.exceptionName = testCase.exceptionName;
    this.errorDescription = testCase.errorDescription;
    this.isActive = testCase.isActive;
    
    // Added for headerdetails -- NML
    this.headerInfo = testCase.getHeaderInfo();
  }
  
  public String getSource() {
    return this.source;
  }
  
  public void setSource(String source) {
    this.source = source;
  }
  
  public String getTestCase() {
    return this.testCase;
  }
  
  public void setTestCase(String testCase) {
    this.testCase = testCase;
  }
  
  public String getDescription() {
    return this.description;
  }
  
  public void setDescription(String description) {
    this.description = description;
  }
  
  public String getPattern() {
    return this.pattern;
  }
  
  public void setPattern(String pattern) {
    this.pattern = pattern;
  }
  
  public String getSourceProtocol() {
    return this.sourceProtocol;
  }
  
  public void setSourceProtocol(String sourceProtocol) {
    this.sourceProtocol = sourceProtocol;
  }
  
  public String getSourceFormat() {
    return this.sourceFormat;
  }
  
  public void setSourceFormat(String sourceFormat) {
    this.sourceFormat = sourceFormat;
  }
  
  public String getTargetProtocol() {
    return this.targetProtocol;
  }
  
  public void setTargetProtocol(String targetProtocol) {
    this.targetProtocol = targetProtocol;
  }
  
  public String getTargetFormat() {
    return this.targetFormat;
  }
  
  public void setTargetFormat(String targetFormat) {
    this.targetFormat = targetFormat;
  }
  
  public String getSecurityInfo() {
    return this.securityInfo;
  }
  
  public void setSecurityInfo(String securityInfo) {
    this.securityInfo = securityInfo;
  }
  
  public String getEndpoint() {
    return this.endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    this.endpoint = endpoint;
  }
  
  public String getLegacyEndPont() {
    return this.legacyEndPont;
  }
  
  public void setLegacyEndPont(String legacyEndPont) {
    this.legacyEndPont = legacyEndPont;
  }
  
  public String getSourceInfo() {
    return this.sourceInfo;
  }
  
  public void setSourceInfo(String sourceInfo) {
    this.sourceInfo = sourceInfo;
  }
  
  public String getTargetInfo() {
    return this.targetInfo;
  }
  
  public void setTargetInfo(String targetInfo) {
    this.targetInfo = targetInfo;
  }
  
  public String getInput() {
    return this.input;
  }
  
  public void setInput(String input) {
    this.input = input;
  }
  
  public String getExpectedOutput() {
    return this.expectedOutput;
  }
  
  public void setExpectedOutput(String expectedOutput) {
    this.expectedOutput = expectedOutput;
  }
  
  public String getActualOutput() {
    return this.actualOutput;
  }
  
  public void setActualOutput(String actualOutput) {
    this.actualOutput = actualOutput;
  }
  
  public String getRowNum() {
    return this.rowNum;
  }
  
  public void setRowNum(String rowNum) {
    this.rowNum = rowNum;
  }
  
  public String getDigitalSignatureInfo() {
    return this.digitalSignatureInfo;
  }
  
  public void setDigitalSignatureInfo(String digitalSignatureInfo) {
    this.digitalSignatureInfo = digitalSignatureInfo;
  }
  
  public boolean isPassed() {
    return this.passed;
  }
  
  public void setPassed(boolean passed) {
    this.passed = passed;
  }
  
  public String getReason() {
    return this.reason;
  }
  
  public void setReason(String reason) {
    this.reason = reason;
  }
  
  public boolean isRerun() {
    return this.rerun;
  }
  
  public void setRerun(boolean rerun) {
    this.rerun = rerun;
  }
  
  public long getExecutedAt() {
    return this.executedAt;
  }
  
  public void setExecutedAt(long executedAt) {
    this.executedAt = executedAt;
  }
  
  public List<String> getIgnoreList() {
    return this.ignoreList;
  }
  
  public void setIgnoreList(List<String> ignoreList) {
    this.ignoreList = ignoreList;
  }
  
  public String getExceptionName() {
    return this.exceptionName;
  }
  
  public void setExceptionName(String exceptionName) {
    this.exceptionName = exceptionName;
  }
  
  public String getErrorDescription() {
    return this.errorDescription;
  }
  
  public void setErrorDescription(String errorDescription) {
    this.errorDescription = errorDescription;
  }
  
  public String getIsActive() {
    return this.isActive;
  }
  
  public void setIsActive(String isActive) {
    this.isActive = isActive;
  }
  
  public String toString() {
    if (this.reason == null)
      this.reason = ""; 
    return String.valueOf(this.testCase) + "," + this.description + "," + this.pattern + "," + 
      this.sourceProtocol + "," + this.sourceFormat + "," + this.targetProtocol + "," + this.targetFormat + "," + 
      this.securityInfo + "," + this.endpoint + "," + this.legacyEndPont + "," + this.sourceInfo +  "," + this.headerInfo + "," + this.input + "," + 
      this.expectedOutput + "," + this.actualOutput + "," + translateResult(this.passed) + "," + new Timestamp(this.executedAt) + "," + this.rerun + "," + this.reason;
  }
  
  public String toXML() {
    if (this.passed)
      return "<testcase time=\"" + new Timestamp(this.executedAt) + "\" name=\"" + this.testCase + "\" classname=\"" + TestCaseFactory.getTestClass(this.pattern) + "\"/>"; 
    return "<testcase time=\"" + new Timestamp(this.executedAt) + "\" name=\"" + this.testCase + "\" classname=\"" + TestCaseFactory.getTestClass(this.pattern) + "\">" + 
      "<error type=\"" + this.exceptionName + "\"><![CDATA[" + this.reason + "]]></error></testcase>";
  }
  
  public String translateResult(boolean bool) {
    if (bool)
      return "PASSED"; 
    return "FAIL";
  }

public String getHeaderInfo() {
	return this.headerInfo;
}

public void setHeaderInfo(String headerInfo) {
	this.headerInfo = headerInfo;
}
}
