package com.cts.integration.unitTest;

import com.cts.integration.dto.RequestDTO;
import com.cts.integration.unitTest.client.XML2WaySSLHttpClient;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.util.Properties;
import java.util.Set;
import junit.framework.TestCase;
import org.apache.log4j.Logger;
import org.custommonkey.xmlunit.Diff;
import org.custommonkey.xmlunit.XMLAssert;
import org.custommonkey.xmlunit.XMLUnit;

public class XMLHttpWebserviceUTC extends TestCase {
  Properties wsProp = new Properties();
  
  static Logger log = Logger.getLogger(XMLHttpWebserviceUTC.class.getName());
  
  public void testXMLHttpWs() throws FileNotFoundException, Exception {
    InputStream wsInput = null;
    FileInputStream propInputStream = null;
    try {
      String source = System.getProperty("RootSource");
      if (source == null || source.trim().length() == 0)
        source = String.valueOf(System.getProperty("user.dir")) + File.separator; 
      wsInput = new FileInputStream(String.valueOf(source) + "xmlHttpWebservice" + File.separator + "url.properties");
      this.wsProp.load(wsInput);
      Set<Object> keys = this.wsProp.keySet();
      for (Object k : keys) {
        String testName = (String)k;
        String wsURL = this.wsProp.getProperty(testName);
        String requestXMLPath = String.valueOf(source) + "xmlHttpWebservice" + File.separator + testName + File.separator + testName + "Input.xml";
        String expectedXMLPath = String.valueOf(source) + "xmlHttpWebservice" + File.separator + testName + File.separator + testName + "Expected.xml";
        String actualXMLPath = String.valueOf(source) + "xmlHttpWebservice" + File.separator + testName + File.separator + testName + "Actual.xml";
        RequestDTO request = new RequestDTO();
        File securityPropertyfile = new File(String.valueOf(source) + "xmlHttpWebservice" + File.separator + testName + File.separator + testName + "Security.properties");
        request.setRequestPath(requestXMLPath);
        request.setServiceURL(wsURL);
        if (securityPropertyfile.exists()) {
          request.setSecured(true);
          Properties securityProp = new Properties();
          propInputStream = new FileInputStream(securityPropertyfile);
          securityProp.load(propInputStream);
          request.setSecurityType(securityProp.getProperty("type"));
          if ("CERT".equalsIgnoreCase(securityProp.getProperty("type"))) {
            request.setCertPath(String.valueOf(source) + "xmlHttpWebservice" + File.separator + testName + File.separator + securityProp.getProperty("CERTNAME"));
          } else {
            request.setUserName(securityProp.getProperty("USERNAME"));
            request.setPassword(securityProp.getProperty("PASSWORD"));
          } 
        } 
        String encoding = "UTF-8";
        String webServiceResponse = XML2WaySSLHttpClient.invokeService(request);
        File responseFile = new File(actualXMLPath);
        responseFile.createNewFile();
        OutputStreamWriter oSW = new OutputStreamWriter(
            new FileOutputStream(responseFile), "UTF-8");
        oSW.write(webServiceResponse);
        oSW.flush();
        oSW.close();
        Reader expectedXMLReader = new InputStreamReader(
            new FileInputStream(expectedXMLPath), "UTF-8");
        Reader actualXMLReader = new InputStreamReader(
            new FileInputStream(actualXMLPath), "UTF-8");
        XMLUnit.setIgnoreWhitespace(true);
        Diff xmlDiff = new Diff(expectedXMLReader, actualXMLReader);
        System.out.println(" TestCase : " + testName);
        XMLAssert.assertXMLEqual(xmlDiff, true);
        System.out.println(" diff " + xmlDiff.identical());
      } 
    } catch (Exception e) {
      e.printStackTrace();
      throw e;
    } finally {
      if (wsInput != null)
        wsInput.close(); 
      if (propInputStream != null)
        propInputStream.close(); 
    } 
  }
}
