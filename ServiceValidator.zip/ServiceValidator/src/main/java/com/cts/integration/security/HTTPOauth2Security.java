package com.cts.integration.security;

import com.cts.integration.dto.ComplexRequestDTO;
import com.cts.integration.dto.ISecurityDTO;
import org.apache.http.client.HttpClient;

public class HTTPOauth2Security implements IHTTPSecurity {
  public HttpClient registerSecurity(ComplexRequestDTO complexRequestDTO, ISecurityDTO securityDTO) throws Exception {
    return null;
  }
}
