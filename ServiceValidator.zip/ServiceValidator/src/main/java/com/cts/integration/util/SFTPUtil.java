package com.cts.integration.util;

import com.cts.integration.dto.ComplexRequestDTO;
import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.Vector;
import org.apache.commons.net.ftp.FTPFile;

public class SFTPUtil {
  public static List<ChannelSftp.LsEntry> listFileFrromSFTP(ComplexRequestDTO complexRequestDTO) throws Exception {
    String SFTPHOST = complexRequestDTO.getHost();
    int SFTPPORT = complexRequestDTO.getPort();
    String SFTPUSER = complexRequestDTO.getFtpUser();
    String SFTPPASS = complexRequestDTO.getFtpPassword();
    List<ChannelSftp.LsEntry> remoteList = new ArrayList<ChannelSftp.LsEntry>();
    String SFTPWORKINGDIR = complexRequestDTO.getRemoteDirectory();
    Session session = null;
    Channel channel = null;
    ChannelSftp channelSftp = null;
    try {
      Vector<ChannelSftp.LsEntry> filelist;
      JSch jsch = new JSch();
      session = jsch.getSession(SFTPUSER, SFTPHOST, SFTPPORT);
      session.setPassword(SFTPPASS);
      Properties config = new Properties();
      config.put("StrictHostKeyChecking", "no");
      session.setConfig(config);
      session.connect();
      channel = session.openChannel("sftp");
      channel.connect();
      channelSftp = (ChannelSftp)channel;
      if (SFTPWORKINGDIR != null && SFTPWORKINGDIR.trim().length() != 0) {
        channelSftp.cd(SFTPWORKINGDIR);
        filelist = channelSftp.ls(SFTPWORKINGDIR);
      } else {
        filelist = channelSftp.ls("/");
      } 
      for (int i = 0; i < filelist.size(); i++) {
        ChannelSftp.LsEntry entry = filelist.get(i);
        remoteList.add(entry);
      } 
      return remoteList;
    } finally {
      if (channelSftp != null)
        channelSftp.disconnect(); 
      if (channel != null)
        channel.disconnect(); 
      if (session != null)
        session.disconnect(); 
    } 
  }
  
  public static List<ChannelSftp.LsEntry> listFileFrromSFTP(String user, String password, String host, int port, String dir) throws Exception {
    String SFTPWORKINGDIR = dir;
    Session session = null;
    Channel channel = null;
    ChannelSftp channelSftp = null;
    List<ChannelSftp.LsEntry> remoteList = new ArrayList<ChannelSftp.LsEntry>();
    try {
      Vector<ChannelSftp.LsEntry> filelist;
      JSch jsch = new JSch();
      session = jsch.getSession(user, host, port);
      session.setPassword(password);
      Properties config = new Properties();
      config.put("StrictHostKeyChecking", "no");
      session.setConfig(config);
      session.connect();
      channel = session.openChannel("sftp");
      channel.connect();
      channelSftp = (ChannelSftp)channel;
      if (SFTPWORKINGDIR != null && SFTPWORKINGDIR.trim().length() != 0) {
        channelSftp.cd(SFTPWORKINGDIR);
        filelist = channelSftp.ls(SFTPWORKINGDIR);
      } else {
        filelist = channelSftp.ls("/");
      } 
      for (int i = 0; i < filelist.size(); i++) {
        ChannelSftp.LsEntry entry = filelist.get(i);
        remoteList.add(entry);
      } 
      return remoteList;
    } finally {
      if (channelSftp != null)
        channelSftp.disconnect(); 
      if (channel != null)
        channel.disconnect(); 
      if (session != null)
        session.disconnect(); 
    } 
  }
  
  public static boolean sftpPut(ComplexRequestDTO complexRequestDTO) throws Exception {
    String SFTPHOST = complexRequestDTO.getHost();
    int SFTPPORT = complexRequestDTO.getPort();
    String SFTPUSER = complexRequestDTO.getFtpUser();
    String SFTPPASS = complexRequestDTO.getFtpPassword();
    String remoteFileLocation = String.valueOf(complexRequestDTO.getRemoteDirectory()) + complexRequestDTO.getRemoteFileName();
    Session session = null;
    Channel channel = null;
    ChannelSftp channelSftp = null;
    try {
      JSch jsch = new JSch();
      session = jsch.getSession(SFTPUSER, SFTPHOST, SFTPPORT);
      session.setPassword(SFTPPASS);
      Properties config = new Properties();
      config.put("StrictHostKeyChecking", "no");
      session.setConfig(config);
      session.connect();
      channel = session.openChannel("sftp");
      channel.connect();
      channelSftp = (ChannelSftp)channel;
      channelSftp.put(complexRequestDTO.getTestInputFileLocation(), remoteFileLocation);
    } finally {
      if (channelSftp != null)
        channelSftp.disconnect(); 
      if (channel != null)
        channel.disconnect(); 
      if (session != null)
        session.disconnect(); 
    } 
    return true;
  }
  
  public static boolean sftpGet(ComplexRequestDTO complexRequestDTO) throws Exception {
    String SFTPHOST = complexRequestDTO.getHost();
    int SFTPPORT = complexRequestDTO.getPort();
    String SFTPUSER = complexRequestDTO.getFtpUser();
    String SFTPPASS = complexRequestDTO.getFtpPassword();
    String remoteFileLocation = String.valueOf(complexRequestDTO.getRemoteDirectory()) + complexRequestDTO.getRemoteFileName();
    Session session = null;
    Channel channel = null;
    ChannelSftp channelSftp = null;
    try {
      JSch jsch = new JSch();
      session = jsch.getSession(SFTPUSER, SFTPHOST, SFTPPORT);
      session.setPassword(SFTPPASS);
      Properties config = new Properties();
      config.put("StrictHostKeyChecking", "no");
      session.setConfig(config);
      session.connect();
      channel = session.openChannel("sftp");
      channel.connect();
      channelSftp = (ChannelSftp)channel;
      channelSftp.get(remoteFileLocation, complexRequestDTO.getTestOutputFileLocation());
    } finally {
      if (channelSftp != null)
        channelSftp.disconnect(); 
      if (channel != null)
        channel.disconnect(); 
      if (session != null)
        session.disconnect(); 
    } 
    return true;
  }
  
  public static boolean sftpDelete(ComplexRequestDTO complexRequestDTO, String remoteDeleteFilePath) throws Exception {
    String SFTPHOST = complexRequestDTO.getHost();
    int SFTPPORT = complexRequestDTO.getPort();
    String SFTPUSER = complexRequestDTO.getFtpUser();
    String SFTPPASS = complexRequestDTO.getFtpPassword();
    FTPFile[] files = (FTPFile[])null;
    List<ChannelSftp.LsEntry> remoteList = new ArrayList<ChannelSftp.LsEntry>();
    Session session = null;
    Channel channel = null;
    ChannelSftp channelSftp = null;
    try {
      JSch jsch = new JSch();
      session = jsch.getSession(SFTPUSER, SFTPHOST, SFTPPORT);
      session.setPassword(SFTPPASS);
      Properties config = new Properties();
      config.put("StrictHostKeyChecking", "no");
      session.setConfig(config);
      session.connect();
      channel = session.openChannel("sftp");
      channel.connect();
      channelSftp = (ChannelSftp)channel;
      channelSftp.rm(remoteDeleteFilePath);
    } finally {
      if (channelSftp != null)
        channelSftp.disconnect(); 
      if (channel != null)
        channel.disconnect(); 
      if (session != null)
        session.disconnect(); 
    } 
    return true;
  }
  
  public static String getLatestMatchingSFTPFile(ComplexRequestDTO complexRequestDTO) throws Exception {
    System.out.println("Gettign matching file from sftp");
    int refTimeStamp = 0;
    String dir = complexRequestDTO.getRemoteDirectory();
    String fileName = complexRequestDTO.getRemoteFileName();
    List<ChannelSftp.LsEntry> fileList = listFileFrromSFTP(complexRequestDTO.getFtpUser(), complexRequestDTO.getFtpPassword(), complexRequestDTO.getHost(), complexRequestDTO.getPort(), dir);
    String name = null;
    for (ChannelSftp.LsEntry entry : fileList) {
      if (CommonUtil.regexMatch(entry.getFilename(), fileName) && 
        entry.getAttrs().getMTime() > refTimeStamp && 
        !entry.getAttrs().isDir()) {
        name = entry.getFilename();
        refTimeStamp = entry.getAttrs().getMTime();
      } 
    } 
    if (name != null)
      complexRequestDTO.setRemoteFileName(name); 
    return name;
  }
  
  public static String getLatestMatchingSFTPFileAfterTestIntiation(ComplexRequestDTO complexRequestDTO) throws Exception {
    System.out.println("Getting matching file from sftp after intiation of test");
    long refTimeStamp = complexRequestDTO.getRequestTimeInMS();
    String dir = complexRequestDTO.getRemoteDirectory();
    String fileName = complexRequestDTO.getRemoteFileName();
    List<ChannelSftp.LsEntry> fileList = listFileFrromSFTP(complexRequestDTO.getFtpUser(), complexRequestDTO.getFtpPassword(), complexRequestDTO.getHost(), complexRequestDTO.getPort(), dir);
    String name = null;
    for (ChannelSftp.LsEntry entry : fileList) {
      if (CommonUtil.regexMatch(entry.getFilename(), fileName) && (
        entry.getAttrs().getMTime() * 1000) > refTimeStamp && 
        !entry.getAttrs().isDir()) {
        name = entry.getFilename();
        refTimeStamp = (entry.getAttrs().getMTime() * 1000);
      } 
    } 
    if (name != null)
      complexRequestDTO.setRemoteFileName(name); 
    return name;
  }
  
  public static void deleteMatchingSFTPFile(ComplexRequestDTO complexRequestDTO) throws Exception {
    System.out.println("deleting matching file from ftp");
    String dir = complexRequestDTO.getRemoteDirectory();
    String fileName = complexRequestDTO.getRemoteFileName();
    List<ChannelSftp.LsEntry> fileList = listFileFrromSFTP(complexRequestDTO.getFtpUser(), complexRequestDTO.getFtpPassword(), complexRequestDTO.getHost(), complexRequestDTO.getPort(), dir);
    for (ChannelSftp.LsEntry entry : fileList) {
      if (CommonUtil.regexMatch(entry.getFilename(), fileName) && !entry.getAttrs().isDir())
        sftpDelete(complexRequestDTO, String.valueOf(dir) + entry.getFilename()); 
    } 
  }
}
