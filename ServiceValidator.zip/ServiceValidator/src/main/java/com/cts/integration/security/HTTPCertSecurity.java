package com.cts.integration.security;

import com.cts.integration.dto.ComplexRequestDTO;
import com.cts.integration.dto.ISecurityDTO;
import java.io.FileInputStream;
import java.security.KeyStore;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import org.apache.http.client.HttpClient;
import org.apache.http.conn.socket.LayeredConnectionSocketFactory;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.SSLContextBuilder;
import org.apache.http.conn.ssl.TrustStrategy;
import org.apache.http.impl.client.HttpClients;

public class HTTPCertSecurity implements IHTTPSecurity {
  public HttpClient registerSecurity(ComplexRequestDTO complexRequestDTO, ISecurityDTO securityDTO) throws Exception {
    FileInputStream kis = null;
    try {
      KeyStore keyStore = KeyStore.getInstance(securityDTO.getKeystoreType());
      kis = new FileInputStream(securityDTO.getCertName());
      keyStore.load(kis, securityDTO.getKeystorePass().toCharArray());
      SSLContextBuilder builder = new SSLContextBuilder();
      builder.loadTrustMaterial(keyStore, new TrustStrategy() {
            public boolean isTrusted(X509Certificate[] chain, String authType) throws CertificateException {
              return true;
            }
          });
      SSLConnectionSocketFactory sslSF = new SSLConnectionSocketFactory(builder.loadKeyMaterial(keyStore, securityDTO.getKeystorePass().toCharArray()).build(), 
          SSLConnectionSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER);
      return (HttpClient)HttpClients.custom().setSSLSocketFactory((LayeredConnectionSocketFactory)sslSF).build();
    } finally {
      if (kis != null)
        kis.close(); 
    } 
  }
}
