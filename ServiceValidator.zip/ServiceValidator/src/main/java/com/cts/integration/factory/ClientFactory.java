package com.cts.integration.factory;

import com.cts.integration.unitTest.client.DBClient;
import com.cts.integration.unitTest.client.FTPClient;
import com.cts.integration.unitTest.client.FileAdvancedClient;
import com.cts.integration.unitTest.client.FileClient;
import com.cts.integration.unitTest.client.HTTPAdvancedClient;
import com.cts.integration.unitTest.client.IJunitClient;
import com.cts.integration.unitTest.client.JMSClient;
import com.cts.integration.unitTest.client.MQClient;
import com.cts.integration.unitTest.client.SFTPClient;

public class ClientFactory {
  public static IJunitClient getClient(String protocol) {
    if ("MQ".equalsIgnoreCase(protocol))
      return (IJunitClient)new MQClient(); 
    if ("FILEA".equalsIgnoreCase(protocol))
      return (IJunitClient)new FileAdvancedClient(); 
    if ("FILE".equalsIgnoreCase(protocol))
      return (IJunitClient)new FileClient(); 
    if ("FTP".equalsIgnoreCase(protocol))
      return (IJunitClient)new FTPClient(); 
    if ("SFTP".equalsIgnoreCase(protocol))
      return (IJunitClient)new SFTPClient(); 
    if ("HTTP".equalsIgnoreCase(protocol) || 
      "HTTPPOST".equalsIgnoreCase(protocol) || 
      "HTTPGET".equalsIgnoreCase(protocol))
      return (IJunitClient)new HTTPAdvancedClient(); 
    if ("JMS".equalsIgnoreCase(protocol))
      return (IJunitClient)new JMSClient(); 
    if ("DB".equalsIgnoreCase(protocol))
      return (IJunitClient)new DBClient(); 
    return null;
  }
}
