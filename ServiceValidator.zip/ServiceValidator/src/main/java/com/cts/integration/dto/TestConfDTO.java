package com.cts.integration.dto;

import java.util.Properties;

public class TestConfDTO {
  String dbReporting;
  
  String dbdriverClass;
  
  String dbType;
  
  String dbURL;
  
  String dbUser;
  
  String dbPassword;
  
  String retry;
  
  String additionalRetry;
  
  String delayAdditionalRetry;
  
  public String getDbReporting() {
    return this.dbReporting;
  }
  
  public void setDbReporting(String dbReporting) {
    this.dbReporting = dbReporting;
  }
  
  public String getDbdriverClass() {
    return this.dbdriverClass;
  }
  
  public void setDbdriverClass(String dbdriverClass) {
    this.dbdriverClass = dbdriverClass;
  }
  
  public String getDbType() {
    return this.dbType;
  }
  
  public void setDbType(String dbType) {
    this.dbType = dbType;
  }
  
  public String getDbURL() {
    return this.dbURL;
  }
  
  public void setDbURL(String dbURL) {
    this.dbURL = dbURL;
  }
  
  public String getDbUser() {
    return this.dbUser;
  }
  
  public void setDbUser(String dbUser) {
    this.dbUser = dbUser;
  }
  
  public String getDbPassword() {
    return this.dbPassword;
  }
  
  public void setDbPassword(String dbPassword) {
    this.dbPassword = dbPassword;
  }
  
  public String getAdditionalRetry() {
    return this.additionalRetry;
  }
  
  public void setAdditionalRetry(String additionalRetry) {
    this.additionalRetry = additionalRetry;
  }
  
  public String getDelayAdditionalRetry() {
    return this.delayAdditionalRetry;
  }
  
  public void setDelayAdditionalRetry(String delayAdditionalRetry) {
    this.delayAdditionalRetry = delayAdditionalRetry;
  }
  
  public String getRetry() {
    return this.retry;
  }
  
  public void setRetry(String retry) {
    this.retry = retry;
  }
  
  public void setValueFromProperties(Properties properties) {
    this.dbReporting = (properties.getProperty("db.reporting") != null && properties.getProperty("db.reporting").trim().length() > 0) ? properties.getProperty("db.reporting").trim() : null;
    this.dbdriverClass = (properties.getProperty("driver.class") != null && properties.getProperty("driver.class").trim().length() > 0) ? properties.getProperty("driver.class").trim() : null;
    this.dbType = (properties.getProperty("db.type") != null && properties.getProperty("db.type").trim().length() > 0) ? properties.getProperty("db.type").trim() : null;
    this.dbURL = (properties.getProperty("db.url") != null && properties.getProperty("db.url").trim().length() > 0) ? properties.getProperty("db.url").trim() : null;
    this.dbUser = (properties.getProperty("db.user") != null && properties.getProperty("db.user").trim().length() > 0) ? properties.getProperty("db.user").trim() : null;
    this.dbPassword = (properties.getProperty("db.password") != null && properties.getProperty("db.password").trim().length() > 0) ? properties.getProperty("db.password").trim() : null;
    this.retry = (properties.getProperty("retry") != null && properties.getProperty("retry").trim().length() > 0) ? properties.getProperty("retry").trim() : null;
    this.additionalRetry = (properties.getProperty("additional.retry") != null && properties.getProperty("additional.retry").trim().length() > 0) ? properties.getProperty("additional.retry").trim() : null;
    this.delayAdditionalRetry = (properties.getProperty("delay.additional.retry") != null && properties.getProperty("delay.additional.retry").trim().length() > 0) ? properties.getProperty("delay.additional.retry").trim() : null;
  }
}
