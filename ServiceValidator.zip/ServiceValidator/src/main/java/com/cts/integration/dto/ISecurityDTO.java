package com.cts.integration.dto;

import java.io.File;
import java.util.Properties;

public class ISecurityDTO {
  String type;
  
  String certName;
  
  String keystoreType;
  
  String keystorePass;
  
  String username;
  
  String password;
  
  String legacyUserName;
  
  String legacyPassword;
  
  File certFile;

  
  public String getType() {
    return this.type;
  }
  
  public void setType(String type) {
    this.type = type;
  }
  
  public String getCertName() {
    return this.certName;
  }
  
  public void setCertName(String certName) {
    this.certName = certName;
  }
  
  public String getKeystoreType() {
    return this.keystoreType;
  }
  
  public void setKeystoreType(String keystoreType) {
    this.keystoreType = keystoreType;
  }
  
  public String getKeystorePass() {
    return this.keystorePass;
  }
  
  public void setKeystorePass(String keystorePass) {
    this.keystorePass = keystorePass;
  }
  
  public String getUsername() {
    return this.username;
  }
  
  public void setUsername(String username) {
    this.username = username;
  }
  
  public String getPassword() {
    return this.password;
  }
  
  public void setPassword(String password) {
    this.password = password;
  }
  
  public String getLegacyUserName() {
    return this.legacyUserName;
  }
  
  public void setLegacyUserName(String legacyUserName) {
    this.legacyUserName = legacyUserName;
  }
  
  public String getLegacyPassword() {
    return this.legacyPassword;
  }
  
  public void setLegacyPassword(String legacyPassword) {
    this.legacyPassword = legacyPassword;
  }
  
  public File getCertFile() {
    return this.certFile;
  }
  
  public void setCertFile(File certFile) {
    this.certFile = certFile;
  }
  
  public void setValueFromProperties(Properties securityProperties, TestCaseDTO testCase) {
    this.type = securityProperties.getProperty("type");
    this.certName = securityProperties.getProperty("CERTNAME");
    this.keystoreType = securityProperties.getProperty("KEYSTORETYPE");
    this.keystorePass = securityProperties.getProperty("KEYSTOREPASSWORD");
    this.username = securityProperties.getProperty("USERNAME");
    this.password = securityProperties.getProperty("PASSWORD");
    this.legacyUserName = securityProperties.getProperty("LEGACYUSERNAME");
    this.legacyPassword = securityProperties.getProperty("LEGACYPASSWORD");
    this.certFile = new File(this.certName);
    String certPath = null;
    if (!this.certFile.isAbsolute()) {
      String securityFilePath = testCase.getSecurityInfo();
      int lastInd = securityFilePath.lastIndexOf(File.separator);
      String dir = securityFilePath.substring(0, lastInd);
      certPath = String.valueOf(dir) + File.separator + this.certName;
      this.certName = certPath;
      this.certFile = new File(this.certName);
    } 
  }
}
