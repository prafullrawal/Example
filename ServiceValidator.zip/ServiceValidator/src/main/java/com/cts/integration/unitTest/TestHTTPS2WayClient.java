package com.cts.integration.unitTest;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileReader;
import java.security.KeyStore;
import javax.net.ssl.SSLContext;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.ssl.SSLContexts;
import org.apache.http.util.EntityUtils;

public class TestHTTPS2WayClient {
  public static void main(String[] a) throws Exception {
    KeyStore keyStore = KeyStore.getInstance("JKS");
    keyStore.load(new FileInputStream("D:/UnitTest/clientCertAndKey/clientks.jks"), "changeit".toCharArray());
    SSLContext sslContext = SSLContexts.custom().loadKeyMaterial(keyStore, "changeit".toCharArray()).build();
    CloseableHttpClient closeableHttpClient = HttpClients.custom().setSslcontext(sslContext).build();
    BufferedReader bufferedReader = null;
    FileReader fr = null;
    StringBuffer requestFileContents = new StringBuffer();
    fr = new FileReader("D:/JUnitTest/xmlHttpWebservice/test3/test3Input.xml");
    bufferedReader = new BufferedReader(fr);
    String line = null;
    try {
      while ((line = bufferedReader.readLine()) != null)
        requestFileContents.append(line); 
      String payLoadLogin = requestFileContents.toString();
      HttpPost httppost = new HttpPost("https://10.226.33.18:1026/fetchaddress");
      httppost.setHeader("Accept", "application/soap+xml,application/dime,multipart/related,text/*");
      httppost.setHeader("SOAPAction", "");
      StringEntity se = new StringEntity(payLoadLogin);
      httppost.setEntity((HttpEntity)se);
      HttpResponse response = closeableHttpClient.execute((HttpUriRequest)httppost);
      System.out.println("Response " + EntityUtils.toString(response.getEntity()));
    } finally {
      fr.close();
      bufferedReader.close();
    } 
  }
}
