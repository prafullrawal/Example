
package com.cts.integration.unitTest.testCase;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.Properties;

import junit.framework.TestCase;

import org.custommonkey.xmlunit.Diff;
import org.custommonkey.xmlunit.XMLAssert;
import org.custommonkey.xmlunit.XMLUnit;
import org.json.JSONArray;
import org.json.JSONObject;
import org.skyscreamer.jsonassert.JSONAssert;

import com.cts.integration.dto.IJunitConstants;
import com.cts.integration.dto.IJunitTestCase;
import com.cts.integration.dto.MQRequestDTO;
import com.cts.integration.unitTest.client.MQClient;
import com.cts.integration.util.FileUtil;

public class MQSynchTestCase extends TestCase {
	
	public void testMQService() throws Exception{
		FileInputStream propInputStream = null;
		Reader expectedMessageReader =null;
		FileInputStream expectedInputStream = null;
		Reader actualMessageReader =null;
		FileInputStream actualInputStream = null;
	    boolean legacyMode = false;
	
		try{
						
			
				
	                 
	            MQRequestDTO actualRequestDTO = new MQRequestDTO();
	            MQRequestDTO legacyRequestDTO = null;
	            String requestPath = IJunitTestCase.getTestCase().getInput();      
	  	        String expectedPath = IJunitTestCase.getTestCase().getExpectedOutput();		    
	  	        String actualpath = IJunitTestCase.getTestCase().getActualOutput(); 
	  	        String sourceInfo = IJunitTestCase.getTestCase().getSourceInfo();
	  	        String actualResponse = null;
	  	        String expectedRespone = null;
	  	        
	  	        String request = FileUtil.readFileAsString(requestPath);
	  	        
	  	        File mqPropertiesFile = new File(sourceInfo);
	  	        Properties mqProperties = new Properties();
	  	        
	  	        propInputStream = new FileInputStream(mqPropertiesFile);
	  	        mqProperties.load(propInputStream);
	  	        
	  	        actualRequestDTO.setActualValueFromProperties(mqProperties);
	  	        actualRequestDTO.setMessage(request);
	  	        if(mqProperties.getProperty("LEGACY")!=null && "TRUE".equalsIgnoreCase(mqProperties.getProperty("LEGACY").trim())){
	  	        	legacyMode = true;
	  	        	legacyRequestDTO = new MQRequestDTO();
	  	        	legacyRequestDTO.setLegacyValueFromProperties(mqProperties);
	  	        	legacyRequestDTO.setMessage(request);
	  	        }
	  	        
	  	        actualResponse = MQClient.invoke2WayMQService(actualRequestDTO);
	  	        FileUtil.writeToFile(actualpath, actualResponse);
	  	        
	  	       
	  	        	
	  	        	 
	  	        if(legacyMode){
	  	        	expectedRespone  = MQClient.invoke2WayMQService(legacyRequestDTO);
	  	        	FileUtil.writeToFile(expectedPath, expectedRespone);
	  	        }else{
	  	        	expectedRespone = FileUtil.readFileAsString(expectedPath);
	  	        }
	  	        expectedInputStream = new FileInputStream(expectedPath);
	        	expectedMessageReader = new InputStreamReader(expectedInputStream);
	        	
	        	actualInputStream = new FileInputStream(actualpath);
	        	actualMessageReader = new InputStreamReader(actualInputStream);
	        	
	        	if(IJunitConstants.FORMAT_XML.equalsIgnoreCase(IJunitTestCase.getTestCase().getTargetFormat())){
	        		XMLUnit.setIgnoreWhitespace(true);		    
				    Diff xmlDiff = new Diff(expectedMessageReader, actualMessageReader);		    
				    XMLAssert.assertXMLEqual(xmlDiff,true); 
	        	}else if(IJunitConstants.FORMAT_JSON.equalsIgnoreCase(IJunitTestCase.getTestCase().getTargetFormat())){
	        		if(actualResponse.trim().startsWith("[")){
	  		    	  JSONArray actualJArray = new JSONArray(actualResponse);
	  		    	  JSONArray expectedJArray = new JSONArray(expectedRespone); 
	  		    	  JSONAssert.assertEquals(expectedJArray, actualJArray, false);
	  		      }else{
	  		    	  JSONObject actualJsonObj = new JSONObject(actualResponse);
	  		    	  JSONObject expectedJsonObj = new JSONObject(expectedRespone);
	  		    	  JSONAssert.assertEquals(expectedJsonObj, actualJsonObj, true);
	  		    	  
	  		      }
	        	}else{
	        		assertEquals(expectedRespone, actualResponse);
	        	}
	  	      
	  	      
	        
	     }catch(Exception e){
	    	
	        	//writer.println(e.getMessage());
	    	   	e.printStackTrace();
	        	throw e;
		}finally{
			if(propInputStream!=null){
				propInputStream.close();
			}
			if(expectedMessageReader != null){
				expectedMessageReader.close();
			}
			if(expectedInputStream != null){
				expectedInputStream.close();
			}
			if(expectedMessageReader != null){
				expectedMessageReader.close();
			}
			
		}
        
        


	}
	
	

}
