package com.cts.integration.dto;

public class IJunitConstants {
  public static final String PATTERN_SYNCHWS = "SynchronousWebservice";
  
  public static final String PATTERN_JSONPOST = "JSONPost";
  
  public static final String PATTERN_JSONGET = "JSONGet";
  
  public static final String PATTERN_SYNCHMQ = "SynchronousMQ";
  
  public static final String PATTERN_COMPLEX = "Complex";
  
  public static final String PATTERN_SYNCH = "Synch";
  
  public static final String PATTERN_ASYNCH = "Asynch";
  
  public static final String DEFAULT_TEST_INPUT_EXCEL = "IJUnitTest.xlsx";
  
  public static final String DEFAULT_TEST_CONF_PROPERTIES = "ijunit.properties";
  
  public static final String CORRELATIONTYPE_RESP_CORRELATIONID = "CORRELATIONID";
  
  public static final String CORRELATIONTYPE_RESP_MESSAGEID = "MESSAGEID";
  
  public static final String CORRELATIONTYPE_RESP_NONE = "NONE";
  
  public static final String FORMAT_XML = "xml";
  
  public static final String FORMAT_JSON = "json";
  
  public static final String FORMAT_TXT = "txt";
  
  public static final String FORMAT_UNKNOWN = "unknown";
  
  public static final String PROTOCOL_MQ = "MQ";
  
  public static final String PROTOCOL_JMS = "JMS";
  
  public static final String PROTOCOL_FILE_ADVANCED = "FILEA";
  
  public static final String PROTOCOL_FILE = "FILE";
  
  public static final String PROTOCOL_FTP = "FTP";
  
  public static final String PROTOCOL_SFTP = "SFTP";
  
  public static final String PROTOCOL_DB = "DB";
  
  public static final String PROTOCOL_HTTP = "HTTP";
  
  public static final String PROTOCOL_HTTP_POST = "HTTPPOST";
  
  public static final String PROTOCOL_HTTP_GET = "HTTPGET";
  
  public static final String HTTP_METHOD_POST = "POST";
  
  public static final String HTTP_METHOD_GET = "GET";
  
  public static final String SECURITY_TYPE_CERT = "CERT";
  
  public static final String SECURITY_TYPE_BASIC = "BASIC";
  
  public static final String VALUE_TRUE = "TRUE";
  
  public static final String VALUE_FALSE = "FALSE";
  
  public static final String VALUE_ACTIVE = "ACTIVE";
  
  public static final String VALUE_INACTIVE = "INACTIVE";
  
  public static final String VALUE_PASSED = "PASSED";
  
  public static final String VALUE_FAIL = "FAIL";
}
