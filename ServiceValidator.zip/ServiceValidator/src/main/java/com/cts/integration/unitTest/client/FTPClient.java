package com.cts.integration.unitTest.client;

import com.cts.integration.dto.ComplexRequestDTO;
import com.cts.integration.util.FileUtil;
import java.util.Calendar;
import org.apache.log4j.Logger;

public class FTPClient implements IJunitClient {
  static Logger log = Logger.getLogger(FTPClient.class.getName());
  
  public void put(ComplexRequestDTO complexRequestDTO) throws Exception {
    log.info("Putting file in FTP ");
    FileUtil.ftpPut(complexRequestDTO.getHost(), complexRequestDTO.getPort(), complexRequestDTO.getFtpUser(), complexRequestDTO.getFtpPassword(), complexRequestDTO.getTestInputFileLocation(), String.valueOf(complexRequestDTO.getRemoteDirectory()) + complexRequestDTO.getRemoteFileName(), complexRequestDTO.getSourceFormat());
  }
  
  public void get(ComplexRequestDTO complexRequestDTO) throws Exception {
    log.info("Fetching file file from FTP");
    Calendar putDate = Calendar.getInstance();
    putDate.setTimeInMillis(complexRequestDTO.getRequestTimeInMS());
    String latestFile = null;
    if ("TRUE".equalsIgnoreCase(complexRequestDTO.getFtpRemoteDelete())) {
      log.info("Looking for existence of matching file");
      latestFile = FileUtil.getLatestMatchingFTPFile(complexRequestDTO.getRemoteDirectory(), complexRequestDTO.getRemoteFileName(), complexRequestDTO.getHost(), complexRequestDTO.getPort(), complexRequestDTO.getFtpUser(), complexRequestDTO.getFtpPassword());
    } else {
      log.info("Looking for  existence of matching file obtained after intitation of test case");
      latestFile = FileUtil.getLatestMatchingFTPFileAfter(complexRequestDTO.getRemoteDirectory(), complexRequestDTO.getRemoteFileName(), putDate, complexRequestDTO.getHost(), complexRequestDTO.getPort(), complexRequestDTO.getFtpUser(), complexRequestDTO.getFtpPassword());
    } 
    if (latestFile == null && System.currentTimeMillis() < complexRequestDTO.getRequestTimeInMS() + complexRequestDTO.getFileftpWaitInterval()) {
      log.info("No Matching file in FTP .. retrying");
      Thread.sleep(complexRequestDTO.getFilePollInterval());
      get(complexRequestDTO);
    } else {
      log.info("Finished Polling");
      if (latestFile != null) {
        log.info("downloading file");
        FileUtil.ftpGet(complexRequestDTO.getHost(), complexRequestDTO.getPort(), complexRequestDTO.getFtpUser(), complexRequestDTO.getFtpPassword(), complexRequestDTO.getTestOutputFileLocation(), latestFile, complexRequestDTO.getTargetFormat());
        complexRequestDTO.setResponse(FileUtil.readFileAsString(complexRequestDTO.getTestOutputFileLocation()));
      } else {
        throw new Exception("No matching file created after initiation of test");
      } 
    } 
  }
  
  public void cleanResponseContainer(ComplexRequestDTO complexRequestDTO) throws Exception {
    if ("TRUE".equalsIgnoreCase(complexRequestDTO.getFtpRemoteDelete())) {
      log.info("deleting matching files before execution of Test case ");
      System.out.println("Files matching with " + complexRequestDTO.getRemoteFileName() + " will be deleted from FTP location before executing the Test ");
      FileUtil.deleteMatchingFTPFile(complexRequestDTO.getRemoteDirectory(), complexRequestDTO.getRemoteFileName(), complexRequestDTO.getHost(), complexRequestDTO.getPort(), complexRequestDTO.getFtpUser(), complexRequestDTO.getFtpPassword());
    } 
  }
  
  public void synchCall(ComplexRequestDTO complexRequestDTO) throws Exception {}
}
