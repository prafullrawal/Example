package com.cts.integration.security;

import com.cts.integration.dto.ComplexRequestDTO;
import com.cts.integration.dto.ISecurityDTO;
import org.apache.http.client.HttpClient;

public interface IHTTPSecurity {
  HttpClient registerSecurity(ComplexRequestDTO paramComplexRequestDTO, ISecurityDTO paramISecurityDTO) throws Exception;
}
