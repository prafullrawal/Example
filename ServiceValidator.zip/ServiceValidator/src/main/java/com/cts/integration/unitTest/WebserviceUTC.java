package com.cts.integration.unitTest;

import com.cts.integration.unitTest.client.XML2WaySSLHttpClient;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Reader;
import junit.framework.TestCase;
import org.custommonkey.xmlunit.Diff;
import org.custommonkey.xmlunit.XMLAssert;
import org.custommonkey.xmlunit.XMLUnit;

public class WebserviceUTC extends TestCase {
  public void test() throws FileNotFoundException, Exception {
    String wsURL = "http://localhost:8088/mockAddressExport1_AddressHttpBinding";
    String requestXMLPath = "D:/UnitTest/request/test1.xml";
    String expectedXMLPath = "D:/UnitTest/expected/test1Out.xml";
    String actualXMLPath = "D:/UnitTest/actual/actual_response_test1.xml";
    String encoding = "UTF-8";
    String webServiceResponse = XML2WaySSLHttpClient.invokeService("http://localhost:8088/mockAddressExport1_AddressHttpBinding", "D:/UnitTest/request/test1.xml", "D:/UnitTest");
    File responseFile = new File("D:/UnitTest/actual/actual_response_test1.xml");
    responseFile.createNewFile();
    OutputStreamWriter oSW = new OutputStreamWriter(
        new FileOutputStream(responseFile), "UTF-8");
    oSW.write(webServiceResponse);
    oSW.flush();
    oSW.close();
    Reader expectedXMLReader = new InputStreamReader(
        new FileInputStream("D:/UnitTest/expected/test1Out.xml"), "UTF-8");
    Reader actualXMLReader = new InputStreamReader(
        new FileInputStream("D:/UnitTest/actual/actual_response_test1.xml"), "UTF-8");
    XMLUnit.setIgnoreWhitespace(true);
    Diff xmlDiff = new Diff(expectedXMLReader, actualXMLReader);
    XMLAssert.assertXMLEqual(xmlDiff, true);
    System.out.println(" diff " + xmlDiff.identical());
  }
}
