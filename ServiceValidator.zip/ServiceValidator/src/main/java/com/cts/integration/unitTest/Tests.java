package com.cts.integration.unitTest;

import com.cts.integration.assertion.IJunitXMLAssertion;
import com.cts.integration.util.FileUtil;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import junit.framework.TestCase;

public class Tests extends TestCase {
  public static void main(String[] a) throws Exception {
    String line = "ACXIOM_DDA_ADHOC_RELAPPEND_20161017065646_00001.TXT";
    String pattern = "^ACXIOM_DDA_ADHOC_RELAPPEND.*TXT$";
    Pattern r = Pattern.compile(pattern);
    Matcher m = r.matcher(line);
    System.out.println(" matched " + m.find());
  }
  
  public void test() throws Exception {
    (new IJunitXMLAssertion()).assertEquals(FileUtil.readFileAsString("D:/JunitTest/test1/test1Expected.xml"), FileUtil.readFileAsString("D:/JunitTest/test1/test1Actual1.xml"), new ArrayList());
  }
}
