package com.cts.integration.util;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class CommonUtil {
  public static boolean regexMatch(String content, String pattern) throws Exception {
    Pattern r = Pattern.compile(pattern);
    Matcher m = r.matcher(content);
    return m.find();
  }
}
