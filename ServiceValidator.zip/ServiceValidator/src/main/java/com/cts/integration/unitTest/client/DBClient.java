package com.cts.integration.unitTest.client;

import com.cts.integration.dto.ComplexRequestDTO;
import com.cts.integration.util.FileUtil;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import org.apache.log4j.Logger;

public class DBClient implements IJunitClient {
  static Logger log = Logger.getLogger(DBClient.class.getName());
  
  public void put(ComplexRequestDTO complexRequestDTO) throws Exception {
    log.info("Writing data to database");
    Connection con = null;
    Statement stat = null;
    try {
      Class.forName(complexRequestDTO.getDriverClass());
      if (complexRequestDTO.getDbUser() == null || complexRequestDTO.getDbUser().trim().length() == 0) {
        con = DriverManager.getConnection(complexRequestDTO.getDbURL());
      } else {
        con = DriverManager.getConnection(complexRequestDTO.getDbURL(), complexRequestDTO.getDbUser(), complexRequestDTO.getDbPassword());
      } 
      stat = con.createStatement();
      int update = stat.executeUpdate(complexRequestDTO.getQuery());
    } finally {
      if (stat != null)
        stat.close(); 
      if (con != null)
        con.close(); 
    } 
  }
  
  public void get(ComplexRequestDTO complexRequestDTO) throws Exception {
    log.info("Getting data to database");
    Connection con = null;
    Statement stat = null;
    ResultSet rs = null;
    try {
      Class.forName(complexRequestDTO.getDriverClass());
      if (complexRequestDTO.getDbUser() == null || complexRequestDTO.getDbUser().trim().length() == 0) {
        con = DriverManager.getConnection(complexRequestDTO.getDbURL());
      } else {
        con = DriverManager.getConnection(complexRequestDTO.getDbURL(), complexRequestDTO.getDbUser(), complexRequestDTO.getDbPassword());
      } 
      stat = con.createStatement();
      fetchUpdate(complexRequestDTO, rs, stat);
    } finally {
      if (rs != null)
        rs.close(); 
      if (stat != null)
        stat.close(); 
      if (con != null)
        con.close(); 
    } 
  }
  
  public void fetchUpdate(ComplexRequestDTO compDTO, ResultSet rs, Statement stat) throws Exception {
    log.info("Fetching data with query " + compDTO.getQuery());
    rs = stat.executeQuery(compDTO.getQuery());
    boolean result = rs.next();
    if (!result && System.currentTimeMillis() < compDTO.getRequestTimeInMS() + compDTO.getFileftpWaitInterval()) {
      log.info("No result found will Fetch again");
      Thread.sleep(compDTO.getFilePollInterval());
      fetchUpdate(compDTO, rs, stat);
    } else {
      log.info("Finished fetching");
      compDTO.setResponse((new Boolean(result)).toString());
      FileUtil.writeToFile(compDTO.getTestOutputFileLocation(), compDTO.getResponse());
    } 
  }
  
  public void cleanResponseContainer(ComplexRequestDTO complexRequestDTO) throws Exception {
    log.info("Cleaning Database before execution of TestCase");
    Connection con = null;
    Statement stat = null;
    try {
      if (complexRequestDTO.getCleanQuery() != null && complexRequestDTO.getCleanQuery().trim().length() != 0) {
        log.info("Cleaning query " + complexRequestDTO.getCleanQuery());
        Class.forName(complexRequestDTO.getDriverClass());
        if (complexRequestDTO.getDbUser() == null || complexRequestDTO.getDbUser().trim().length() == 0) {
          con = DriverManager.getConnection(complexRequestDTO.getDbURL());
        } else {
          con = DriverManager.getConnection(complexRequestDTO.getDbURL(), complexRequestDTO.getDbUser(), complexRequestDTO.getDbPassword());
        } 
        stat = con.createStatement();
        int i = stat.executeUpdate(complexRequestDTO.getCleanQuery());
      } 
    } finally {
      if (stat != null)
        stat.close(); 
      if (con != null)
        con.close(); 
    } 
  }
  
  public void synchCall(ComplexRequestDTO complexRequestDTO) throws Exception {}
}
