package com.cts.integration.factory;

import com.cts.integration.dto.TestCaseDTO;
import com.cts.integration.unitTest.testCase.GenericTestCase;
import com.cts.integration.unitTest.testCase.SynchGenericTestCase;
import junit.framework.TestCase;

public class TestCaseFactory {
  public static Class getTestClass(String pattern) {
    if ("Synch".equalsIgnoreCase(pattern))
      return SynchGenericTestCase.class; 
    if ("Asynch".equalsIgnoreCase(pattern))
      return GenericTestCase.class; 
    return GenericTestCase.class;
  }
  
  public static TestCase getTestClass(String pattern, TestCaseDTO testCase) {
    if ("Synch".equalsIgnoreCase(pattern))
      return (TestCase)new SynchGenericTestCase("test", testCase); 
    if ("Asynch".equalsIgnoreCase(pattern))
      return (TestCase)new GenericTestCase("test", testCase); 
    return (TestCase)new GenericTestCase("test", testCase);
  }
}
