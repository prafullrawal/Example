package com.cts.integration.unitTest.client;

import com.cts.integration.dto.ComplexRequestDTO;
import com.cts.integration.util.FileUtil;

public class FileAdvancedClient implements IJunitClient {
  public void put(ComplexRequestDTO complexRequestDTO) throws Exception {
    FileUtil.writeToFile(String.valueOf(complexRequestDTO.getLocalDirectory()) + complexRequestDTO.getLocalFileName(), complexRequestDTO.getMessage());
  }
  
  public void get(ComplexRequestDTO complexRequestDTO) throws Exception {
    String latestFile = FileUtil.getLatestMatchingFileAfter(complexRequestDTO.getLocalDirectory(), complexRequestDTO.getLocalFileName(), complexRequestDTO.getRequestTimeInMS());
    if (latestFile == null && System.currentTimeMillis() < complexRequestDTO.getRequestTimeInMS() + complexRequestDTO.getFileftpWaitInterval()) {
      Thread.sleep(complexRequestDTO.getFilePollInterval());
      get(complexRequestDTO);
    } else if (latestFile != null) {
      complexRequestDTO.setResponse(FileUtil.readFileAsString(latestFile));
      FileUtil.writeToFile(complexRequestDTO.getTestOutputFileLocation(), complexRequestDTO.getResponse());
    } else {
      throw new Exception("No matching file created after initiation of test");
    } 
  }
  
  public void cleanResponseContainer(ComplexRequestDTO complexRequestDTO) throws Exception {}
  
  public void synchCall(ComplexRequestDTO complexRequestDTO) throws Exception {}
}
