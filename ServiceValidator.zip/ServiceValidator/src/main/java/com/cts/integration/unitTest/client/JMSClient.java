package com.cts.integration.unitTest.client;

import com.cts.integration.dto.ComplexRequestDTO;
import com.cts.integration.util.FileUtil;
import java.util.Hashtable;
import java.util.UUID;
import javax.jms.BytesMessage;
import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.MessageListener;
import javax.jms.MessageProducer;
import javax.jms.Queue;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.naming.Context;
import javax.naming.InitialContext;
import org.apache.log4j.Logger;

public class JMSClient implements IJunitClient {
  static Logger log = Logger.getLogger(JMSClient.class.getName());
  
  public void put(ComplexRequestDTO complexRequestDTO) throws Exception {
    log.info(" putting JMS message in " + complexRequestDTO.getRequestQueueName());
    Connection myConn = null;
    Session mySess = null;
    try {
      String MYCF_LOOKUP_NAME = complexRequestDTO.getConnectionFactory();
      String MYQUEUE_LOOKUP_NAME = complexRequestDTO.getRequestQueueName();
      String REPLY_QUEUE_NAME = complexRequestDTO.getResponseQueueName();
      Context ctx = null;
      Hashtable<Object, Object> env = new Hashtable<Object, Object>();
      env.put("java.naming.factory.initial", complexRequestDTO.getJmsConetxFactory());
      env.put("java.naming.provider.url", complexRequestDTO.getJmsProviderURL());
      ctx = new InitialContext(env);
      ConnectionFactory myConnFactory = (ConnectionFactory)ctx.lookup(MYCF_LOOKUP_NAME);
      Queue myQueue = (Queue)ctx.lookup(MYQUEUE_LOOKUP_NAME);
      myConn = myConnFactory.createConnection();
      mySess = myConn.createSession(false, 1);
      MessageProducer myMsgProducer = mySess.createProducer((Destination)myQueue);
      TextMessage myTextMsg = mySess.createTextMessage();
      myTextMsg.setText(complexRequestDTO.getMessage());
      if (REPLY_QUEUE_NAME != null && REPLY_QUEUE_NAME.trim().length() > 0) {
        log.info(" Setting JMS Replyto Queue name " + REPLY_QUEUE_NAME);
        Queue replyQueue = (Queue)ctx.lookup(REPLY_QUEUE_NAME);
        myTextMsg.setJMSReplyTo((Destination)replyQueue);
      } 
      if ("CORRELATIONID".equalsIgnoreCase(complexRequestDTO.getCorrelationType())) {
        String correlationId = UUID.randomUUID().toString();
        log.info("Setting correlartion ID  in request Message as " + correlationId);
        myTextMsg.setJMSCorrelationID(correlationId);
        complexRequestDTO.setJmsCorrelationId(correlationId);
      } 
      myMsgProducer.send((Message)myTextMsg);
      complexRequestDTO.setJmsMessageId(myTextMsg.getJMSMessageID());
      log.info("Message ID of put message " + myTextMsg.getJMSMessageID());
    } finally {
      if (mySess != null)
        mySess.close(); 
      if (myConn != null)
        myConn.close(); 
    } 
  }
  
  public void get(ComplexRequestDTO complexRequestDTO) throws Exception {
    log.info(" Getting JMS message from " + complexRequestDTO.getResponseQueueName());
    complexRequestDTO.setResponse(getMessage(complexRequestDTO));
    FileUtil.writeToFile(complexRequestDTO.getTestOutputFileLocation(), complexRequestDTO.getResponse());
  }
  
  public void cleanResponseContainer(ComplexRequestDTO complexRequestDTO) throws Exception {
    if ("NONE".equalsIgnoreCase(complexRequestDTO.getCorrelationType())) {
      log.info(" JMS queue " + complexRequestDTO.getResponseQueueName() + " is getting purged for a Test Case ");
      purgeMessage(complexRequestDTO);
    } 
  }
  
  public void synchCall(ComplexRequestDTO complexRequestDTO) throws Exception {
    log.info("JMS Synch Call");
    cleanResponseContainer(complexRequestDTO);
    put(complexRequestDTO);
    get(complexRequestDTO);
  }
  
  public String getMessage(ComplexRequestDTO complexRequestDTO) throws Exception {
    log.info("JMS getMessage()");
    Connection myConn = null;
    Session mySess = null;
    MessageConsumer consumer = null;
    String filter = null;
    try {
      String MYCF_LOOKUP_NAME = complexRequestDTO.getReplyToConnectionFactory();
      String MYQUEUE_LOOKUP_NAME = complexRequestDTO.getResponseQueueName();
      log.info(" Trying to get message from CF " + MYCF_LOOKUP_NAME + " and Q " + MYQUEUE_LOOKUP_NAME);
      Context ctx = null;
      Hashtable<Object, Object> env = new Hashtable<Object, Object>();
      env.put("java.naming.factory.initial", complexRequestDTO.getJmsConetxFactory());
      env.put("java.naming.provider.url", complexRequestDTO.getJmsProviderURL());
      ctx = new InitialContext(env);
      ConnectionFactory myConnFactory = (ConnectionFactory)ctx.lookup(MYCF_LOOKUP_NAME);
      Queue myQueue = (Queue)ctx.lookup(MYQUEUE_LOOKUP_NAME);
      myConn = myConnFactory.createConnection();
      mySess = myConn.createSession(false, 1);
      if ("CORRELATIONID".equalsIgnoreCase(complexRequestDTO.getCorrelationType())) {
        System.out.println("Setting correlation Type CorrelationId");
        filter = "JMSCorrelationID = '" + complexRequestDTO.getJmsCorrelationId() + "'";
        consumer = mySess.createConsumer((Destination)myQueue, filter);
        log.info("Applied filter to lookup by JMSCorrelationID");
      } else if ("MESSAGEID".equalsIgnoreCase(complexRequestDTO.getCorrelationType())) {
        System.out.println("Setting correlation Type MessageId");
        filter = "JMSMessageID = '" + complexRequestDTO.getJmsMessageId() + "'";
        consumer = mySess.createConsumer((Destination)myQueue, filter);
        log.info("Applied filter to lookup by JMSMessageID");
      } else {
        consumer = mySess.createConsumer((Destination)myQueue);
      } 
      myConn.start();
      Message msg = consumer.receive(complexRequestDTO.getWaitInterval());
      String readMsg = null;
      if (msg != null) {
        log.info(" Msg obrained of type " + msg.getClass());
        log.debug(msg);
        if (!(msg instanceof TextMessage) && !(msg instanceof BytesMessage))
          throw new RuntimeException("Expected a TextMessage or ByteMessage"); 
        if (msg instanceof TextMessage) {
          TextMessage tm = (TextMessage)msg;
          readMsg = tm.getText();
          log.info(" correlation Id in received message " + tm.getJMSCorrelationID());
          log.info(" Message Id in received message " + tm.getJMSMessageID());
        } else {
          BytesMessage bm = (BytesMessage)msg;
          byte[] byteArr = new byte[(int)bm.getBodyLength()];
          bm.readBytes(byteArr);
          readMsg = new String(byteArr, complexRequestDTO.getJmsByteMessageEncoding());
          log.info(" correlation Id in received message " + bm.getJMSCorrelationID());
          log.info(" Message Id in received message " + bm.getJMSMessageID());
        } 
        log.info(" Message read as String ");
        return readMsg;
      } 
      throw new Exception("No message received in queue " + complexRequestDTO.getResponseQueueName());
    } finally {
      if (mySess != null)
        mySess.close(); 
      if (myConn != null)
        myConn.close(); 
    } 
  }
  
  TextMessage tm = null;
  
  public String getMessageWithListener(ComplexRequestDTO complexRequestDTO) throws Exception {
    Connection myConn = null;
    Session mySess = null;
    try {
      String MYCF_LOOKUP_NAME = complexRequestDTO.getReplyToConnectionFactory();
      String MYQUEUE_LOOKUP_NAME = complexRequestDTO.getResponseQueueName();
      Context ctx = null;
      Hashtable<Object, Object> env = new Hashtable<Object, Object>();
      env.put("java.naming.factory.initial", complexRequestDTO.getJmsConetxFactory());
      env.put("java.naming.provider.url", complexRequestDTO.getJmsProviderURL());
      ctx = new InitialContext(env);
      ConnectionFactory myConnFactory = (ConnectionFactory)ctx.lookup(MYCF_LOOKUP_NAME);
      Queue myQueue = (Queue)ctx.lookup(MYQUEUE_LOOKUP_NAME);
      myConn = myConnFactory.createConnection();
      mySess = myConn.createSession(false, 1);
      MessageConsumer consumer = mySess.createConsumer((Destination)myQueue);
      consumer.setMessageListener(new MessageListener() {
            public void onMessage(Message msg) {
              try {
                if (!(msg instanceof TextMessage))
                  throw new RuntimeException("no text message"); 
                JMSClient.this.tm = (TextMessage)msg;
                System.out.println(JMSClient.this.tm.getText());
              } catch (JMSException e) {
                System.err.println("Error reading message");
              } 
            }
          });
      myConn.start();
      Thread.sleep(complexRequestDTO.getWaitInterval());
      return this.tm.getText();
    } finally {
      if (mySess != null)
        mySess.close(); 
      if (myConn != null)
        myConn.close(); 
    } 
  }
  
  public void purgeMessage(ComplexRequestDTO complexRequestDTO) throws Exception {
    log.info("Purging queue");
    Connection myConn = null;
    Session mySess = null;
    MessageConsumer consumer = null;
    String filter = null;
    try {
      String MYCF_LOOKUP_NAME = complexRequestDTO.getReplyToConnectionFactory();
      String MYQUEUE_LOOKUP_NAME = complexRequestDTO.getResponseQueueName();
      Context ctx = null;
      Hashtable<Object, Object> env = new Hashtable<Object, Object>();
      env.put("java.naming.factory.initial", complexRequestDTO.getJmsConetxFactory());
      env.put("java.naming.provider.url", complexRequestDTO.getJmsProviderURL());
      ctx = new InitialContext(env);
      ConnectionFactory myConnFactory = (ConnectionFactory)ctx.lookup(MYCF_LOOKUP_NAME);
      Queue myQueue = (Queue)ctx.lookup(MYQUEUE_LOOKUP_NAME);
      myConn = myConnFactory.createConnection();
      mySess = myConn.createSession(false, 1);
      consumer = mySess.createConsumer((Destination)myQueue);
      myConn.start();
      Message msg = null;
      do {
        msg = consumer.receiveNoWait();
        if (msg == null)
          continue; 
        msg.acknowledge();
      } while (msg != null);
    } finally {
      if (mySess != null)
        mySess.close(); 
      if (myConn != null)
        myConn.close(); 
    } 
  }
}
