package com.cts.integration.util;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPFile;

public class FileUtil {
  public static String readFileAsString(String path) throws Exception {
    FileReader fr = null;
    BufferedReader bufferedReader = null;
    try {
      StringBuffer requestFileContents = new StringBuffer();
      fr = new FileReader(path);
      bufferedReader = new BufferedReader(fr);
      String line = null;
      while ((line = bufferedReader.readLine()) != null)
        requestFileContents.append(line); 
      return requestFileContents.toString();
    } finally {
      if (fr != null)
        fr.close(); 
      if (bufferedReader != null)
        bufferedReader.close(); 
    } 
  }
  
  public static void writeToFile(String path, String content) throws Exception {
    FileOutputStream fos = null;
    OutputStreamWriter osw = null;
    try {
      File responseFile = new File(path);
      responseFile.createNewFile();
      fos = new FileOutputStream(responseFile);
      osw = new OutputStreamWriter(fos);
      osw.write(content);
      osw.flush();
      fos.flush();
    } finally {
      if (osw != null)
        osw.close(); 
      if (fos != null)
        fos.close(); 
    } 
  }
  
  public static void ftpPut(String host, int port, String user, String password, String localPath, String remotePath, String format) throws Exception {
    FTPClient ftpClient = new FTPClient();
    InputStream inputStream = null;
    try {
      ftpClient.connect(host, port);
      ftpClient.login(user, password);
      ftpClient.enterLocalPassiveMode();
      ftpClient.setFileType(getFTPFileTypeByformat(format));
      File file = new File(localPath);
      inputStream = new FileInputStream(file);
      boolean done = ftpClient.storeFile(remotePath, inputStream);
      inputStream.close();
    } finally {
      if (inputStream != null)
        inputStream.close(); 
      if (ftpClient != null && ftpClient.isConnected()) {
        ftpClient.logout();
        ftpClient.disconnect();
      } 
    } 
  }
  
  public static boolean ftpGet(String host, int port, String user, String password, String localPath, String remotePath, String format) throws Exception {
    FTPClient ftpClient = new FTPClient();
    OutputStream outputStream = null;
    try {
      ftpClient.connect(host, port);
      ftpClient.login(user, password);
      ftpClient.enterLocalPassiveMode();
      ftpClient.setFileType(getFTPFileTypeByformat(format));
      File downloadFile1 = new File(localPath);
      outputStream = new BufferedOutputStream(new FileOutputStream(downloadFile1));
      boolean success = ftpClient.retrieveFile(remotePath, outputStream);
      if (success)
        System.out.println("File " + remotePath + " has been downloaded successfully."); 
      return success;
    } finally {
      if (outputStream != null)
        outputStream.close(); 
      if (ftpClient != null && ftpClient.isConnected()) {
        ftpClient.logout();
        ftpClient.disconnect();
      } 
    } 
  }
  
  public static boolean ftpdelete(String host, int port, String user, String password, String remotePath, String format) throws Exception {
    FTPClient ftpClient = new FTPClient();
    try {
      ftpClient.connect(host, port);
      ftpClient.login(user, password);
      ftpClient.enterLocalPassiveMode();
      ftpClient.setFileType(getFTPFileTypeByformat(format));
      boolean success = ftpClient.deleteFile(remotePath);
      if (success)
        System.out.println("File " + remotePath + " has been deleted successfully."); 
      return success;
    } finally {
      if (ftpClient != null && ftpClient.isConnected()) {
        ftpClient.logout();
        ftpClient.disconnect();
      } 
    } 
  }
  
  public static int getFTPFileTypeByformat(String format) {
    Map<String, Integer> FTPfileTypes = new HashMap<String, Integer>();
    FTPfileTypes.put("txt", new Integer(0));
    FTPfileTypes.put("json", new Integer(0));
    FTPfileTypes.put("json", new Integer(0));
    return (FTPfileTypes.get(format) != null) ? ((Integer)FTPfileTypes.get(format)).intValue() : 0;
  }
  
  public static void purgeDirectory(File dir) {
    if (dir.isDirectory()) {
      byte b;
      int i;
      File[] arrayOfFile;
      for (i = (arrayOfFile = dir.listFiles()).length, b = 0; b < i; ) {
        File file = arrayOfFile[b];
        if (file.isDirectory())
          purgeDirectory(file); 
        file.delete();
        b++;
      } 
    } 
  }
  
  public static void purgeDirectoryskipSubDir(File dir) {
    if (dir.isDirectory()) {
      byte b;
      int i;
      File[] arrayOfFile;
      for (i = (arrayOfFile = dir.listFiles()).length, b = 0; b < i; ) {
        File file = arrayOfFile[b];
        if (!file.isDirectory())
          file.delete(); 
        b++;
      } 
    } 
  }
  
  public static void purgeAndArchiveDirectorySkipSubDir(File dir) throws Exception {
    if (dir.isDirectory()) {
      String archiveDir = String.valueOf(dir.getAbsolutePath()) + File.separator + "IJunitArchive";
      File newDir = new File(archiveDir);
      if (!newDir.exists() || (newDir.exists() && !newDir.isDirectory()))
        newDir.mkdir(); 
      byte b;
      int i;
      File[] arrayOfFile;
      for (i = (arrayOfFile = dir.listFiles()).length, b = 0; b < i; ) {
        File file = arrayOfFile[b];
        if (!file.isDirectory()) {
          String fileContent = readFileAsString(file.getAbsolutePath());
          String newPath = String.valueOf(archiveDir) + File.separator + file.getName();
          writeToFile(newPath, fileContent);
          file.delete();
        } 
        b++;
      } 
    } 
  }
  
  public static String getLatestMatchingFileAfter(String fileLocation, long testExecutionTime) throws Exception {
    int lastInd = fileLocation.lastIndexOf(File.separator);
    String dir = fileLocation.substring(0, lastInd);
    String fileName = fileLocation.substring(lastInd + 1);
    File folder = new File(dir);
    String absolutePath = null;
    byte b;
    int i;
    File[] arrayOfFile;
    for (i = (arrayOfFile = folder.listFiles()).length, b = 0; b < i; ) {
      File file = arrayOfFile[b];
      if (CommonUtil.regexMatch(file.getName(), fileName) && file.lastModified() > testExecutionTime) {
        absolutePath = file.getAbsolutePath();
        testExecutionTime = file.lastModified();
      } 
      b++;
    } 
    return absolutePath;
  }
  
  public static String getLatestMatchingFileAfter(String dir, String fileName, long testExecutionTime) throws Exception {
    File folder = new File(dir);
    String absolutePath = null;
    byte b;
    int i;
    File[] arrayOfFile;
    for (i = (arrayOfFile = folder.listFiles()).length, b = 0; b < i; ) {
      File file = arrayOfFile[b];
      if (CommonUtil.regexMatch(file.getName(), fileName) && file.lastModified() > testExecutionTime) {
        absolutePath = file.getAbsolutePath();
        testExecutionTime = file.lastModified();
      } 
      b++;
    } 
    return absolutePath;
  }
  
  public static String getLatestMatchingFile(String fileLocation) throws Exception {
    int lastInd = fileLocation.lastIndexOf(File.separator);
    String dir = fileLocation.substring(0, lastInd);
    String fileName = fileLocation.substring(lastInd + 1);
    File folder = new File(dir);
    String absolutePath = null;
    long lastModified = 0L;
    byte b;
    int i;
    File[] arrayOfFile;
    for (i = (arrayOfFile = folder.listFiles()).length, b = 0; b < i; ) {
      File file = arrayOfFile[b];
      if (CommonUtil.regexMatch(file.getName(), fileName) && file.lastModified() > lastModified) {
        absolutePath = file.getAbsolutePath();
        lastModified = file.lastModified();
      } 
      b++;
    } 
    return absolutePath;
  }
  
  public static String getLatestMatchingFile(String dir, String fileName) throws Exception {
    File folder = new File(dir);
    String absolutePath = null;
    long lastModified = 0L;
    byte b;
    int i;
    File[] arrayOfFile;
    for (i = (arrayOfFile = folder.listFiles()).length, b = 0; b < i; ) {
      File file = arrayOfFile[b];
      if (CommonUtil.regexMatch(file.getName(), fileName) && file.lastModified() > lastModified) {
        absolutePath = file.getAbsolutePath();
        lastModified = file.lastModified();
      } 
      b++;
    } 
    return absolutePath;
  }
  
  public static String getLatestMatchingFileWithExtension(String fileLocation) throws Exception {
    int lastInd = fileLocation.lastIndexOf(File.separator);
    String dir = fileLocation.substring(0, lastInd);
    String fileName = fileLocation.substring(lastInd + 1);
    File folder = new File(dir);
    String absolutePath = null;
    long lastModified = 0L;
    byte b;
    int i;
    File[] arrayOfFile;
    for (i = (arrayOfFile = folder.listFiles()).length, b = 0; b < i; ) {
      File file = arrayOfFile[b];
      if (file.getName().startsWith(String.valueOf(fileName) + ".") && !file.getName().endsWith("properties") && file.lastModified() > lastModified) {
        absolutePath = file.getAbsolutePath();
        lastModified = file.lastModified();
      } 
      b++;
    } 
    return absolutePath;
  }
  
  public static String confirmAbsoluteInputFileName(String filePath) throws Exception {
    File inputFile = new File(filePath);
    if (inputFile.exists())
      return filePath; 
    return getLatestMatchingFileWithExtension(filePath);
  }
  
  public static String getLatestMatchingFTPFileAfter(String remoteFileLocation, Calendar executionTimeStamp, String host, int port, String userName, String password) throws Exception {
    System.out.println("Gettign matching file from ftp after intitation of Test");
    FTPClient ftpClient = new FTPClient();
    ftpClient.connect(host, port);
    ftpClient.login(userName, password);
    String absolutePath = null;
    int lastInd = remoteFileLocation.lastIndexOf(File.separator);
    String dir = null;
    String fileName = null;
    FTPFile[] files = (FTPFile[])null;
    if (lastInd >= 0) {
      dir = remoteFileLocation.substring(0, lastInd + 1);
      fileName = remoteFileLocation.substring(lastInd + 1);
      files = ftpClient.listFiles(dir);
    } else {
      files = ftpClient.listFiles();
    } 
    String name = null;
    byte b;
    int i;
    FTPFile[] arrayOfFTPFile1;
    for (i = (arrayOfFTPFile1 = files).length, b = 0; b < i; ) {
      FTPFile file = arrayOfFTPFile1[b];
      if (CommonUtil.regexMatch(file.getName(), fileName) && file.getTimestamp().after(executionTimeStamp)) {
        name = file.getName();
        executionTimeStamp = file.getTimestamp();
      } 
      b++;
    } 
    if (name == null || dir == null)
      return name; 
    return String.valueOf(dir) + name;
  }
  
  public static String getLatestMatchingFTPFileAfter(String remoteDir, String remoteFileName, Calendar executionTimeStamp, String host, int port, String userName, String password) throws Exception {
    System.out.println("Gettign matching file from ftp after intitation of Test");
    FTPClient ftpClient = new FTPClient();
    ftpClient.connect(host, port);
    ftpClient.login(userName, password);
    String absolutePath = null;
    FTPFile[] files = (FTPFile[])null;
    if (remoteDir != null && remoteDir.trim().length() > 0) {
      files = ftpClient.listFiles(remoteDir);
    } else {
      files = ftpClient.listFiles();
    } 
    String name = null;
    byte b;
    int i;
    FTPFile[] arrayOfFTPFile1;
    for (i = (arrayOfFTPFile1 = files).length, b = 0; b < i; ) {
      FTPFile file = arrayOfFTPFile1[b];
      if (CommonUtil.regexMatch(file.getName(), remoteFileName) && file.getTimestamp().after(executionTimeStamp)) {
        name = file.getName();
        executionTimeStamp = file.getTimestamp();
      } 
      b++;
    } 
    if (name == null || remoteDir == null)
      return name; 
    return String.valueOf(remoteDir) + name;
  }
  
  public static String getLatestMatchingFTPFile(String remoteFileLocation, String host, int port, String userName, String password) throws Exception {
    System.out.println("Gettign matching file from ftp");
    FTPClient ftpClient = new FTPClient();
    ftpClient.connect(host, port);
    ftpClient.login(userName, password);
    String absolutePath = null;
    Calendar executionTimeStamp = null;
    int lastInd = remoteFileLocation.lastIndexOf(File.separator);
    String dir = null;
    String fileName = null;
    FTPFile[] files = (FTPFile[])null;
    if (lastInd >= 0) {
      dir = remoteFileLocation.substring(0, lastInd + 1);
      fileName = remoteFileLocation.substring(lastInd + 1);
      files = ftpClient.listFiles(dir);
    } else {
      files = ftpClient.listFiles();
    } 
    String name = null;
    byte b;
    int i;
    FTPFile[] arrayOfFTPFile1;
    for (i = (arrayOfFTPFile1 = files).length, b = 0; b < i; ) {
      FTPFile file = arrayOfFTPFile1[b];
      if (CommonUtil.regexMatch(file.getName(), fileName) && (
        executionTimeStamp == null || file.getTimestamp().after(executionTimeStamp))) {
        name = file.getName();
        executionTimeStamp = file.getTimestamp();
      } 
      b++;
    } 
    if (name == null || dir == null)
      return name; 
    return String.valueOf(dir) + name;
  }
  
  public static String getLatestMatchingFTPFile(String remoteDir, String remoteFileName, String host, int port, String userName, String password) throws Exception {
    System.out.println("Gettign matching file from ftp");
    FTPClient ftpClient = new FTPClient();
    ftpClient.connect(host, port);
    ftpClient.login(userName, password);
    String absolutePath = null;
    Calendar executionTimeStamp = null;
    FTPFile[] files = (FTPFile[])null;
    if (remoteDir != null && remoteDir.trim().length() > 0) {
      files = ftpClient.listFiles(remoteDir);
    } else {
      files = ftpClient.listFiles();
    } 
    String name = null;
    byte b;
    int i;
    FTPFile[] arrayOfFTPFile1;
    for (i = (arrayOfFTPFile1 = files).length, b = 0; b < i; ) {
      FTPFile file = arrayOfFTPFile1[b];
      if (CommonUtil.regexMatch(file.getName(), remoteFileName) && (
        executionTimeStamp == null || file.getTimestamp().after(executionTimeStamp))) {
        name = file.getName();
        executionTimeStamp = file.getTimestamp();
      } 
      b++;
    } 
    if (name == null || remoteDir == null)
      return name; 
    return String.valueOf(remoteDir) + name;
  }
  
  public static void deleteMatchingFTPFile(String remoteFileLocation, String host, int port, String userName, String password) throws Exception {
    System.out.println("deleting matching file from ftp");
    FTPClient ftpClient = new FTPClient();
    ftpClient.connect(host, port);
    ftpClient.login(userName, password);
    String absolutePath = null;
    int lastInd = remoteFileLocation.lastIndexOf(File.separator);
    String dir = null;
    String fileName = null;
    FTPFile[] files = (FTPFile[])null;
    if (lastInd >= 0) {
      dir = remoteFileLocation.substring(0, lastInd + 1);
      fileName = remoteFileLocation.substring(lastInd + 1);
      files = ftpClient.listFiles(dir);
    } else {
      files = ftpClient.listFiles();
    } 
    String name = null;
    byte b;
    int i;
    FTPFile[] arrayOfFTPFile1;
    for (i = (arrayOfFTPFile1 = files).length, b = 0; b < i; ) {
      FTPFile file = arrayOfFTPFile1[b];
      if (CommonUtil.regexMatch(file.getName(), fileName))
        ftpClient.deleteFile(String.valueOf(dir) + file.getName()); 
      b++;
    } 
  }
  
  public static void deleteMatchingFTPFile(String remoteDir, String remoteFileName, String host, int port, String userName, String password) throws Exception {
    System.out.println("deleting matching file from ftp");
    FTPClient ftpClient = new FTPClient();
    ftpClient.connect(host, port);
    ftpClient.login(userName, password);
    String absolutePath = null;
    FTPFile[] files = (FTPFile[])null;
    if (remoteDir != null && remoteDir.trim().length() > 0) {
      files = ftpClient.listFiles(remoteDir);
    } else {
      files = ftpClient.listFiles();
    } 
    String name = null;
    byte b;
    int i;
    FTPFile[] arrayOfFTPFile1;
    for (i = (arrayOfFTPFile1 = files).length, b = 0; b < i; ) {
      FTPFile file = arrayOfFTPFile1[b];
      if (CommonUtil.regexMatch(file.getName(), remoteFileName))
        ftpClient.deleteFile(String.valueOf(remoteDir) + file.getName()); 
      b++;
    } 
  }
  
  public static String getMessageIfFileExists(String fileLocation) throws Exception {
    String message = null;
    String absoluteFileLocation = confirmAbsoluteInputFileName(fileLocation);
    if (absoluteFileLocation != null) {
      File file = new File(absoluteFileLocation);
      if (file.exists())
        message = readFileAsString(absoluteFileLocation); 
    } 
    return message;
  }
}
