package com.cts.integration.unitTest.testCase;

import java.io.File;
import java.io.FileInputStream;
import java.util.Properties;

import org.apache.log4j.Logger;

import junit.framework.TestCase;

import com.cts.integration.assertion.IJunitAssertion;
import com.cts.integration.dto.ComplexRequestDTO;
import com.cts.integration.dto.IJunitTestCase;
import com.cts.integration.factory.AssertionFactory;
import com.cts.integration.factory.ClientFactory;
import com.cts.integration.unitTest.client.IJunitClient;
import com.cts.integration.util.ExcelUtil;
import com.cts.integration.util.FileUtil;


import com.cts.integration.dto.TestCaseDTO;
import junit.framework.TestCase;
import org.apache.log4j.Logger;

public class GenericTestCase extends TestCase {
  static Logger log = Logger.getLogger(GenericTestCase.class.getName());
  
  TestCaseDTO testCase;
  
  public GenericTestCase(String testName, TestCaseDTO testCase) {
    super(testName);
    this.testCase = testCase;
  }
	public void test() throws Exception{
		log.info("Executing Asynch Test");
		FileInputStream inputPropInputStream = null;
		FileInputStream outputPropInputStream = null;
		String expectdResponse = null;
		
		try{
			ComplexRequestDTO requestDTO = new ComplexRequestDTO();
			ComplexRequestDTO responseDTO = new ComplexRequestDTO();
			ComplexRequestDTO legacyRequestDTO = null;
			ComplexRequestDTO legacyResponseDTO = null;
			
			
  	        //String sourceInfo = IJunitTestCase.testCase.getSourceInfo();
  	        //String targetInfo = IJunitTestCase.testCase.getTargetInfo();
			String sourceInfo = testCase.getSourceInfo();
			String targetInfo = testCase.getTargetInfo();
			
  	        File inputPropertiesFile = new File(sourceInfo);
	        Properties inputProperties = new Properties();
	        if(inputPropertiesFile.exists()){
	        	log.info("loading source properties file");
	        	inputPropInputStream = new FileInputStream(inputPropertiesFile);
	        	inputProperties.load(inputPropInputStream);
	        }
	        
	        File outputPropertiesFile = new File(targetInfo);
	        Properties outputProperties = new Properties();
	        if(outputPropertiesFile.exists()){
	        	log.info("loading target properties file");
	        	outputPropInputStream = new FileInputStream(outputPropertiesFile);
	        	outputProperties.load(outputPropInputStream);
	        }
	        
	        //prepare request and response
	        requestDTO.setActualValueFromProperties(inputProperties);
	        //requestDTO.setActualValuesFromTestCase(IJunitTestCase.testCase);
	        requestDTO.setActualValuesFromTestCase(testCase);
	        responseDTO.setActualValueFromProperties(outputProperties);
	        //responseDTO.setActualValuesFromTestCase(IJunitTestCase.testCase);
	        responseDTO.setActualValuesFromTestCase(testCase);
	        
	        //get client from facotry
	        //IJunitClient client = ClientFactory.getClient(IJunitTestCase.testCase.getSourceProtocol());
	        IJunitClient client = ClientFactory.getClient(testCase.getSourceProtocol());
	        log.info("Got source Client "+client);
	        //IJunitClient responseClient = ClientFactory.getClient(IJunitTestCase.testCase.getTargetProtocol());
	        IJunitClient responseClient = ClientFactory.getClient(testCase.getTargetProtocol());
	        log.info("Got target Client "+responseClient);
	        //clean any inputQueue/directory prior to Test
	        responseClient.cleanResponseContainer(responseDTO);
	        log.info("Target Cleaned before execution of test");
	        long putTime = System.currentTimeMillis();
	        
	        //invoke Test
	        client.put(requestDTO);
	        log.info("Request Put in source");
	        
	        //set parameters for response
	        responseDTO.setMessageId(requestDTO.getMessageId());
	        responseDTO.setJmsMessageId(requestDTO.getJmsMessageId());
	        responseDTO.setJmsCorrelationId(requestDTO.getJmsCorrelationId());
	        responseDTO.setRequestTimeInMS(putTime);
	        
	        //get response
	        responseClient.get(responseDTO);
	        log.info("Got Response from Target");
	        //check for legacy mode/comparison mode
	        //String asIsURL = IJunitTestCase.testCase.getLegacyEndPont();
	        String asIsURL = testCase.getLegacyEndPont();
	        if(
	        		(inputProperties.getProperty("LEGACY")!=null 
	        		&& "TRUE".equalsIgnoreCase(inputProperties.getProperty("LEGACY").trim())
	        		)
	        		||
	        		(asIsURL!=null && asIsURL.trim().length()>0)
	        		){
  	        	
	        	log.info("Retrieving expected response from Legacy(As-is)");
  	        	legacyRequestDTO = new ComplexRequestDTO();
  				legacyResponseDTO = new ComplexRequestDTO();
  				
  				 //prepare legacy request and response
  				legacyRequestDTO.setLegacyValueFromProperties(inputProperties);
  				//legacyRequestDTO.setLegacyValuesFromTestCase(IJunitTestCase.testCase);
  				legacyRequestDTO.setLegacyValuesFromTestCase(testCase);
  				legacyResponseDTO.setLegacyValueFromProperties(outputProperties);
  				//legacyResponseDTO.setLegacyValuesFromTestCase(IJunitTestCase.testCase);
  				legacyResponseDTO.setLegacyValuesFromTestCase(testCase);
  				
  				responseClient.cleanResponseContainer(legacyResponseDTO);
  				log.info("Legacy Target Cleaned before execution of test");
  		        long putLegacyTime = System.currentTimeMillis();
  		        
  		        //invoke legacy Test
  		        client.put(legacyRequestDTO);
  		        log.info("Message put to Legacy Source");
  		        
  		        //set parameters for legacy response
  		        legacyResponseDTO.setMessageId(legacyRequestDTO.getMessageId());
  		        legacyResponseDTO.setJmsMessageId(legacyRequestDTO.getJmsMessageId());
  		        legacyResponseDTO.setJmsCorrelationId(legacyRequestDTO.getJmsCorrelationId());
  		        legacyResponseDTO.setRequestTimeInMS(putLegacyTime);
  		        
  		        //get legacy response
  		        responseClient.get(legacyResponseDTO);
  		        log.info("Got Legacy response from Target");
  		        expectdResponse = legacyResponseDTO.getResponse();
  	        }else{
  	        	//String expectdPath = FileUtil.confirmAbsoluteInputFileName(IJunitTestCase.testCase.getExpectedOutput());
  	        	String expectdPath = FileUtil.confirmAbsoluteInputFileName(testCase.getExpectedOutput());
  	        	expectdResponse = FileUtil.readFileAsString(expectdPath);
  	        	log.info("Retrieved Expected response from Test Case configuration");
  	        }
	        
	        //IJunitAssertion assertion = AssertionFactory.getAssertion(IJunitTestCase.testCase.getTargetFormat());
	        IJunitAssertion assertion = AssertionFactory.getAssertion(testCase.getTargetFormat());
	        log.info("Got assertion object "+assertion);
	        if(assertion != null){
	        	//assertion.assertEquals(expectdResponse, responseDTO.getResponse(),IJunitTestCase.testCase.getIgnoreList());
	        	assertion.assertEquals(expectdResponse, responseDTO.getResponse(),testCase.getIgnoreList());
	        }else{
	        	log.info("Performing Default Assertion");
	        	assertEquals(expectdResponse, responseDTO.getResponse());
	        }
	        
	        
		}catch(Exception e){
			e.printStackTrace();
			throw e;
		}finally{
			if(inputPropInputStream != null){
				inputPropInputStream.close();
			}
			if(outputPropInputStream != null){
				outputPropInputStream.close();
			}
		}
	}
}
