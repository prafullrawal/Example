package com.cts.integration.factory;

import com.cts.integration.assertion.IJUnitJSONAssertion;
import com.cts.integration.assertion.IJunitAssertion;
import com.cts.integration.assertion.IJunitXMLAssertion;

public class AssertionFactory {
  public static IJunitAssertion getAssertion(String format) {
    if ("xml".equalsIgnoreCase(format))
      return (IJunitAssertion)new IJunitXMLAssertion(); 
    if ("json".equalsIgnoreCase(format))
      return (IJunitAssertion)new IJUnitJSONAssertion(); 
    return null;
  }
}
