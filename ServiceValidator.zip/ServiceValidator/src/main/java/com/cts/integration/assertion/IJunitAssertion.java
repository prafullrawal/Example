package com.cts.integration.assertion;

import java.util.List;

public interface IJunitAssertion {
  void assertEquals(Object paramObject1, Object paramObject2, List<String> paramList) throws Exception;
}
