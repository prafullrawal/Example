package com.cts.integration.dto;

public class RequestDTO {
  String serviceURL;
  
  String requestPath;
  
  boolean secured;
  
  String securityType;
  
  String certPath;
  
  String keystoreType;
  
  String keystorePass;
  
  String userName;
  
  String password;
  
  String method;
  
  String authorization ;
  
  public static final String SECURITY_TYPE_CERT = "CERT";
  
  public static final String SECURITY_TYPE_BASIC = "BASIC";
  
  public String getMethod() {
    return this.method;
  }
  
  public void setMethod(String method) {
    this.method = method;
  }
  
  public String getServiceURL() {
    return this.serviceURL;
  }
  
  public void setServiceURL(String serviceURL) {
    this.serviceURL = serviceURL;
  }
  
  public String getRequestPath() {
    return this.requestPath;
  }
  
  public void setRequestPath(String requestPath) {
    this.requestPath = requestPath;
  }
  
  public boolean isSecured() {
    return this.secured;
  }
  
  public void setSecured(boolean secured) {
    this.secured = secured;
  }
  
  public String getSecurityType() {
    return this.securityType;
  }
  
  public void setSecurityType(String securityType) {
    this.securityType = securityType;
  }
  
  public String getCertPath() {
    return this.certPath;
  }
  
  public void setCertPath(String certPath) {
    this.certPath = certPath;
  }
  
  public String getUserName() {
    return this.userName;
  }
  
  public void setUserName(String userName) {
    this.userName = userName;
  }
  
  public String getPassword() {
    return this.password;
  }
  
  public void setPassword(String password) {
    this.password = password;
  }
  
  public String getKeystoreType() {
    return this.keystoreType;
  }
  
  public void setKeystoreType(String keystoreType) {
    this.keystoreType = keystoreType;
  }
  
  public String getKeystorePass() {
    return this.keystorePass;
  }
  
  public void setKeystorePass(String keystorePass) {
    this.keystorePass = keystorePass;
  }

public String getAuthorization() {
	return authorization;
}

public void setAuthorization(String authorization) {
	this.authorization = authorization;
}
}
