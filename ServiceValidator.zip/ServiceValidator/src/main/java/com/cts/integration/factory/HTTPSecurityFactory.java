package com.cts.integration.factory;

import com.cts.integration.security.HTTPBasicAuthSecurity;
import com.cts.integration.security.HTTPCertSecurity;
import com.cts.integration.security.IHTTPSecurity;

public class HTTPSecurityFactory {
  public static IHTTPSecurity getHTTPSecurityByType(String securityType) {
    if ("BASIC".equalsIgnoreCase(securityType))
      return (IHTTPSecurity)new HTTPBasicAuthSecurity(); 
    if ("CERT".equalsIgnoreCase(securityType))
      return (IHTTPSecurity)new HTTPCertSecurity(); 
    return null;
  }
}
