package com.cts.integration.dto;

import java.util.Properties;

public class MQRequestDTO {
  String host;
  
  int port = 1414;
  
  String channel;
  
  String replyHost;
  
  int replyPort = 1414;
  
  String replyChannel;
  
  String queueManagerName;
  
  String replyToQueueManager;
  
  String requestQueueName;
  
  String responseQueueName;
  
  String message;
  
  String correlationType;
  
  int waitInterval = 60000;
  
  public String getHost() {
    return this.host;
  }
  
  public void setHost(String host) {
    this.host = host;
  }
  
  public int getPort() {
    return this.port;
  }
  
  public void setPort(int port) {
    this.port = port;
  }
  
  public String getChannel() {
    return this.channel;
  }
  
  public void setChannel(String channel) {
    this.channel = channel;
  }
  
  public String getQueueManagerName() {
    return this.queueManagerName;
  }
  
  public void setQueueManagerName(String queueManagerName) {
    this.queueManagerName = queueManagerName;
  }
  
  public String getReplyToQueueManager() {
    return this.replyToQueueManager;
  }
  
  public void setReplyToQueueManager(String replyToQueueManager) {
    this.replyToQueueManager = replyToQueueManager;
  }
  
  public String getRequestQueueName() {
    return this.requestQueueName;
  }
  
  public void setRequestQueueName(String requestQueueName) {
    this.requestQueueName = requestQueueName;
  }
  
  public String getResponseQueueName() {
    return this.responseQueueName;
  }
  
  public void setResponseQueueName(String responseQueueName) {
    this.responseQueueName = responseQueueName;
  }
  
  public String getMessage() {
    return this.message;
  }
  
  public void setMessage(String message) {
    this.message = message;
  }
  
  public String getCorrelationType() {
    return this.correlationType;
  }
  
  public void setCorrelationType(String correlationType) {
    this.correlationType = correlationType;
  }
  
  public int getWaitInterval() {
    return this.waitInterval;
  }
  
  public void setWaitInterval(int waitInterval) {
    this.waitInterval = waitInterval;
  }
  
  public String getReplyHost() {
    return this.replyHost;
  }
  
  public void setReplyHost(String replyHost) {
    this.replyHost = replyHost;
  }
  
  public int getReplyPort() {
    return this.replyPort;
  }
  
  public void setReplyPort(int replyPort) {
    this.replyPort = replyPort;
  }
  
  public String getReplyChannel() {
    return this.replyChannel;
  }
  
  public void setReplyChannel(String replyChannel) {
    this.replyChannel = replyChannel;
  }
  
  public void setActualValueFromProperties(Properties mqProperties) {
    this.host = mqProperties.getProperty("host").trim();
    this.port = (mqProperties.getProperty("port") != null && mqProperties.getProperty("port").trim().length() > 0) ? Integer.parseInt(mqProperties.getProperty("port").trim()) : 1414;
    this.channel = (mqProperties.getProperty("channel") != null && mqProperties.getProperty("channel").trim().length() > 0) ? mqProperties.getProperty("channel").trim() : "SYSTEM.DEF.SVRCONN";
    this.replyHost = (mqProperties.getProperty("reply.host") != null && mqProperties.getProperty("reply.host").trim().length() > 0) ? mqProperties.getProperty("reply.host").trim() : this.host;
    this.replyPort = (mqProperties.getProperty("reply.port") != null && mqProperties.getProperty("reply.port").trim().length() > 0) ? Integer.parseInt(mqProperties.getProperty("reply.port").trim()) : this.port;
    this.replyChannel = (mqProperties.getProperty("reply.channel") != null && mqProperties.getProperty("reply.channel").trim().length() > 0) ? mqProperties.getProperty("reply.channel").trim() : this.channel;
    this.queueManagerName = mqProperties.getProperty("queue.manager").trim();
    this.replyToQueueManager = (mqProperties.getProperty("reply.queue.manager") != null && mqProperties.getProperty("reply.queue.manager").trim().length() > 0) ? mqProperties.getProperty("reply.queue.manager").trim() : this.queueManagerName;
    this.requestQueueName = mqProperties.getProperty("request.queue.name").trim();
    this.responseQueueName = mqProperties.getProperty("reply.queue.name").trim();
    this.correlationType = (mqProperties.getProperty("correlation.type") != null && mqProperties.getProperty("correlation.type").trim().length() > 0) ? mqProperties.getProperty("correlation.type").trim() : "CORRELATIONID";
    this.waitInterval = (mqProperties.getProperty("wait.interval") != null && mqProperties.getProperty("wait.interval").trim().length() > 0) ? Integer.parseInt(mqProperties.getProperty("port").trim()) : 60000;
  }
  
  public void setLegacyValueFromProperties(Properties mqProperties) {
    this.host = mqProperties.getProperty("legacy.host").trim();
    this.port = (mqProperties.getProperty("legacy.port") != null && mqProperties.getProperty("legacy.port").trim().length() > 0) ? Integer.parseInt(mqProperties.getProperty("legacy.port").trim()) : 1414;
    this.channel = (mqProperties.getProperty("legacy.channel") != null && mqProperties.getProperty("legacy.channel").trim().length() > 0) ? mqProperties.getProperty("legacy.channel").trim() : "SYSTEM.DEF.SVRCONN";
    this.replyHost = (mqProperties.getProperty("legacy.reply.host") != null && mqProperties.getProperty("legacy.reply.host").trim().length() > 0) ? mqProperties.getProperty("legacy.reply.host").trim() : this.host;
    this.replyPort = (mqProperties.getProperty("legacy.reply.port") != null && mqProperties.getProperty("legacy.reply.port").trim().length() > 0) ? Integer.parseInt(mqProperties.getProperty("legacy.reply.port").trim()) : this.port;
    this.replyChannel = (mqProperties.getProperty("legacy.reply.channel") != null && mqProperties.getProperty("legacy.reply.channel").trim().length() > 0) ? mqProperties.getProperty("legacy.reply.channel").trim() : this.channel;
    this.queueManagerName = mqProperties.getProperty("legacy.queue.manager").trim();
    this.replyToQueueManager = (mqProperties.getProperty("legacy.reply.queue.manager") != null && mqProperties.getProperty("legacy.reply.queue.manager").trim().length() > 0) ? mqProperties.getProperty("legacy.reply.queue.manager").trim() : this.queueManagerName;
    this.requestQueueName = mqProperties.getProperty("legacy.request.queue.name").trim();
    this.responseQueueName = mqProperties.getProperty("legacy.reply.queue.name").trim();
    this.correlationType = (mqProperties.getProperty("legacy.correlation.type") != null && mqProperties.getProperty("correlation.type").trim().length() > 0) ? mqProperties.getProperty("correlation.type").trim() : "CORRELATIONID";
    this.waitInterval = (mqProperties.getProperty("legacy.wait.interval") != null && mqProperties.getProperty("wait.interval").trim().length() > 0) ? Integer.parseInt(mqProperties.getProperty("port").trim()) : 60000;
  }
}
