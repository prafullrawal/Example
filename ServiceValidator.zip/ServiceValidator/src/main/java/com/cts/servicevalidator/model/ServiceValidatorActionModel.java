package com.cts.servicevalidator.model;

import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

//import org.apache.struts2.dispatcher.SessionMap;
import com.cts.integration.dto.IJunitConstants;
import com.cts.integration.dto.TestCaseDTO;

public class ServiceValidatorActionModel {

	private static final long serialVersionUID = 1L;
	private String username;
	private String password;
	private List<TestCaseDTO> testCases = new ArrayList<TestCaseDTO>();
	List<TestCaseDTO> testReports = new ArrayList<TestCaseDTO>();
	private String deletedTestCaseName;
	private List<Boolean> checkLists = new ArrayList<Boolean>();
	private List<String> protocolList = new ArrayList<String>(Arrays.asList("",IJunitConstants.PROTOCOL_DB, IJunitConstants.PROTOCOL_FILE, IJunitConstants.PROTOCOL_FILE_ADVANCED,
			IJunitConstants.PROTOCOL_FTP,IJunitConstants.PROTOCOL_HTTP,IJunitConstants.PROTOCOL_HTTP_GET
			,IJunitConstants.PROTOCOL_HTTP_POST,IJunitConstants.PROTOCOL_JMS,IJunitConstants.PROTOCOL_MQ,IJunitConstants.PROTOCOL_SFTP));
	private List<String> formatList = new ArrayList<String>(Arrays.asList("",IJunitConstants.FORMAT_XML,IJunitConstants.FORMAT_JSON, IJunitConstants.FORMAT_TXT,IJunitConstants.FORMAT_UNKNOWN));
	private List<String> patternList = new ArrayList<String>(Arrays.asList(IJunitConstants.PATTERN_SYNCH,IJunitConstants.PATTERN_ASYNCH));
	private List<String> activeList = new ArrayList<String>(Arrays.asList(IJunitConstants.VALUE_ACTIVE,IJunitConstants.VALUE_INACTIVE));
	private TestCaseDTO newTestCase = new TestCaseDTO();
	String newIgnoreField;
	private boolean added=false;
	List<String> ignoreFields = new ArrayList<String>();
	private String logMessage = new String();
	String profileRoot;
	String csvReportName;
	String xmlReportName;
	String quickReportName;
	String csvReportPath;
	String xmlReportPath;
	String quickReportPath;
	
	String downloadReportName;
	FileInputStream reportInputStream;
	List<String> reportList = new ArrayList<String>();
	//private SessionMap<String,Object> sessionMap;  
	private String infoContent;
	
	
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public List<TestCaseDTO> getTestCases() {
		return testCases;
	}
	public void setTestCases(List<TestCaseDTO> testCases) {
		this.testCases = testCases;
	}
	public List<TestCaseDTO> getTestReports() {
		return testReports;
	}
	public void setTestReports(List<TestCaseDTO> testReports) {
		this.testReports = testReports;
	}
	public String getDeletedTestCaseName() {
		return deletedTestCaseName;
	}
	public void setDeletedTestCaseName(String deletedTestCaseName) {
		this.deletedTestCaseName = deletedTestCaseName;
	}
	public List<Boolean> getCheckLists() {
		return checkLists;
	}
	public void setCheckLists(List<Boolean> checkLists) {
		this.checkLists = checkLists;
	}
	public List<String> getProtocolList() {
		return protocolList;
	}
	public void setProtocolList(List<String> protocolList) {
		this.protocolList = protocolList;
	}
	public List<String> getFormatList() {
		return formatList;
	}
	public void setFormatList(List<String> formatList) {
		this.formatList = formatList;
	}
	public List<String> getPatternList() {
		return patternList;
	}
	public void setPatternList(List<String> patternList) {
		this.patternList = patternList;
	}
	public List<String> getActiveList() {
		return activeList;
	}
	public void setActiveList(List<String> activeList) {
		this.activeList = activeList;
	}
	public TestCaseDTO getNewTestCase() {
		return newTestCase;
	}
	public void setNewTestCase(TestCaseDTO newTestCase) {
		this.newTestCase = newTestCase;
	}
	public String getNewIgnoreField() {
		return newIgnoreField;
	}
	public void setNewIgnoreField(String newIgnoreField) {
		this.newIgnoreField = newIgnoreField;
	}
	public boolean isAdded() {
		return added;
	}
	public void setAdded(boolean added) {
		this.added = added;
	}
	public List<String> getIgnoreFields() {
		return ignoreFields;
	}
	public void setIgnoreFields(List<String> ignoreFields) {
		this.ignoreFields = ignoreFields;
	}
	public String getLogMessage() {
		return logMessage;
	}
	public void setLogMessage(String logMessage) {
		this.logMessage = logMessage;
	}
	public String getProfileRoot() {
		return profileRoot;
	}
	public void setProfileRoot(String profileRoot) {
		this.profileRoot = profileRoot;
	}
	public String getCsvReportName() {
		return csvReportName;
	}
	public void setCsvReportName(String csvReportName) {
		this.csvReportName = csvReportName;
	}
	public String getXmlReportName() {
		return xmlReportName;
	}
	public void setXmlReportName(String xmlReportName) {
		this.xmlReportName = xmlReportName;
	}
	public String getQuickReportName() {
		return quickReportName;
	}
	public void setQuickReportName(String quickReportName) {
		this.quickReportName = quickReportName;
	}
	public String getCsvReportPath() {
		return csvReportPath;
	}
	public void setCsvReportPath(String csvReportPath) {
		this.csvReportPath = csvReportPath;
	}
	public String getXmlReportPath() {
		return xmlReportPath;
	}
	public void setXmlReportPath(String xmlReportPath) {
		this.xmlReportPath = xmlReportPath;
	}
	public String getQuickReportPath() {
		return quickReportPath;
	}
	public void setQuickReportPath(String quickReportPath) {
		this.quickReportPath = quickReportPath;
	}
	public String getDownloadReportName() {
		return downloadReportName;
	}
	public void setDownloadReportName(String downloadReportName) {
		this.downloadReportName = downloadReportName;
	}
	public FileInputStream getReportInputStream() {
		return reportInputStream;
	}
	public void setReportInputStream(FileInputStream reportInputStream) {
		this.reportInputStream = reportInputStream;
	}
	public List<String> getReportList() {
		return reportList;
	}
	public void setReportList(List<String> reportList) {
		this.reportList = reportList;
	}

	/*
	 * public SessionMap<String, Object> getSessionMap() { return sessionMap; }
	 * public void setSessionMap(SessionMap<String, Object> sessionMap) {
	 * this.sessionMap = sessionMap; }
	 */
	public String getInfoContent() {
		return infoContent;
	}
	public void setInfoContent(String infoContent) {
		this.infoContent = infoContent;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
}
