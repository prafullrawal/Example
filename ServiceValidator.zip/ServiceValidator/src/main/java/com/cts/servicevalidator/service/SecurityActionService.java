package com.cts.servicevalidator.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Properties;

//import org.apache.struts2.ServletActionContext;
import org.springframework.stereotype.Service;

import com.cts.servicevalidator.contants.*;
import com.cts.servicevalidator.model.SecurityActionModel;
import com.cts.integration.util.FileUtil;

@Service
public class SecurityActionService {
	
	SecurityActionModel securityActionModel = new SecurityActionModel();

	public String loadSecurityProperties(String username,String testName) {
		
		FileInputStream fis = null;
		
		 try {
			
			
			/*
			 * username = ServletActionContext.getRequest().getParameter("username");
			 * testName = ServletActionContext.getRequest().getParameter("testName");
			 */
			
			 
			securityActionModel.setUsername(username);
			securityActionModel.setTestName(testName);
			
			securityActionModel.setTargetPath(UIConstants.WEBROOT+File.separator+username+File.separator+testName+File.separator+testName+"Security.properties");
			String samplePath=UIConstants.WEBROOT+File.separator+"Security.properties";
			System.out.println("path --"+securityActionModel.getTargetPath());
			File sourcePropertiesFile = new File(securityActionModel.getTargetPath());
			if(!sourcePropertiesFile.exists()){
				sourcePropertiesFile = new File(samplePath);
				securityActionModel.setConfContent(new String(Files.readAllBytes(Paths.get(samplePath)),Charset.defaultCharset()));
				//confContent= FileUtil.readFileAsString(samplePath);
			}else{
				securityActionModel.setConfContent(new String(Files.readAllBytes(Paths.get(securityActionModel.getTargetPath())),Charset.defaultCharset()));
				//confContent= FileUtil.readFileAsString(targetPath);
			}
			
			//confContent=protocolProperties.toString();
	    	return "success";
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			//addActionError("System error "+e.getMessage());
			return "error";
		}finally{
			try {
				if(fis!=null){
					
						fis.close();
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		
	}

	public String saveSecurityProperties() {
		
		FileInputStream fis = null; 
		try {
			
			
			FileUtil.writeToFile(securityActionModel.getTargetPath(), securityActionModel.getConfContent());
			
			String targetDir = UIConstants.WEBROOT+File.separator+securityActionModel.getUsername()+File.separator+securityActionModel.getTestName()+File.separator;
			String certFileName=null;
			System.out.println("CertFile "+securityActionModel.getCertFile());
			if(securityActionModel.getCertFile()!=null){
				fis=new FileInputStream(new File(securityActionModel.getTargetPath()));
				Properties securityProperties= new Properties();
				securityProperties.load(fis);
				
				certFileName=securityProperties.getProperty("CERTNAME");
				System.out.println("certFileName "+certFileName);
				File targetFile = new File(targetDir+certFileName);
				org.apache.commons.io.FileUtils.copyFile(securityActionModel.getCertFile(), targetFile);
			}
			
	    	return "success";
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			//addActionError("System error"+e.getMessage());
			return "error";
		}finally{
			try {
				if(fis!=null){
					fis.close();
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		
	}

	public String reloadSecurityProperties() {
		
		try {
			
			 String samplePath=UIConstants.WEBROOT+File.separator+"Security.properties";
			 System.out.println(" reloading from "+samplePath);
			 securityActionModel.setConfContent(new String(Files.readAllBytes(Paths.get(samplePath)),Charset.defaultCharset()));
			
	    	return "success";
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			//addActionError("System error"+e.getMessage());
			return "error";
		}finally{
			
			
		}
		
	}

}
