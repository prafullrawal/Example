package com.cts.servicevalidator.model;

import java.io.File;

public class HeaderActionModel {

	String confContent;
	String username;
	String testName;
	String targetPath;
	File headerFile;
	
	public String getConfContent() {
		return confContent;
	}
	public void setConfContent(String confContent) {
		this.confContent = confContent;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getTestName() {
		return testName;
	}
	public void setTestName(String testName) {
		this.testName = testName;
	}
	public String getTargetPath() {
		return targetPath;
	}
	public void setTargetPath(String targetPath) {
		this.targetPath = targetPath;
	}
	public File getHeaderFile() {
		return headerFile;
	}
	public void setHeaderFile(File headerFile) {
		this.headerFile = headerFile;
	}
}
