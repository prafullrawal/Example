package com.cts.servicevalidator.model;

public class PropertiesActionModel {

	String confContent;
	String protocol;
	String username;
	String testName;
	String type;
	String targetPath;
	
	public String getConfContent() {
		return confContent;
	}
	public void setConfContent(String confContent) {
		this.confContent = confContent;
	}
	public String getProtocol() {
		return protocol;
	}
	public void setProtocol(String protocol) {
		this.protocol = protocol;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getTestName() {
		return testName;
	}
	public void setTestName(String testName) {
		this.testName = testName;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getTargetPath() {
		return targetPath;
	}
	public void setTargetPath(String targetPath) {
		this.targetPath = targetPath;
	}
	
}
