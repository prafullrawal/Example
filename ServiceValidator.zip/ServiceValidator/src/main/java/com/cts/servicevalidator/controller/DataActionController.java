package com.cts.servicevalidator.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cts.servicevalidator.service.DataActionService;

@Controller
public class DataActionController {
	
	@Autowired
	DataActionService dataActionService; 

	@RequestMapping("/loadData.action")
	public String load(@RequestParam("username") String username, @RequestParam("testCase") String testCase) {
		String result = dataActionService.loadData(username,testCase);
		String forward = "";
		if(result=="success")
			forward = "";
		else if(result=="error")
			forward = "";
		
		return forward;
	}
	
	@RequestMapping("/saveData.action")
	public String save() {
		String result = dataActionService.save();
		String forward = "";
		if(result=="success")
			forward = "";
		else if(result=="error")
			forward = "";
		
		return forward;
	}
	
	@RequestMapping("/downloadData.action")
	public String download() {
		String result = dataActionService.download();
		String forward = "";
		if(result=="success")
			forward = "";
		else if(result=="error")
			forward = "";
		
		return forward;
	}
	
	
}
