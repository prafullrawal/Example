package com.cts.servicevalidator.controller;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cts.servicevalidator.service.DataActionService;

@Controller
public class DataActionController {
	
	@Autowired
	DataActionService dataActionService; 

	
	@RequestMapping("/loadData.action")
	public String load(@RequestParam("username") String username, @RequestParam("testName") String testName,@RequestParam("rand") String rand,
					  Map<String,Object> model) {
		List result = dataActionService.loadData(username,testName,rand);
		String forward = "";
		if(result.get(0).equals("success")) {
			
			model.put("username", username);
			model.put("testName", testName);
			model.put("uploadFilePath", result.get(1));
			model.put("uploadDirPath", result.get(2));
			model.put("fileList", result.get(3));
			model.put("type", result.get(4));
			model.put("content", result.get(5));
			model.put("displayList", result.get(6));
			
			forward = "Data.jsp";
		}
		else if(result.get(0).equals("error")) {
			model.put("actionerror", result.get(1));
			forward = "Data.jsp";
		}
		
		return forward;
	}
	
	@RequestMapping("/LoadData.action")
	public String LoadData(@RequestParam("username") String username, @RequestParam("testName") String testName,@RequestParam("rand") String rand,
						  @RequestParam("type") String type,Map<String,Object> model) {
		List result = dataActionService.LoadData(username,testName,rand,type);
		String forward = "";
		if(result.get(0).equals("success")) {
			
			model.put("username", username);
			model.put("testName", testName);
			model.put("uploadFilePath", result.get(1));
			model.put("uploadDirPath", result.get(2));
			model.put("fileList", result.get(3));
			model.put("type", result.get(4));
			model.put("content", result.get(5));
			model.put("displayList", result.get(6));
			
			forward = "Data.jsp";
		}
		else if(result.get(0).equals("error")) {
			model.put("actionerror", result.get(1));
			forward = "Data.jsp";
		}
		
		return forward;
	}
	
	@RequestMapping("/saveData.action")
	public String save(@RequestParam("username") String username, @RequestParam("testName") String testName,@RequestParam("content") String content,
					   @RequestParam("uploadDirPath") String uploadDirPath,@RequestParam("type") String type,@RequestParam("uploadFilePath") String uploadFilePath,Map<String,Object> model) {
		List result = dataActionService.save(uploadDirPath,uploadFilePath,type,content,username);
		
    	
    	String forward = "";
		if(result.get(0).equals("success")) {
			
			model.put("username", username);
			model.put("testName", testName);
			model.put("uploadFilePath", uploadFilePath);
			model.put("uploadDirPath", uploadDirPath);
			model.put("fileList", result.get(2));
			model.put("type", type);
			model.put("content", result.get(3));
			model.put("displayList", result.get(4));
			
			
			forward = "Data.jsp";
		}
		else if(result.get(0).equals("error")) {
			model.put("actionerror", result.get(1));
			forward = "Data.jsp";
		}
		
		return forward;
	}
	
	@RequestMapping("/downloadData.action")
	public void download(@RequestParam("uploadFilePath") String uploadFilePath, HttpServletResponse response,
						 Map<String,Object> model) throws IOException {
		
		List result = dataActionService.download(uploadFilePath);
		
		String forward = "";
		if(result.get(0).equals("success")) {
			
			FileInputStream file = (FileInputStream) result.get(1);
			IOUtils.copy(file,response.getOutputStream());
			response.setHeader("Content-Disposition", "attachment; filename=\"reportData.txt\""); 
			response.flushBuffer();
		
		} else if(result.get(0).equals("error")) {
			model.put("actionerror", result.get(1));
			forward = "Data.jsp";
		}
		
		
	}
}
