package com.cts.servicevalidator.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cts.servicevalidator.service.DataActionService;

@Controller
public class DataActionController {
	
	@Autowired
	DataActionService dataActionService; 

	@RequestMapping("/loadData.action")
	public String load() {
		dataActionService.loadData();
		return "load";
	}
	
	@RequestMapping("/saveData.action")
	public String save() {
		dataActionService.saveData();
		return "save";
	}
	
	@RequestMapping("/downloadData.action")
	public String download() {
		dataActionService.downloadData();
		return "download";
	}
	
	
}
