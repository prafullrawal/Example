package com.cts.servicevalidator.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class DataActionController {

	@RequestMapping("/DataAction/load")
	public String load() {
		return "load";
	}
	
	@RequestMapping("/DataAction/save")
	public String save() {
		return "save";
	}
	
	@RequestMapping("/DataAction/download")
	public String download() {
		return "download";
	}
	
	
}
