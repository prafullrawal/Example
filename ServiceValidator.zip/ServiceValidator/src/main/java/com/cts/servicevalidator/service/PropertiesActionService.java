package com.cts.servicevalidator.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;

//import org.apache.struts2.ServletActionContext;
import org.springframework.stereotype.Service;

import com.cts.integration.util.FileUtil;
import com.cts.servicevalidator.contants.*;
import com.cts.servicevalidator.model.PropertiesActionModel;

@Service
public class PropertiesActionService {
	
	PropertiesActionModel propertiesActionModel = new PropertiesActionModel();

	public String loadProtocol(String type,String username,String testName,String protocol) {
		
		//FileInputStream fis = null;
		
		 try {
			
			/*
			 * type = ServletActionContext.getRequest().getParameter("type"); username =
			 * ServletActionContext.getRequest().getParameter("username"); testName =
			 * ServletActionContext.getRequest().getParameter("testName"); protocol =
			 * ServletActionContext.getRequest().getParameter("protocol");
			 */
			
			 propertiesActionModel.setType(type);
			 propertiesActionModel.setUsername(username);
			 propertiesActionModel.setTestName(testName);
			 propertiesActionModel.setProtocol(protocol);
			 
			
			System.out.println(" type --- "+type);
			propertiesActionModel.setTargetPath(UIConstants.WEBROOT+File.separator+username+File.separator+testName+File.separator+testName+type+".properties");
			String samplePath=UIConstants.WEBROOT+File.separator+"Sample"+protocol+".properties";
			System.out.println("path --"+propertiesActionModel.getTargetPath());
			File sourcePropertiesFile = new File(propertiesActionModel.getTargetPath());
			if(!sourcePropertiesFile.exists()){
				sourcePropertiesFile = new File(samplePath);
				propertiesActionModel.setConfContent(new String(Files.readAllBytes(Paths.get(samplePath)),Charset.defaultCharset()));
				//confContent= FileUtil.readFileAsString(samplePath);
			}else{
				propertiesActionModel.setConfContent(new String(Files.readAllBytes(Paths.get(propertiesActionModel.getTargetPath())),Charset.defaultCharset()));
				//confContent= FileUtil.readFileAsString(targetPath);
			}
			//fis= new FileInputStream(sourcePropertiesFile);
			//protocolProperties.load(fis);
			//confContent=protocolProperties.toString();
	    	return "success";
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			//addActionError("System error"+e.getMessage());
			return "error";
		}finally{
			/*try {
				if(fis!=null){
					
						fis.close();
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}*/
			
		}
		
	}

	public String saveProtocol() {
		FileInputStream fis = null;
		
		 try {
			
			FileUtil.writeToFile(propertiesActionModel.getTargetPath(), propertiesActionModel.getConfContent());
	    	return "success";
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			//addActionError("System error"+e.getMessage());
			return "error";
		}finally{
			try {
				if(fis!=null){
					
						fis.close();
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		
	}

	public String reloadProperties() {
		
		FileInputStream fis = null;
		
		 try {
			
			String samplePath=UIConstants.WEBROOT+File.separator+"Sample"+propertiesActionModel.getProtocol()+".properties";
			propertiesActionModel.setConfContent(new String(Files.readAllBytes(Paths.get(samplePath)),Charset.defaultCharset()));
			
	    	return "success";
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			//addActionError("System error"+e.getMessage());
			return "error";
		}finally{
			try {
				if(fis!=null){
					
						fis.close();
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		
	}

	
}
