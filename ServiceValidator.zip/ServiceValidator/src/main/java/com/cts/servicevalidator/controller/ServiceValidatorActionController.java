package com.cts.servicevalidator.controller;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cts.servicevalidator.model.ServiceValidatorActionModel;
import com.cts.servicevalidator.service.ServiceValidatorActionService;
import com.google.gson.Gson;
import javax.servlet.http.HttpSession;

@Controller
public class ServiceValidatorActionController {
	
	@Autowired
	ServiceValidatorActionService serviceValidatorActionService;
	
	@RequestMapping("/")
	public String index(Map<String, Object> model) {
		model.put("", "");
		return "index.jsp"; 
	}
	
	@RequestMapping("/NewUserLogin")
	public String NewUserLogin(Map<String, Object> model) {
		model.put("", "");
		return "NewUserLogin.jsp"; 
	}
	
	@RequestMapping("/ExistingUserLogin")
	public String ExistingUserLogin(Map<String, Object> model) {
		model.put("", "");
		return "ExistingUserLogin.jsp"; 
	}
	
	@RequestMapping("/ProfileLogin")
	public String ProfileLogin(Map<String, Object> model) {
		model.put("", "");
		return "ProfileLogin.jsp"; 
	}
	
	
	@RequestMapping("/NewProfileLogin")
	public String NewProfileLogin(Map<String, Object> model) {
		model.put("", "");
		return "NewProfileLogin.jsp"; 
	}
	
	@RequestMapping("/User")
	public String User(Map<String, Object> model) {
		model.put("", "");
		String forward = "";
		forward = "User.jsp";
		System.out.println("inside under User.jsp");
		return forward; 
	}
	
	@RequestMapping(value="/newuserlogin.action", method = RequestMethod.POST)
	public String login(@RequestParam("username") String username, @RequestParam("password") String password , Map<String, Object> model) {
		System.out.println(username+" "+password);
		String result = serviceValidatorActionService.newuserlogin(username,password);
		if(result.equals("success"))
			return "User.jsp";
		else
			return "NewUserLogin.jsp";
	}
	
	@RequestMapping("/existinguserlogin.action")
	public String existinguserlogin(@RequestParam("username") String username, @RequestParam("password") String password , Map<String, Object> model) {
		String result = serviceValidatorActionService.existinguserlogin(username,password);
	
		String forward = "";
	
		if(result.equals("success"))
			forward =  "profile.jsp";
		else if(result.equals("error"))
			forward = "ExistingUserLogin.jsp";
		
		return forward;
	}
	
	@RequestMapping("/profilelogin.action")
	public String profileloginAction(@RequestParam("profilename") String profilename,Map<String, Object> model) {
		List<Object> result = serviceValidatorActionService.profilelogin(profilename);
		
		ServiceValidatorActionModel serviceValidatorActionModel = (ServiceValidatorActionModel) result.get(1);
		
		System.out.println(result);
		
		Gson gson = new Gson();
		String s = gson.toJson(serviceValidatorActionModel); 
		
		System.out.println(s);
		
		String forward = "";
		if(result.get(0).equals("success")) {
			model.put("serviceValidatorModel",result.get(1));
			forward =  "Welcome.jsp";
		}
		else if(result.equals("error")) {
			forward = "ProfileLogin.jsp";
		}
		
		return forward;
	}
	
	
	@RequestMapping("/add.action")
	public String addTestCase() {
		return "string";
	}

	@RequestMapping("/save.action")
	public String save() {
		serviceValidatorActionService.save();
		return "string";
	}

	@RequestMapping("/delete.action")
	public String delete() {
		serviceValidatorActionService.delete();
		return "string";
	}

	@RequestMapping("/excuteTest.action")
	public String executeTest() {
		serviceValidatorActionService.executeTest();
		return "string";
	}

	@RequestMapping("/executeDisplay.action")
	public String executeDisplay() {
		serviceValidatorActionService.executeDisplay(null);
		return "string";
	}

	@RequestMapping("/downloadReportByName.action")
	public String downloadReportByName() {
		serviceValidatorActionService.downloadReportByName();
		return "string";
	}

	@RequestMapping("/displayReportPage.action")
	public String displayReportPage() {
		serviceValidatorActionService.displayReportPage(null);
		return "string";
	}

	@RequestMapping("/currentReport.action")
	public String currentReport(HttpSession httpSession) {
		serviceValidatorActionService.currentReport(httpSession);
		return "string";
	}

	@RequestMapping("/showInfo.action")
	public String showInfo(HttpSession httpSession) {
		serviceValidatorActionService.showInfo(httpSession);
		return "string";
	}
	 
	
}
