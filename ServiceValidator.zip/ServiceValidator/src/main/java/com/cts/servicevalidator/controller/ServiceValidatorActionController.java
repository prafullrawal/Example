package com.cts.servicevalidator.controller;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cts.servicevalidator.service.ServiceValidatorActionService;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Controller
public class ServiceValidatorActionController {
	
	@Autowired
	ServiceValidatorActionService serviceValidatorActionService;
	
	@ModelAttribute
	public ServiceValidatorActionService construct() {
		return new ServiceValidatorActionService();
	}
	
	@RequestMapping("/")
	public String index(Map<String, Object> model) {
		model.put("", "");
		return "index.jsp"; 
	}
	
	@RequestMapping("/NewUserLogin")
	public String NewUserLogin(Map<String, Object> model) {
		model.put("", "");
		return "NewUserLogin.jsp"; 
	}
	
	@RequestMapping("/ExistingUserLogin")
	public String ExistingUserLogin(Map<String, Object> model) {
		model.put("", "");
		return "ExistingUserLogin.jsp"; 
	}
	
	@RequestMapping("/ProfileLogin")
	public String ProfileLogin(Map<String, Object> model) {
		model.put("", "");
		return "ProfileLogin.jsp"; 
	}
	
	
	@RequestMapping("/NewProfileLogin")
	public String NewProfileLogin(Map<String, Object> model) {
		model.put("", "");
		return "NewProfileLogin.jsp"; 
	}
	
	@RequestMapping("/User")
	public String User(Map<String, Object> model) {
		model.put("", "");
		String forward = "";
		forward = "User.jsp";
		System.out.println("inside under User.jsp");
		return forward; 
	}
	
	@RequestMapping(value="/newuserlogin.action", method = RequestMethod.POST)
	public String login(@RequestParam("username") String username, @RequestParam("password") String password , Map<String, Object> model) {
		System.out.println(username+" "+password);
		String result = serviceValidatorActionService.newuserlogin(username,password);
		if(result.equals("success"))
			return "User.jsp";
		else
			return "NewUserLogin.jsp";
	}
	
	@RequestMapping("/existinguserlogin.action")
	public String existinguserlogin(@RequestParam("username") String username, @RequestParam("password") String password , Map<String, Object> model) {
		String result = serviceValidatorActionService.existinguserlogin(username,password);
	
		String forward = "";
	
		if(result.equals("success"))
			forward =  "profile.jsp";
		else if(result.equals("error"))
			forward = "ExistingUserLogin.jsp";
		
		return forward;
	}
	
	@RequestMapping("/profilelogin.action")
	public String profileloginAction(@RequestParam("profilename") String profilename,Map<String, Object> model) {
		List<Object> result = serviceValidatorActionService.profilelogin(profilename);
		
		String forward = "";
		if(result.get(0).equals("success")) {
			model.put("serviceValidatorModel",result.get(1));
			forward =  "Welcome.jsp";
		}
		else if(result.get(0).equals("error")) {
			forward = "ProfileLogin.jsp";
		}
		
		return forward;
	}
	
	@RequestMapping(path="/add.action" , method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public String addTestCase(@RequestParam Map<String, String> requestParams,Map<String, Object> model, @ModelAttribute("serviceValidatorActionService") ServiceValidatorActionService serviceValidatorAction ) throws ParseException, JsonParseException, JsonMappingException, IOException {
		
		System.out.println(serviceValidatorAction.getTestCases());
		
		List<Object> result = serviceValidatorActionService.add(requestParams); 
		String forward = "";
		
		if(result.get(0).equals("success")) {
			model.put("serviceValidatorModel",result.get(1));
			forward =  "Welcome.jsp";
		}
		else if(result.get(0).equals("error")) {
			forward = "Welcome.jsp";
		}
		
		return forward;
	}

	@RequestMapping(path="/save", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public String save(@RequestParam Map<String, String> requestParams,Map<String, Object> model, HttpServletRequest request ) {
		List<Object> result = serviceValidatorActionService.save(requestParams);
		
		String forward = "";
		if(result.get(0).equals("success")) {
			model.put("serviceValidatorModel",result.get(1));
			forward =  "Welcome.jsp";
		}
		else if(result.get(0).equals("error")) {
			forward = "Welcome.jsp";
		}
		
		return forward;
	}

	@RequestMapping(path="/delete.action", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE )
	public String delete(@RequestParam Map<String, String> requestParams,Map<String, Object> model) {
		
		List<Object> result = serviceValidatorActionService.delete(requestParams);
		
		String forward = "";
		if(result.get(0).equals("success")) {
			model.put("serviceValidatorModel",result.get(1));
			forward =  "Welcome.jsp";
		}
		else if(result.get(0).equals("error")) {
			forward = "Welcome.jsp";
		}
		
		return forward;
	}

	@RequestMapping("/executeTest.action")
	public String executeTest(@PathVariable String username,String rand) {
		System.out.println(username +"*******"+ rand);
		serviceValidatorActionService.executeTest();
		return "string";
	}

	@RequestMapping("/executeDisplay.action?username={username}&rand={rand}")
	public String executeDisplay(@PathVariable String username,String rand) {
		System.out.println(username +"*******"+ rand);
		serviceValidatorActionService.executeDisplay(null);
		return "string";
	}

	@RequestMapping("/downloadReportByName.action")
	public String downloadReportByName() {
		serviceValidatorActionService.downloadReportByName();
		return "string";
	}

	@RequestMapping("/displayReportPage.action")
	public String displayReportPage() {
		serviceValidatorActionService.displayReportPage(null);
		return "string";
	}

	@RequestMapping("/currentReport.action")
	public String currentReport(HttpSession httpSession) {
		serviceValidatorActionService.currentReport(httpSession);
		return "string";
	}

	@RequestMapping("/showInfo.action")
	public String showInfo(HttpSession httpSession) {
		serviceValidatorActionService.showInfo(httpSession);
		return "string";
	}
	 
	
}
