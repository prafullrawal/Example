package com.cts.servicevalidator.controller;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.io.IOUtils;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cts.servicevalidator.service.ServiceValidatorActionService;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Controller
public class ServiceValidatorActionController {
	
	@Autowired
	ServiceValidatorActionService serviceValidatorActionService;
	
	@RequestMapping("/")
	public String index(Map<String, Object> model) {
		return "index"; 
	}
	
	@RequestMapping("/logout")
	public String logout(Map<String, Object> model) {
		// need to remove session here
		System.out.println("System's logging out");
		return "index"; 
	}
	
	@RequestMapping("/NewUserLogin")
	public String NewUserLogin(Map<String, Object> model) {
		return "NewUserLogin"; 
	}
	
	@RequestMapping("/ExistingUserLogin")
	public String ExistingUserLogin(Map<String, Object> model) {
		return "ExistingUserLogin"; 
	}
	
	@RequestMapping("/ProfileLogin")
	public String ProfileLogin(Map<String, Object> model) {
		return "ProfileLogin"; 
	}
	
	
	@RequestMapping("/NewProfileLogin")
	public String NewProfileLogin(Map<String, Object> model) {
		return "NewProfileLogin"; 
	}
	
	@RequestMapping("/addprofile.action")
	public String addProfile(@RequestParam("username") String username,Map<String, Object> model) {
		
		String forward = "";
		
		List result = serviceValidatorActionService.addprofile(username);
		
		if (result != null && result.get(0) != null) {
			if (result.get(0).equals("success")) {
				model.put("serviceValidatorModel", result.get(1));
				forward = "Welcome";
			} else if (result.get(0).equals("error")) {
				model.put("error", result.get(1));
				forward = "profileError";
			}
		} else {
			model.put("actionerror", "Invalid Data loaded");
		}
		
		return forward;
	}

	
	@RequestMapping("/User")
	public String User(Map<String, Object> model) {
		return "User"; 
	}
	
	@RequestMapping(value="/newuserlogin.action", method = RequestMethod.POST)
	public String login(@RequestParam("username") String username, @RequestParam("password") String password , Map<String, Object> model) {
		
		String result = serviceValidatorActionService.newuserlogin(username,password);
		String forward = "";
		
		if (result != null) {
			if (result.equals("success")) {
				forward = "User";
			} else {
				model.put("error", "Error");
				forward = "NewUserLogin";
			}
		} else {
			model.put("actionerror", "Invalid Data loaded");
		}
		
		return forward;
	}
	
	@RequestMapping("/existinguserlogin.action")
	public String existinguserlogin(@RequestParam("username") String username, @RequestParam("password") String password , Map<String, Object> model) {
		String result = serviceValidatorActionService.existinguserlogin(username,password);
	
		String forward = "";
	
		if (result != null) {
			if (result.equals("success"))
				forward = "profile";
			else if (result.equals("error"))
				forward = "ExistingUserLogin";
		} else {
			model.put("actionerror", "Invalid Data loaded");
		}
		
		return forward;
	}
	
	@RequestMapping("/profilelogin.action")
	public String profileloginAction(@RequestParam("profilename") String profilename,Map<String, Object> model) {
		List<Object> result = serviceValidatorActionService.profilelogin(profilename);
		
		String forward = "";
		
		if (result != null && result.get(0) != null) {
			if (result.get(0).equals("success")) {
				model.put("serviceValidatorModel", result.get(1));
				forward = "Welcome";
			} else if (result.get(0).equals("error")) {
				forward = "ProfileLogin";
			}
		} else {
			model.put("actionerror", "Invalid Data loaded");
		}
		
		return forward;
	}
	
	@RequestMapping(path="/add.action" , method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public String addTestCase(@RequestParam Map<String, String> requestParams,Map<String, Object> model, @ModelAttribute("serviceValidatorActionService") ServiceValidatorActionService serviceValidatorAction ) throws ParseException, JsonParseException, JsonMappingException, IOException {
		
		List<Object> result = serviceValidatorActionService.add(requestParams); 
		String forward = "";
		
		if (result != null && result.get(0) != null) {

			if (result.get(0).equals("success")) {
				model.put("serviceValidatorModel", result.get(1));
				forward = "Welcome";
			} else if (result.get(0).equals("error")) {
				forward = "Welcome";
			}

		} else {
			model.put("actionerror", "Invalid Data loaded");
		}
		
		return forward;
	}

	@RequestMapping(path="/save", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public String save(@RequestParam Map<String, String> requestParams,Map<String, Object> model, HttpServletRequest request ) {
		List<Object> result = serviceValidatorActionService.save(requestParams);
		
		String forward = "";
		if (result != null && result.get(0) != null) {

			if (result.get(0).equals("success")) {
				model.put("serviceValidatorModel", result.get(1));
				forward = "Welcome";
			} else if (result.get(0).equals("error")) {
				forward = "Welcome";
			}

		} else {
			model.put("actionerror", "Invalid Data loaded");
		}
		return forward;
	}

	@RequestMapping(path="/delete.action", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE )
	public String delete(@RequestParam Map<String, String> requestParams,Map<String, Object> model) {
		
		List<Object> result = serviceValidatorActionService.delete(requestParams);
		String forward = "";
		
		if (result != null && result.get(0) != null) {

			if (result.get(0).equals("success")) {
				model.put("serviceValidatorModel", result.get(1));
				forward = "Welcome";
			} else if (result.get(0).equals("error")) {
				forward = "Welcome";
			}

		} else {
			model.put("actionerror", "Invalid Data loaded");
		}
		return forward;
	}

	@RequestMapping(path="/executeTest.action", method = RequestMethod.POST)
	public String executeTest(@RequestParam("username") String username,HttpServletRequest request,Map<String, Object> model) {
		
		List result = serviceValidatorActionService.executeTest(username,request);
		
		model.put("logMessage", result.get(1));
		model.put("username", username);
		model.put("csvReportName",result.get(2));
		
		String forward = "";
		
		if (result != null && result.get(0) != null) {

			if (result.get(0).equals("success")) {
				forward = "LogResult";
			} else if (result.get(0).equals("error")) {
				forward = "LogResult";
			}

		} else {
			model.put("actionerror", "Invalid Data loaded");
		}
		
		
		return forward;
	
	}

	@RequestMapping(path="/executeDisplay.action")
	public String executeDisplay(@RequestParam("username") String username,@RequestParam("rand") String rand , Map<String, Object> model) {
		Map map = serviceValidatorActionService.executeDisplay(username,rand);
		
		String forward = "";
		
		if (map != null && map.get("success") != null) {

			if (map.get("success").equals("success")) {

				model.put("username", map.get("username"));
				model.put("profileRoot", map.get("profileRoot"));
				forward = "executeDisplay";
			} else if (map.get("error").equals("error")) {
				forward = "executeDisplay";
			}

		} else {
			model.put("actionerror", "Invalid Data loaded");
		}
		
		return forward;
	}

	@RequestMapping("/downloadReportByName.action")
	public void downloadReportByName(@RequestParam("username") String username, @RequestParam("downloadReportName") String downloadReportName , HttpServletResponse response ,  Map<String, Object> model) throws IOException {
		
		List result =  serviceValidatorActionService.downloadReportByName(username,downloadReportName);
		
		if(result!=null && result.get(0)!=null) {

			FileInputStream file = (FileInputStream) result.get(1);
					
					String fileName = downloadReportName.split("\\.")[0];
					String extension = downloadReportName.split("\\.")[1];
					
					IOUtils.copy(file,response.getOutputStream());
					response.setHeader("Content-Disposition", "attachment; filename=\""+fileName+"."+extension+"\""); 
					response.flushBuffer();
				

			} else {		
					model.put("actionerror", "Invalid Data loaded");
			}
		
	}

	@RequestMapping("/loadReports.action")
	public String displayReportPage(@RequestParam("username") String username,@RequestParam("rand") String rand , Map<String, Object> model) {
		List result = serviceValidatorActionService.displayReportPage(username,rand);
		
		String forward = "";
		
		if (result != null && result.get(0) != null) {

			if (result.get(0).equals("success")) {

				model.put("username", username);
				model.put("reportList", result.get(1));
				forward = "AllReports";
			} else if (result.get(0).equals("error")) {
				forward = "AllReports";
			}

		} else {
			model.put("actionerror", "Invalid Data loaded");
		}
	
		return forward;
	}

	@RequestMapping("/currentReport.action")
	public String currentReport(@RequestParam("username") String username,HttpServletRequest request,Map<String, Object> model) {
		List result = serviceValidatorActionService.currentReport(request);
		
		String forward = "";
		
		if (result != null && result.get(0) != null) {

			if (result.get(0).equals("success")) {

				model.put("username", username);
				model.put("testReports", result.get(1));
				model.put("xmlReportName", result.get(2));
				model.put("quickReportName", result.get(3));
				model.put("csvReportName", result.get(4));

				forward = "CurrentReport";
			} else if (result.get(0).equals("error")) {

				model.put("actionerror", result.get(1));
				forward = "CurrentReport";
			}

		} else {
			model.put("actionerror", "Invalid Data loaded");
		}
	
		return forward;
	}

	@RequestMapping(path="/showInfo.action")
	public String showInfo(@RequestParam("testName") String testName,@RequestParam("type") String type,@RequestParam("count") String count,
							@RequestParam("rand") String rand ,HttpServletRequest request,Map<String, Object> model) {
		List result = serviceValidatorActionService.showInfo(testName, type,count,rand,request);
		
		String forward = "";
		
		if (result != null && result.get(0) != null) {
			if (result.get(0).equals("success")) {
				model.put("infoContent", result.get(1));
				forward = "ShowInfo";
			} else if (result.get(0).equals("error")) {

				model.put("actionerror", result.get(1));
				forward = "ShowInfo";
			}

		} else {
			model.put("actionerror", "Invalid Data loaded");
		}
	
		return forward;
		
	}
	 
	
}
