package com.cts.servicevalidator.controller;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.io.IOUtils;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cts.servicevalidator.service.ServiceValidatorActionService;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Controller
public class ServiceValidatorActionController {
	
	@Autowired
	ServiceValidatorActionService serviceValidatorActionService;
	
	@ModelAttribute
	public ServiceValidatorActionService construct() {
		return new ServiceValidatorActionService();
	}
	
	@RequestMapping("/")
	public String index(Map<String, Object> model) {
		model.put("", "");
		return "index.jsp"; 
	}
	
	@RequestMapping("/NewUserLogin")
	public String NewUserLogin(Map<String, Object> model) {
		model.put("", "");
		return "NewUserLogin.jsp"; 
	}
	
	@RequestMapping("/ExistingUserLogin")
	public String ExistingUserLogin(Map<String, Object> model) {
		model.put("", "");
		return "ExistingUserLogin.jsp"; 
	}
	
	@RequestMapping("/ProfileLogin")
	public String ProfileLogin(Map<String, Object> model) {
		model.put("", "");
		return "ProfileLogin.jsp"; 
	}
	
	
	@RequestMapping("/NewProfileLogin")
	public String NewProfileLogin(Map<String, Object> model) {
		model.put("", "");
		return "NewProfileLogin.jsp"; 
	}
	
	@RequestMapping("/User")
	public String User(Map<String, Object> model) {
		model.put("", "");
		String forward = "";
		forward = "User.jsp";
		System.out.println("inside under User.jsp");
		return forward; 
	}
	
	@RequestMapping(value="/newuserlogin.action", method = RequestMethod.POST)
	public String login(@RequestParam("username") String username, @RequestParam("password") String password , Map<String, Object> model) {
		System.out.println(username+" "+password);
		String result = serviceValidatorActionService.newuserlogin(username,password);
		if(result.equals("success"))
			return "User.jsp";
		else
			return "NewUserLogin.jsp";
	}
	
	@RequestMapping("/existinguserlogin.action")
	public String existinguserlogin(@RequestParam("username") String username, @RequestParam("password") String password , Map<String, Object> model) {
		String result = serviceValidatorActionService.existinguserlogin(username,password);
	
		String forward = "";
	
		if(result.equals("success"))
			forward =  "profile.jsp";
		else if(result.equals("error"))
			forward = "ExistingUserLogin.jsp";
		
		return forward;
	}
	
	@RequestMapping("/profilelogin.action")
	public String profileloginAction(@RequestParam("profilename") String profilename,Map<String, Object> model) {
		List<Object> result = serviceValidatorActionService.profilelogin(profilename);
		
		String forward = "";
		if(result.get(0).equals("success")) {
			model.put("serviceValidatorModel",result.get(1));
			forward =  "Welcome.jsp";
		}
		else if(result.get(0).equals("error")) {
			forward = "ProfileLogin.jsp";
		}
		
		return forward;
	}
	
	@RequestMapping(path="/add.action" , method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public String addTestCase(@RequestParam Map<String, String> requestParams,Map<String, Object> model, @ModelAttribute("serviceValidatorActionService") ServiceValidatorActionService serviceValidatorAction ) throws ParseException, JsonParseException, JsonMappingException, IOException {
		
		System.out.println(serviceValidatorAction.getTestCases());
		
		List<Object> result = serviceValidatorActionService.add(requestParams); 
		String forward = "";
		
		if(result.get(0).equals("success")) {
			model.put("serviceValidatorModel",result.get(1));
			forward =  "Welcome.jsp";
		}
		else if(result.get(0).equals("error")) {
			forward = "Welcome.jsp";
		}
		
		return forward;
	}

	@RequestMapping(path="/save", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public String save(@RequestParam Map<String, String> requestParams,Map<String, Object> model, HttpServletRequest request ) {
		List<Object> result = serviceValidatorActionService.save(requestParams);
		
		String forward = "";
		if(result.get(0).equals("success")) {
			model.put("serviceValidatorModel",result.get(1));
			forward =  "Welcome.jsp";
		}
		else if(result.get(0).equals("error")) {
			forward = "Welcome.jsp";
		}
		
		return forward;
	}

	@RequestMapping(path="/delete.action", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE )
	public String delete(@RequestParam Map<String, String> requestParams,Map<String, Object> model) {
		
		List<Object> result = serviceValidatorActionService.delete(requestParams);
		
		String forward = "";
		if(result.get(0).equals("success")) {
			model.put("serviceValidatorModel",result.get(1));
			forward =  "Welcome.jsp";
		}
		else if(result.get(0).equals("error")) {
			forward = "Welcome.jsp";
		}
		
		return forward;
	}

	@RequestMapping(path="/executeTest.action", method = RequestMethod.POST)
	public String executeTest(@RequestParam("username") String username,HttpSession session,Map<String, Object> model) {
		
		List result = serviceValidatorActionService.executeTest(username,session);
		
		model.put("logMessage", result.get(1));
		model.put("username", username);
		model.put("csvReportName",result.get(2));
		
		String forward = "";
		if(result.get(0).equals("success")) {
			forward =  "LogResult.jsp";
		}
		else if(result.get(0).equals("error")) {
			forward = "LogResult.jsp";
		}
		
		return forward;
	
	}

	@RequestMapping(path="/executeDisplay.action")
	public String executeDisplay(@RequestParam("username") String username,@RequestParam("rand") String rand , Map<String, Object> model) {
		Map map = serviceValidatorActionService.executeDisplay(username,rand);
		
		String forward = "";
		
		if(map.get("success").equals("success")) {
			
			model.put("username",map.get("username"));
			model.put("profileRoot",map.get("profileRoot"));
			forward =  "executeDisplay.jsp";
		}
		else if(map.get("error").equals("error")) {
			forward = "executeDisplay.jsp";
		}
		
		return forward;
	}

	@RequestMapping("/downloadReportByName.action")
	public void downloadReportByName(@RequestParam("username") String username, @RequestParam("downloadReportName") String downloadReportName , HttpServletResponse response) throws IOException {
		
		List list =  serviceValidatorActionService.downloadReportByName(username,downloadReportName);
		
		FileInputStream file = (FileInputStream) list.get(1);
		
		IOUtils.copy(file,response.getOutputStream());
		response.setContentType("application/pdf");      
		response.setHeader("Content-Disposition", "attachment; filename=\"report.txt\""); 
		
		response.flushBuffer();
		
	}

	@RequestMapping("/loadReports.action")
	public String displayReportPage(@RequestParam("username") String username,@RequestParam("rand") String rand , Map<String, Object> model) {
		List list = serviceValidatorActionService.displayReportPage(username,rand);
		
		String forward = "";
		
		if(list.get(0).equals("success")) {
			
			model.put("username", username);
			model.put("reportList",list.get(1));
			forward =  "AllReports.jsp";
		}
		else if(list.get(0).equals("error")) {
			forward = "AllReports.jsp";
		}
	
		return forward;
	}

	@RequestMapping("/currentReport.action")
	public String currentReport(HttpSession httpSession) {
		serviceValidatorActionService.currentReport();
		return "string";
	}

	@RequestMapping("/showInfo.action")
	public String showInfo(HttpSession httpSession) {
		serviceValidatorActionService.showInfo(httpSession);
		return "string";
	}
	 
	
}
