package com.cts.servicevalidator.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cts.servicevalidator.service.ServiceValidatorActionService;

@Controller
public class ServiceValidatorActionController {
	
	@Autowired
	ServiceValidatorActionService serviceValidatorActionService;
	
	@RequestMapping("/")
	public String index(Map<String, Object> model) {
		model.put("", "");
		return "index.jsp"; 
	}
	
	@RequestMapping("/NewUserLogin")
	public String NewUserLogin(Map<String, Object> model) {
		model.put("", "");
		return "NewUserLogin.jsp"; 
	}
	
	@RequestMapping("/ExistingUserLogin")
	public String ExistingUserLogin(Map<String, Object> model) {
		model.put("", "");
		return "ExistingUserLogin.jsp"; 
	}
	
	@RequestMapping("/ProfileLogin")
	public String ProfileLogin(Map<String, Object> model) {
		model.put("", "");
		return "ProfileLogin.jsp"; 
	}
	
	
	@RequestMapping("/NewProfileLogin")
	public String NewProfileLogin(Map<String, Object> model) {
		model.put("", "");
		return "NewProfileLogin.jsp"; 
	}
	
	
	@RequestMapping(value="/ServiceValidatorAction/newuserlogin.action", method = RequestMethod.POST)
	public String login(@RequestParam("username") String username, @RequestParam("password") String password , Map<String, Object> model) {
		System.out.println(username+" "+password);
		String result = serviceValidatorActionService.newuserlogin(username,password);
		if(result.equals("success"))
			return "user.jsp";
		else
			return "NewUserLogin.jsp";
	}
	
	@RequestMapping("/ServiceValidatorAction/existinguserlogin.action")
	public String existinguserlogin(@RequestParam("username") String username, @RequestParam("password") String password , Map<String, Object> model) {
		String result = serviceValidatorActionService.existinguserlogin(username,password);
		if(result.equals("success"))
			return "profile.jsp";
		else if(result.equals("error"))
			return "ExistingUserLogin.jsp";
		
		return "string";
	}
	
	@RequestMapping("/profilelogin.action")
	public String profileloginAction(@RequestParam("profilename") String profilename) {
		serviceValidatorActionService.profilelogin(profilename);
		return "string";
	}
	
	@RequestMapping("/ServiceValidatorAction/delete")
	public String delete() {
		return "string";
	}
	
	@RequestMapping("/ServiceValidatorAction/writeXLSXFile")
	public void writeXLSXFile() {
		//return "string";
	}
	
	@RequestMapping("/ServiceValidatorAction/executeDisplay")
	public String executeDisplay() {
		return "string";
	}
	
	@RequestMapping("/ServiceValidatorAction/executeTest")
	public String executeTest() {
		return "string";
	}
	
	@RequestMapping("/ServiceValidatorAction/downloadReport")
	public String downloadReport() {
		return "string";
	}
	
	@RequestMapping("/ServiceValidatorAction/downloadReportByName")
	public String downloadReportByName() {
		return "string";
	}
	
	@RequestMapping("/ServiceValidatorAction/displayReportPage")
	public String displayReportPage() {
		return "string";
	}
	
	@RequestMapping("/ServiceValidatorAction/currentReport")
	public String currentReport() {
		return "string";
	}
	
	@RequestMapping("/ServiceValidatorAction/showInfo")
	public String showInfo() {
		return "string";
	}
	
}
