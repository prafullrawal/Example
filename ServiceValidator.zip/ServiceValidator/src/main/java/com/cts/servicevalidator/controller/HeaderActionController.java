package com.cts.servicevalidator.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cts.servicevalidator.service.HeaderActionService;


@Controller
public class HeaderActionController {

	@Autowired
	HeaderActionService headerActionService;
	
	@RequestMapping("/loadHeaderProperties.action")
	public String loadHeaderProperties() {
		headerActionService.loadHeaderProperties();
		return "load";
	}
	
	@RequestMapping("/saveHeaderProperties.action")
	public String saveHeaderProperties() {
		headerActionService.saveHeaderProperties();
		return "load";
	}
	
	@RequestMapping("/reloadHeaderProperties.action")
	public String reloadHeaderProperties() {
		headerActionService.reloadHeaderProperties();
		return "load";
	}
	
}
