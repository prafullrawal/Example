package com.cts.servicevalidator.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cts.servicevalidator.service.HeaderActionService;


@Controller
public class HeaderActionController {

	@Autowired
	HeaderActionService headerActionService;
	
	@RequestMapping(path="/loadHeaderProperties.action")
	public String loadHeaderProperties(@RequestParam("testName") String testName,@RequestParam("username") String username,
									   @RequestParam("rand") String rand,Map<String,Object> model ) {
		List result = headerActionService.loadHeaderProperties(testName,username,rand);
		String forward = "";
		if(result.get(0).equals("success")) {
			model.put("testName",testName);
			model.put("username",username);
			model.put("targetPath",result.get(1));
			model.put("confContent",result.get(2));
			forward = "HeaderProperties.jsp";
		}
		else if(result.get(0).equals("error")) {
			forward = "HeaderProperties.jsp";
			model.put("testName",testName);
			model.put("username",username);
			model.put("actionerror", result.get(1));
		}
		
		return forward;
	}
	
	@RequestMapping("/saveHeaderProperties.action")
	public String saveHeaderProperties(@RequestParam("username") String username,@RequestParam("testName") String testName,
			   @RequestParam("targetPath") String targetPath,@RequestParam("confContent") String confContent,Map<String,Object> model) {
		List result = headerActionService.saveHeaderProperties(username,testName,targetPath,confContent);
		String forward = "";
		if(result.get(0).equals("success")) {
			model.put("testName",testName);
			model.put("username",username);
			model.put("targetPath",targetPath);
			model.put("confContent",confContent);
			forward = "HeaderProperties.jsp";
		}
		else if(result.get(0).equals("error")) {
			model.put("testName",testName);
			model.put("username",username);
			model.put("targetPath",targetPath);
			model.put("actionerror", result.get(1));
			forward = "HeaderProperties.jsp";
		}
		return forward;
	}
	
	@RequestMapping("/reloadHeaderProperties.action")
	public String reloadHeaderProperties(@RequestParam("username") String username,@RequestParam("testName") String testName,
			   @RequestParam("targetPath") String targetPath,@RequestParam("confContent") String confContent,Map<String,Object> model) {
		List result = headerActionService.reloadHeaderProperties(username,testName);
		String forward = "";
		if(result.get(0).equals("success")) {
			model.put("testName",testName);
			model.put("username",username);
			model.put("targetPath",targetPath);
			model.put("confContent",result.get(1));
			forward = "HeaderProperties.jsp";
		}
		else if(result.get(0).equals("error")) {
			model.put("testName",testName);
			model.put("username",username);
			model.put("targetPath",targetPath);
			model.put("confContent", confContent);
			model.put("actionerror", result.get(1));
			forward = "HeaderProperties.jsp";
		}
		return forward;
	}
	
}
