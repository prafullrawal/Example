package com.cts.servicevalidator.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cts.servicevalidator.service.HeaderActionService;


@Controller
public class HeaderActionController {

	@Autowired
	HeaderActionService headerActionService;
	
	@RequestMapping("/loadHeaderProperties.action")
	public String loadHeaderProperties() {
		String result = headerActionService.loadHeaderProperties();
		String forward = "";
		if(result=="success")
			forward = "";
		else if(result=="error")
			forward = "";
		
		return forward;
	}
	
	@RequestMapping("/saveHeaderProperties.action")
	public String saveHeaderProperties() {
		String result = headerActionService.saveHeaderProperties();
		String forward = "";
		if(result=="success")
			forward = "";
		else if(result=="error")
			forward = "";
		
		return forward;
	}
	
	@RequestMapping("/reloadHeaderProperties.action")
	public String reloadHeaderProperties() {
		String result = headerActionService.reloadHeaderProperties();
		String forward = "";
		if(result=="success")
			forward = "";
		else if(result=="error")
			forward = "";
		
		return forward;
	}
	
}
