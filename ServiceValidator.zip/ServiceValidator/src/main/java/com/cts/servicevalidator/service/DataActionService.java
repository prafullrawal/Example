package com.cts.servicevalidator.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;

//import org.apache.struts2.ServletActionContext;
import org.springframework.stereotype.Service;

import com.cts.servicevalidator.contants.*;
import com.cts.servicevalidator.model.DataActionModel;
import com.cts.integration.util.FileUtil;
import org.apache.commons.io.FileUtils;

@Service
public class DataActionService {
	
	DataActionModel dataActionModel = new DataActionModel();
	
	public void appendToFile(String path,String content,FileOutputStream infile)throws Exception {
		FileOutputStream fos = infile;
	    OutputStreamWriter osw = null;
		try{
			  File responseFile = new File(path);    
		      //responseFile.createNewFile(); 
		      fos = new FileOutputStream(responseFile,true);
		      osw = new OutputStreamWriter(fos); 
		      osw.write("\n");		      
		      osw.append(content);	    
		      osw.flush(); 
		      fos.flush();
		}finally{
			if(osw != null){
				//actualOSW.flush();    
			    osw.close();  
			}
			if(fos != null){
				//actualFOS.flush();
				fos.close();
			}
		}
	}

	public String loadData(String username,String testName) {
		
		try {
			
			 dataActionModel.setUsername(username);
			 dataActionModel.setTestName(testName);
			
			/*
			 * username = ServletActionContext.getRequest().getParameter("username");
			 * testName = ServletActionContext.getRequest().getParameter("testName");
			 */
			dataActionModel.setUploadDirPath(UIConstants.WEBROOT+File.separator+username+File.separator+testName+File.separator);
			 
			if(dataActionModel.getType()==null || dataActionModel.getType().trim().length()==0){
				dataActionModel.setType("Input");
			}
			
			dataActionModel.setContent(null);
			
			dataActionModel.setUploadFilePath(UIConstants.WEBROOT+File.separator+username+File.separator+testName+File.separator+testName+dataActionModel.getType());
			File file = new File(dataActionModel.getUploadFilePath());
			if(file.exists()){
				dataActionModel.setContent(new String(Files.readAllBytes(Paths.get(dataActionModel.getUploadFilePath())),Charset.defaultCharset()));
			}
			
			File dir = new File(dataActionModel.getUploadDirPath());
			File stores[]=dir.listFiles();
			StringBuffer sb = new StringBuffer();
			for(File filestore:stores){
				sb.append(filestore.getName());
				sb.append(";");
			}
			dataActionModel.setFileList(sb.toString());
			
			
	    	return "success";
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			//addActionError("System error"+e.getMessage());
			return "error";
		}
	}

	public String saveData() {
		
		try {
			 if(dataActionModel.getUploadFile()!=null){
				 org.apache.commons.io.FileUtils.copyFile(dataActionModel.getUploadFile(), new File(dataActionModel.getUploadFilePath())); 
				 dataActionModel.setContent(new String(Files.readAllBytes(Paths.get(dataActionModel.getUploadFilePath())),Charset.defaultCharset()));
				 
			}else if(dataActionModel.getContent()!=null && dataActionModel.getContent().trim().length()!=0){
				 FileUtil.writeToFile(dataActionModel.getUploadFilePath(), dataActionModel.getContent());
			 }
				
			File dir = new File(dataActionModel.getUploadDirPath());
			File stores[]=dir.listFiles();
			StringBuffer sb = new StringBuffer();
			for(File filestore:stores){
				sb.append(filestore.getName());
				sb.append(";");
			}
			dataActionModel.setFileList(sb.toString());
			
	    	return "success";
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			//addActionError("System error"+e.getMessage());
			return "error";
		}
	}

	public String downloadData() {
		
		 try {
			 File file = new File(dataActionModel.getUploadFilePath());
			if(file.exists()){
				System.out.println("Setting download file");
				dataActionModel.setDownLoadInputStream(new FileInputStream(dataActionModel.getUploadFilePath()));				
			}
			
	    	return "success";
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			//addActionError("System error"+e.getMessage());
			return "error";
		}
	}

}
