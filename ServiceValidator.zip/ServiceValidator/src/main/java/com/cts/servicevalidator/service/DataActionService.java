package com.cts.servicevalidator.service;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class DataActionService {
	
	public void appendToFile(String path,String content,FileOutputStream infile)throws Exception {
		FileOutputStream fos = infile;
	    OutputStreamWriter osw = null;
		try{
			  File responseFile = new File(path);    
		      //responseFile.createNewFile(); 
		      fos = new FileOutputStream(responseFile,true);
		      osw = new OutputStreamWriter(fos); 
		      osw.write("\n");		      
		      osw.append(content);	    
		      osw.flush(); 
		      fos.flush();
		}finally{
			if(osw != null){
				//actualOSW.flush();    
			    osw.close();  
			}
			if(fos != null){
				//actualFOS.flush();
				fos.close();
			}
		}
	}

}
