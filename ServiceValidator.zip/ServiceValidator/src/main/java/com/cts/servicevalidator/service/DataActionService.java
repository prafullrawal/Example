package com.cts.servicevalidator.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

//import org.apache.struts2.ServletActionContext;
import org.springframework.stereotype.Service;

import com.cts.servicevalidator.contants.*;
import com.cts.integration.*;
import com.cts.integration.util.FileUtil;
import org.apache.commons.io.FileUtils;

@Service
public class DataActionService {
	
	String testName;
	String username;
	String type;
	File uploadFile;
	String uploadFilePath;
	String uploadDirPath;
	String content;
	FileInputStream downLoadInputStream;
	String fileList;
	List<String> displayList = new ArrayList<String>(Arrays.asList("Input","Expected","Actual"));
	
	public String getTestName() {
		return testName;
	}
	public void setTestName(String testName) {
		this.testName = testName;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public File getUploadFile() {
		return uploadFile;
	}
	public void setUploadFile(File uploadFile) {
		this.uploadFile = uploadFile;
	}
	public String getUploadFilePath() {
		return uploadFilePath;
	}
	public void setUploadFilePath(String uploadFilePath) {
		this.uploadFilePath = uploadFilePath;
	}
	public String getUploadDirPath() {
		return uploadDirPath;
	}
	public void setUploadDirPath(String uploadDirPath) {
		this.uploadDirPath = uploadDirPath;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public FileInputStream getDownLoadInputStream() {
		return downLoadInputStream;
	}
	public void setDownLoadInputStream(FileInputStream downLoadInputStream) {
		this.downLoadInputStream = downLoadInputStream;
	}
	public String getFileList() {
		return fileList;
	}
	public void setFileList(String fileList) {
		this.fileList = fileList;
	}
	public List<String> getDisplayList() {
		return displayList;
	}
	public void setDisplayList(List<String> displayList) {
		this.displayList = displayList;
	}
	
public List loadData(String username,String testName, String rand) {
		
		List list = new ArrayList();
	
		try {
			
			uploadDirPath = UIConstants.WEBROOT+File.separator+username+File.separator+testName+File.separator;
			if(type==null || type.trim().length()==0){
				type="Input";
			}
			content=null;
			
			uploadFilePath=UIConstants.WEBROOT+File.separator+username+File.separator+testName+File.separator+testName+type;
			File file = new File(uploadFilePath);
			if(file.exists()){
				content=new String(Files.readAllBytes(Paths.get(uploadFilePath)),Charset.defaultCharset());
			}
			
			File dir = new File(uploadDirPath);
			File stores[]=dir.listFiles();
			StringBuffer sb = new StringBuffer();
			for(File filestore:stores){
				sb.append(filestore.getName());
				sb.append(";");
			}
			fileList = sb.toString();
			
	    	list.add("success");
	    	list.add(uploadFilePath);
	    	list.add(uploadDirPath);
	    	list.add(fileList);
	    	list.add(type);
	    	list.add(content);
	    	list.add(displayList);
	    	
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			//addActionError("System error"+e.getMessage());
			list.add("error");
			list.add("System error"+e.getMessage());
		}
		return list;
	}
	
public List save(String uploadFilePath, String uploadDirPath, String type, String content, String username) {
	
	List list = new ArrayList();

	try {
		 if(uploadFile!=null){
			 org.apache.commons.io.FileUtils.copyFile(uploadFile, new File(uploadFilePath)); 
			 content=new String(Files.readAllBytes(Paths.get(uploadFilePath)),Charset.defaultCharset());
			 
		}else if(content!=null && content.trim().length()!=0){
			 FileUtil.writeToFile(uploadFilePath, content);
		 }
			
		File dir = new File(uploadDirPath);
		File stores[]=dir.listFiles();
		StringBuffer sb = new StringBuffer();
		for(File filestore:stores){
			sb.append(filestore.getName());
			sb.append(";");
		}
		fileList = sb.toString();
		
    	list.add("success");
    	list.add(uploadFilePath);
    	list.add(fileList);
    	list.add(content);
    	list.add(displayList);
    	
		
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		//addActionError("System error"+e.getMessage());
		list.add("error");
		list.add("System error"+e.getMessage());
	}
	
	return list;
}

public List download(String uploadFilePath) {
		
	List list = new ArrayList();
	
		 try {
			 File file = new File(uploadFilePath);
			if(file.exists()){
				System.out.println("Setting download file");
				downLoadInputStream = new FileInputStream(uploadFilePath);				
			}
			
	    	list.add("success");
	    	list.add(downLoadInputStream);
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			//addActionError("System error"+e.getMessage());
			list.add("error");
			list.add("System error"+e.getMessage());
		}
		 
		 return list;
	}
	
public static void appendToFile(String path,String content,FileOutputStream infile)throws Exception{
		FileOutputStream fos = infile;
	    OutputStreamWriter osw = null;
		try{
			  File responseFile = new File(path);    
		      //responseFile.createNewFile(); 
		      fos = new FileOutputStream(responseFile,true);
		      osw = new OutputStreamWriter(fos); 
		      osw.write("\n");		      
		      osw.append(content);	    
		      osw.flush();
		      fos.flush();
		}finally{
			if(osw != null){
				//actualOSW.flush();    
			    osw.close();  
			}
			if(fos != null){
				//actualFOS.flush();
				fos.close();
			}
		}
	}


public List LoadData(String username, String testName, String rand, String type) {
	
	List list = new ArrayList();
	
	try {
		
		uploadDirPath = UIConstants.WEBROOT+File.separator+username+File.separator+testName+File.separator;
		if(type==null || type.trim().length()==0){
			type="Input";
		}
		content=null;
		
		uploadFilePath=UIConstants.WEBROOT+File.separator+username+File.separator+testName+File.separator+testName+type;
		File file = new File(uploadFilePath);
		if(file.exists()){
			content=new String(Files.readAllBytes(Paths.get(uploadFilePath)),Charset.defaultCharset());
		}
		
		File dir = new File(uploadDirPath);
		File stores[]=dir.listFiles();
		StringBuffer sb = new StringBuffer();
		for(File filestore:stores){
			sb.append(filestore.getName());
			sb.append(";");
		}
		fileList = sb.toString();
		
    	list.add("success");
    	list.add(uploadFilePath);
    	list.add(uploadDirPath);
    	list.add(fileList);
    	list.add(type);
    	list.add(content);
    	list.add(displayList);
    	
		
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		//addActionError("System error"+e.getMessage());
		list.add("error");
		list.add("System error"+e.getMessage());
	}
	
	return list;

	}
}