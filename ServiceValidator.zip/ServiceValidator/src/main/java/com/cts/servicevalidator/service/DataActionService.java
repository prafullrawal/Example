package com.cts.servicevalidator.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;

//import org.apache.struts2.ServletActionContext;
import org.springframework.stereotype.Service;

import com.cts.servicevalidator.contants.*;
import com.cts.integration.util.FileUtil;


@Service
public class DataActionService {
	
	public void appendToFile(String path,String content,FileOutputStream infile)throws Exception {
		FileOutputStream fos = infile;
	    OutputStreamWriter osw = null;
		try{
			  File responseFile = new File(path);    
		      //responseFile.createNewFile(); 
		      fos = new FileOutputStream(responseFile,true);
		      osw = new OutputStreamWriter(fos); 
		      osw.write("\n");		      
		      osw.append(content);	    
		      osw.flush(); 
		      fos.flush();
		}finally{
			if(osw != null){
				//actualOSW.flush();    
			    osw.close();  
			}
			if(fos != null){
				//actualFOS.flush();
				fos.close();
			}
		}
	}

	public void loadData() {
		
		try {
			username = ServletActionContext.getRequest().getParameter("username");
			testName = ServletActionContext.getRequest().getParameter("testName");
			uploadDirPath = UIConstants.WEBROOT+File.separator+username+File.separator+testName+File.separator;
			if(type==null || type.trim().length()==0){
				type="Input";
			}
			content=null;
			
			uploadFilePath=UIConstants.WEBROOT+File.separator+username+File.separator+testName+File.separator+testName+type;
			File file = new File(uploadFilePath);
			if(file.exists()){
				content=new String(Files.readAllBytes(Paths.get(uploadFilePath)),Charset.defaultCharset());
			}
			
			File dir = new File(uploadDirPath);
			File stores[]=dir.listFiles();
			StringBuffer sb = new StringBuffer();
			for(File filestore:stores){
				sb.append(filestore.getName());
				sb.append(";");
			}
			fileList = sb.toString();
			
			
	    	return "success";
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			addActionError("System error"+e.getMessage());
			return "error";
		}
	}

	public void saveData() {
		
		try {
			 if(uploadFile!=null){
				 org.apache.commons.io.FileUtils.copyFile(uploadFile, new File(uploadFilePath)); 
				 content=new String(Files.readAllBytes(Paths.get(uploadFilePath)),Charset.defaultCharset());
				 
				
				 
			 }else if(content!=null && content.trim().length()!=0){
				 FileUtil.writeToFile(uploadFilePath, content);
			 }
				
			File dir = new File(uploadDirPath);
			File stores[]=dir.listFiles();
			StringBuffer sb = new StringBuffer();
			for(File filestore:stores){
				sb.append(filestore.getName());
				sb.append(";");
			}
			fileList = sb.toString();
			
	    	return "success";
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			addActionError("System error"+e.getMessage());
			return "error";
		}
	}

	public void downloadData() {
		
		 try {
			 File file = new File(uploadFilePath);
			if(file.exists()){
				System.out.println("Setting download file");
				downLoadInputStream = new FileInputStream(uploadFilePath);				
			}
			
	    	return "success";
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			addActionError("System error"+e.getMessage());
			return "error";
		}
	}

}
