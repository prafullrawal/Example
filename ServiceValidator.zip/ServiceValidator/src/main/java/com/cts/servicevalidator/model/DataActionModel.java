package com.cts.servicevalidator.model;

import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class DataActionModel {

	String testName;
	String username;
	String type;
	File uploadFile;
	String uploadFilePath;
	String uploadDirPath;
	String content;
	FileInputStream downLoadInputStream;
	String fileList;
	List<String> displayList = new ArrayList<String>(Arrays.asList("Input","Expected","Actual"));
	
	public String getTestName() {
		return testName;
	}
	public void setTestName(String testName) {
		this.testName = testName;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public File getUploadFile() {
		return uploadFile;
	}
	public void setUploadFile(File uploadFile) {
		this.uploadFile = uploadFile;
	}
	public String getUploadFilePath() {
		return uploadFilePath;
	}
	public void setUploadFilePath(String uploadFilePath) {
		this.uploadFilePath = uploadFilePath;
	}
	public String getUploadDirPath() {
		return uploadDirPath;
	}
	public void setUploadDirPath(String uploadDirPath) {
		this.uploadDirPath = uploadDirPath;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public FileInputStream getDownLoadInputStream() {
		return downLoadInputStream;
	}
	public void setDownLoadInputStream(FileInputStream downLoadInputStream) {
		this.downLoadInputStream = downLoadInputStream;
	}
	public String getFileList() {
		return fileList;
	}
	public void setFileList(String fileList) {
		this.fileList = fileList;
	}
	public List<String> getDisplayList() {
		return displayList;
	}
	public void setDisplayList(List<String> displayList) {
		this.displayList = displayList;
	}
	
}
