package com.cts.servicevalidator.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ExecuteActionController {

	@RequestMapping("/ExecuteAction/executeTest")
	public String executeTest() {
		return "ExecuteTest";
	}
}
