package com.cts.servicevalidator.controller;

import java.io.File;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.cts.servicevalidator.service.SecurityActionService;

@Controller
public class SecurityActionController {

	@Autowired
	SecurityActionService securityActionService;
	
	@RequestMapping(path = "/loadSecurityProperties.action")
	public String loadSecurityProperties(@RequestParam("testName") String testName,@RequestParam("username") String username, @RequestParam("rand") String rand, Map<String,Object> model) {
		List result = securityActionService.loadSecurityProperties(testName,username,rand);
		String forward = "";
		if(result.get(0).equals("success")) {
			model.put("testName",testName);
			model.put("username",username);
			model.put("targetPath",result.get(1));
			model.put("confContent",result.get(2));
			forward = "SecurityProperties.jsp";
		}
		else if(result.get(1).equals("error")) {
			model.put("testName",testName);
			model.put("username",username);
			model.put("actionerror", result.get(1));
			forward = "SecurityProperties.jsp";
		}
		
		return forward;
	}
	
	@RequestMapping("/saveSecurityProperties.action")
	public String saveSecurityProperties(@RequestParam("username") String username,@RequestParam("testName") String testName,
			   @RequestParam("targetPath") String targetPath,@RequestParam("confContent") String confContent,@RequestParam("certFile") MultipartFile certFile,Map<String,Object> model) {
		List result = securityActionService.saveSecurityProperties(username,testName,targetPath,confContent);
		String forward = "";
		if(result.get(0).equals("success")) {
			model.put("testName",testName);
			model.put("username",username);
			model.put("targetPath",targetPath);
			model.put("confContent",confContent);
			forward = "SecurityProperties.jsp";
		}
		else if(result.get(1).equals("error")) {
			model.put("testName",testName);
			model.put("username",username);
			model.put("targetPath",targetPath);
			model.put("actionerror", result.get(1));
			forward = "SecurityProperties.jsp";
		}
		return forward;
	}
	
	@RequestMapping("/reloadSecurityProperties.action")
	public String reloadSecurityProperties(@RequestParam("username") String username,@RequestParam("testName") String testName,
			   @RequestParam("targetPath") String targetPath,@RequestParam("confContent") String confContent,@RequestParam("certFile") MultipartFile certFile,Map<String,Object> model) {
		List result =securityActionService.reloadSecurityProperties(username,testName);
		String forward = "";
		if(result.get(0).equals("success")) {
			model.put("testName",testName);
			model.put("username",username);
			model.put("targetPath",targetPath);
			model.put("confContent",result.get(1));
			forward = "SecurityProperties.jsp";
		}
		else if(result.get(1).equals("error")) {
			model.put("testName",testName);
			model.put("username",username);
			model.put("targetPath",targetPath);
			model.put("confContent", confContent);
			model.put("actionerror", result.get(1));
			forward = "SecurityProperties.jsp";
		}
		return forward;
	}
}
