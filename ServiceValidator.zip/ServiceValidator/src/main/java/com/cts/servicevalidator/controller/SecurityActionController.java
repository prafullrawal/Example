package com.cts.servicevalidator.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class SecurityActionController {

	@RequestMapping("/SecurityAction/loadSecurityProperties")
	public String loadSecurityProperties() {
		return "String";
	}
	
	@RequestMapping("/SecurityAction/saveSecurityProperties")
	public String saveSecurityProperties() {
		return "String";
	}
	
	@RequestMapping("/SecurityAction/reloadSecurityProperties")
	public String reloadSecurityProperties() {
		return "String";
	}
}
