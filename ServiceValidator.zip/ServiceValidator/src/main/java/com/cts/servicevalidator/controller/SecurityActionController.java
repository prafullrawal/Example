package com.cts.servicevalidator.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.servicevalidator.service.SecurityActionService;

@Controller
public class SecurityActionController {

	@Autowired
	SecurityActionService securityActionService;
	
	@RequestMapping("/loadSecurityProperties.action")
	public String loadSecurityProperties() {
		String result = securityActionService.loadSecurityProperties("","");
		String forward = "";
		if(result=="success")
			forward = "";
		else if(result=="error")
			forward = "";
		
		return forward;
	}
	
	@RequestMapping("/saveSecurityProperties.action")
	public String saveSecurityProperties() {
		String result = securityActionService.saveSecurityProperties();
		String forward = "";
		if(result=="success")
			forward = "";
		else if(result=="error")
			forward = "";
		
		return forward;
	}
	
	@RequestMapping("/reloadSecurityProperties.action")
	public String reloadSecurityProperties() {
		String result =securityActionService.reloadSecurityProperties();
		String forward = "";
		if(result=="success")
			forward = "";
		else if(result=="error")
			forward = "";
		
		return forward;
	}
}
