package com.cts.servicevalidator.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cts.servicevalidator.service.PropertiesActionService;

@Controller
public class PropertiesActionController {

	@Autowired
	PropertiesActionService propertiesActionService;
	
	@RequestMapping("/loadProtocol.action")
	public String loadProtocol(@RequestParam("type") String type,@RequestParam("username") String username,@RequestParam("testName") String testName,@RequestParam("protocol") String protocol) {
		
		String result = propertiesActionService.loadProtocol(type, username, testName, protocol);
		String forward = "";
		if(result=="success")
			forward = "";
		else if(result=="error")
			forward = "";
		
		return forward;
	}
	
	@RequestMapping("/saveProtocol.action")
	public String saveProtocol() {
		String result = propertiesActionService.saveProtocol();
		String forward = "";
		if(result=="success")
			forward = "";
		else if(result=="error")
			forward = "";
		
		return forward;
	}
	
	@RequestMapping("/reloadProperties.action")
	public String reloadProperties() {
		String result = propertiesActionService.reloadProperties();
		String forward = "";
		if(result=="success")
			forward = "";
		else if(result=="error")
			forward = "";
		
		return forward;
	}
}
