package com.cts.servicevalidator.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.servicevalidator.service.PropertiesActionService;

@Controller
public class PropertiesActionController {

	@Autowired
	PropertiesActionService propertiesActionService;
	
	@RequestMapping("/loadProtocol.action")
	public String loadProtocol() {
		
		propertiesActionService.loadProtocol();
		return "String";
	}
	
	@RequestMapping("/saveProtocol.action")
	public String saveProtocol() {
		propertiesActionService.saveProtocol();
		return "String";
	}
	
	@RequestMapping("/reloadProperties.action")
	public String reloadProperties() {
		propertiesActionService.reloadProperties();
		return "String";
	}
}
