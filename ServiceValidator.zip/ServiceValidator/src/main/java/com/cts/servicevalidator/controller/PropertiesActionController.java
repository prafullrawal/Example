package com.cts.servicevalidator.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cts.servicevalidator.service.PropertiesActionService;

@Controller
public class PropertiesActionController {

	@Autowired
	PropertiesActionService propertiesActionService;
	
	
	@RequestMapping("/loadProtocolProperties.action")
	public String loadProtocol(@RequestParam("type") String type,@RequestParam("username") String username,@RequestParam("testName") String testName,
							   @RequestParam("protocol") String protocol, Map<String,Object> model) {
		
		List result = propertiesActionService.loadProtocol(type, username, testName, protocol);
		String forward = "";
		if(result!=null && result.get(0)!=null) {
				if(result.get(0).equals("success")) {
					model.put("type",type);
					model.put("username",username);
					model.put("testName",testName);
					model.put("protocol",protocol);
					model.put("targetPath",result.get(1));
					model.put("confContent",result.get(2));
					forward = "ProtocolProperties";
				}
				
				else if(result.get(0).equals("error")) {
					model.put("actionerror", "Error or file not found "+result.get(1));
					model.put("type",type);
					model.put("username",username);
					model.put("testName",testName);
					model.put("protocol",protocol);
					model.put("targetPath",result.get(2));
					model.put("confContent",result.get(3));
					forward = "ProtocolProperties";
				}
		} else {		
			model.put("actionerror", "Invalid properties loaded");
		}
		
		return forward;	
	}
	
	@RequestMapping("/saveProtocol.action")
	public String saveProtocol(@RequestParam("type") String type,@RequestParam("username") String username,@RequestParam("testName") String testName,
			   @RequestParam("protocol") String protocol,@RequestParam("confContent") String confContent,@RequestParam("targetPath") String targetPath, Map<String,Object> model) {
		List result = propertiesActionService.saveProtocol(targetPath,confContent);
		String forward = "";
		if(result!=null && result.get(0)!=null) {
				if(result.get(0).equals("success")) {
					model.put("type",type);
					model.put("username",username);
					model.put("testName",testName);
					model.put("protocol",protocol);
					model.put("targetPath",targetPath);
					model.put("confContent",confContent);
					forward = "ProtocolProperties";
				}
				
				else if(result.get(0).equals("error")) {
					model.put("actionerror", "Error "+result.get(1));
					model.put("type",type);
					model.put("username",username);
					model.put("testName",testName);
					model.put("protocol",protocol);
					model.put("targetPath",targetPath);
					model.put("confContent",confContent);
					forward = "ProtocolProperties";
				}
		} else {		
			model.put("actionerror", "Invalid properties loaded");
		}
		return forward;	
	}
	
	@RequestMapping("/reloadProperties.action")
	public String reloadProperties(@RequestParam("type") String type,@RequestParam("username") String username,@RequestParam("testName") String testName,
			   @RequestParam("protocol") String protocol,@RequestParam("confContent") String confContent,@RequestParam("targetPath") String targetPath, Map<String,Object> model) {
		
		List result = propertiesActionService.reloadProperties(protocol);
		String forward = "";
		if(result!=null && result.get(0)!=null) {
				if(result.get(0).equals("success")) {
					model.put("type",type);
					model.put("username",username);
					model.put("testName",testName);
					model.put("protocol",protocol);
					model.put("targetPath",targetPath);
					model.put("confContent",confContent);
					forward = "ProtocolProperties";
				}
				
				else if(result.get(0).equals("error")) {
					model.put("actionerror", "Error "+result.get(1));
					model.put("type",type);
					model.put("username",username);
					model.put("testName",testName);
					model.put("protocol",protocol);
					model.put("targetPath",targetPath);
					model.put("confContent",confContent);
					forward = "ProtocolProperties";
				}
		} else {		
			model.put("actionerror", "Invalid properties loaded");
		}
		return forward;	
	}
}
