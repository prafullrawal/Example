package com.cts.servicevalidator.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class PropertiesActionController {

	@RequestMapping("/PropertiesAction/loadProtocol")
	public String loadProtocol() {
		return "String";
	}
	
	@RequestMapping("/PropertiesAction/saveProtocol")
	public String saveProtocol() {
		return "String";
	}
	
	@RequestMapping("/PropertiesAction/reloadProperties")
	public String reloadProperties() {
		return "String";
	}
}
