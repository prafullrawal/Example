package com.cts.servicevalidator.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;
import java.lang.Object;

import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.integration.dto.IJunitConstants;
import com.cts.integration.dto.TestCaseDTO;
import com.cts.integration.util.ExcelUtil;
import com.cts.servicevalidator.contants.UIConstants;
import com.cts.servicevalidator.model.ServiceValidatorActionModel;



@Service
public class ServiceValidatorActionService {

	@Autowired
	DataActionService dataActionService;
	
	ServiceValidatorActionModel serviceValidatorActionModel = new ServiceValidatorActionModel();
	

	public String newuserlogin(String username, String password) {

		boolean useradded = false;
		Properties prop = new Properties();
		String key = null, value = null;

		String propertiesFileLocation = UIConstants.WEBROOT + File.separator + UIConstants.DEFAULT_USER_FILE;

		try {
			System.out.println("Loading properties file .............. " + propertiesFileLocation);
			FileInputStream input = new FileInputStream(propertiesFileLocation);

			prop.load(input);
			System.out.println("Completed properties file loading .............. ");

			Enumeration objEn = prop.keys();
			while (objEn.hasMoreElements()) {
				key = objEn.nextElement().toString();
				value = prop.getProperty(key.toString());

				if ((username.contentEquals(key)) && (password.contentEquals(value)))

				{
					useradded = false;
					return "error";

				} else {
					useradded = true;

				}

			}

			if (useradded == true) {
				FileOutputStream output = new FileOutputStream(propertiesFileLocation, true);
				dataActionService.appendToFile(propertiesFileLocation, username + "=" + password, output);
				System.out.println("Created User .............. ");
			} else {
				System.out.println(" User is already exists.............. ");
			}

		} catch (Exception e) {
			System.out.println("Error while loading the UserProfile propertyfile " + e.getMessage());

		}

		if (useradded == true) {
			return "success";
		} else {
//			/addActionError(getText("error.create"));
			return "error";
		}

	}
	

	public String existinguserlogin(String username, String password) {

		
			boolean foundUser = false;
			Properties prop = new Properties();
			String key = null, value = null;
			ArrayList objList = new ArrayList();
			HashMap<String, String> map = new HashMap<String, String>();

			String propertiesFileLocation = UIConstants.WEBROOT + File.separator + UIConstants.DEFAULT_USER_FILE;

			try {
				System.out.println("Loading properties file .............. " + propertiesFileLocation);
				FileInputStream input = new FileInputStream(propertiesFileLocation);
				prop.load(input);

				Enumeration objEn = prop.keys();
				while (objEn.hasMoreElements()) {
					key = objEn.nextElement().toString();
					value = prop.getProperty(key.toString());

					if ((username.contentEquals(key)) && (password.contentEquals(value)))

					{
						foundUser = true;
						System.out.println("User is Authorized .............. ");
						return "success";
					} else {
						foundUser = false;
						System.out.println("User is UnAuthorized .............. ");
					}

				}

			} catch (Exception e) {
				System.out.println("Error while loading the UserProfile propertyfile " + e.getMessage());

			}

			if (foundUser == true) {
				return "success";
			} else {
				//addActionError(getText("error.login"));
				return "error";
			}
	}


	public List<Object> profilelogin(String username) {
		
		List forward = new ArrayList();
		
		File dir = new File(UIConstants.WEBROOT);
		File[] files = dir.listFiles();
		if (files.length < 1) {
			File newfile = new File(UIConstants.WEBROOT + File.separator + "Sample");
			newfile.mkdir();
		}
		boolean foundprofile = false;
		System.setProperty("javax.net.ssl.trustStore",
				"C:\\Program Files (x86)\\Java\\jre1.8.0_191\\lib\\security\\cacerts");
		System.out.println("Trust store =>" + System.getProperty("javax.net.ssl.trustStore"));
		System.out.println("Profile Path => " + UIConstants.WEBROOT);
		try {
			for (File file : files) {
				if (file.isDirectory() && file.getName().equals(username)) {
					foundprofile = true;
					String tesPlanFile = UIConstants.WEBROOT + File.separator + username + File.separator
							+ IJunitConstants.DEFAULT_TEST_INPUT_EXCEL;
					File testPlan = new File(tesPlanFile);
					if (testPlan.exists()) {
						serviceValidatorActionModel.setTestCases(ExcelUtil.readExcel(tesPlanFile));
						if (serviceValidatorActionModel.getTestCases().size() > 0) {

							for (int i = 1; i < serviceValidatorActionModel.getTestCases().size(); i++) {
								List<String> ignoredList = serviceValidatorActionModel.getTestCases().get(i).getIgnoreList();
								StringBuffer sb = new StringBuffer();
								int count = 0;
								for (String element : ignoredList) {
									if (count == 0) {
										sb.append(element);
									} else {
										sb.append(",");
										sb.append(element);
									}
									count++;
								}
								serviceValidatorActionModel.getIgnoreFields().add(sb.toString());
							}

							// removing excel header
							serviceValidatorActionModel.getTestCases().remove(0);
						}
					}

					if (serviceValidatorActionModel.getTestCases().size() == 0) {
						// adding empty first row
						TestCaseDTO emptyTest = new TestCaseDTO();
						serviceValidatorActionModel.getTestCases().add(emptyTest);
					}

					System.out.println("No of test cases " + serviceValidatorActionModel.getTestCases().size());
					break;
				}
			}

			if (foundprofile == true) {
				forward.add("success");
				JSONObject json = new JSONObject();
				json.put("protocolList", serviceValidatorActionModel.getProtocolList());
				json.put("formatList", serviceValidatorActionModel.getFormatList());
				json.put("patternList", serviceValidatorActionModel.getPatternList());
				json.put("activeList", serviceValidatorActionModel.getActiveList());
				
				forward.add(json);
				return forward;
			} else {
				//addActionError(getText("error.profile"));
				forward.add("error");
				return forward;
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			//addActionError("System error" + e.getMessage());
			forward.add("error");
			return forward;
		}
		
	}


	public String addTestCase(String newTestCase, String newTestCaseDescription, String newTestCaseEndpoint,
			String newTestCaseLegacyEndPont, String newTestCaseNewIgnoreField, String newTestCasePatternList,
			String newTestCaseSourceFormat, String newTestCaseSourceProtocol, String newTestCaseTargetFormat,
			String newTestCaseTargetProtocol) {
		
		
		try {
    	 	setAdded(true);
 	    	if(newTestCase.getTestCase() != null && newTestCase.getTestCase().trim().length()>0){
 	    		testCases.add(newTestCase);
 	    		ignoreFields.add(newIgnoreField);
 	    		if(newIgnoreField!=null && newIgnoreField.trim().length()>0){
 	    			String ignoreSplits[]= newIgnoreField.split(",");
 	    			newTestCase.setIgnoreList(Arrays.asList(ignoreSplits));
 	    		}
 	    		newIgnoreField=new String();
 	    		File testDir = new File(UIConstants.WEBROOT+File.separator+this.username+File.separator+newTestCase.getTestCase());
 	    		System.out.println("directory exists "+testDir.exists());
 	    		System.out.println("directory localtion "+testDir.getAbsolutePath());
 	    		if(!testDir.exists()){
 	    			testDir.mkdir();
 	    		}
 	    	}
 	    	newTestCase = new TestCaseDTO();
 	    	System.out.println(" List size "+testCases.size());
    	return "success";
		
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		//addActionError("System error"+e.getMessage());
		return "error";
	}
		
	}
	
	
}
