package com.cts.servicevalidator.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.io.IOUtils;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
//mport org.apache.struts2.ServletActionContext;
//import org.apache.struts2.ServletActionContext;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.junit.Ignore;
import org.junit.runner.JUnitCore;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.integration.dto.ExcelColumnConstants;
import com.cts.integration.dto.IJunitConstants;
import com.cts.integration.dto.TestCaseDTO;
import com.cts.integration.dto.TestConfDTO;
import com.cts.integration.factory.TestCaseFactory;
import com.cts.integration.unitTest.executer.IJunitExecuter;
import com.cts.integration.util.DBUtil;
import com.cts.integration.util.ExcelUtil;
import com.cts.servicevalidator.contants.UIConstants;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;

import junit.framework.TestCase;
import junit.framework.TestResult;

@Service
public class ServiceValidatorActionService {

	@Autowired
	DataActionService dataActionService;

	private static final long serialVersionUID = 1L;
	private String username;
	private String password;
	private List<TestCaseDTO> testCases = new ArrayList<TestCaseDTO>();
	private List<TestCaseDTO> testReports = new ArrayList<TestCaseDTO>();
	private String deletedTestCaseName;
	private List<Boolean> checkLists = new ArrayList<Boolean>();
	private List<String> protocolList = new ArrayList<String>(Arrays.asList("", IJunitConstants.PROTOCOL_DB,
			IJunitConstants.PROTOCOL_FILE, IJunitConstants.PROTOCOL_FILE_ADVANCED, IJunitConstants.PROTOCOL_FTP,
			IJunitConstants.PROTOCOL_HTTP, IJunitConstants.PROTOCOL_HTTP_GET, IJunitConstants.PROTOCOL_HTTP_POST,
			IJunitConstants.PROTOCOL_JMS, IJunitConstants.PROTOCOL_MQ, IJunitConstants.PROTOCOL_SFTP));
	private List<String> formatList = new ArrayList<String>(Arrays.asList("", IJunitConstants.FORMAT_XML,
			IJunitConstants.FORMAT_JSON, IJunitConstants.FORMAT_TXT, IJunitConstants.FORMAT_UNKNOWN));
	private List<String> patternList = new ArrayList<String>(
			Arrays.asList(IJunitConstants.PATTERN_SYNCH, IJunitConstants.PATTERN_ASYNCH));
	private List<String> activeList = new ArrayList<String>(
			Arrays.asList(IJunitConstants.VALUE_ACTIVE, IJunitConstants.VALUE_INACTIVE));
	private TestCaseDTO newTestCase = new TestCaseDTO();
	private String newIgnoreField;
	private boolean added = false;
	private List<String> ignoreFields = new ArrayList<String>();
	private String logMessage = new String();
	private String profileRoot;
	private String csvReportName;
	private String xmlReportName;
	private String quickReportName;
	private String csvReportPath;
	private String xmlReportPath;
	private String quickReportPath;

	private String downloadReportName;
	private FileInputStream reportInputStream;
	private List<String> reportList = new ArrayList<String>();
	// private SessionMap<String,Object> sessionMap;
	
	private String infoContent;

	
	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public List<TestCaseDTO> getTestCases() {
		return testCases;
	}

	public void setTestCases(List<TestCaseDTO> testCases) {
		this.testCases = testCases;
	}

	public List<TestCaseDTO> getTestReports() {
		return testReports;
	}

	public void setTestReports(List<TestCaseDTO> testReports) {
		this.testReports = testReports;
	}

	public String getDeletedTestCaseName() {
		return deletedTestCaseName;
	}

	public void setDeletedTestCaseName(String deletedTestCaseName) {
		this.deletedTestCaseName = deletedTestCaseName;
	}

	public List<Boolean> getCheckLists() {
		return checkLists;
	}

	public void setCheckLists(List<Boolean> checkLists) {
		this.checkLists = checkLists;
	}

	public List<String> getProtocolList() {
		return protocolList;
	}

	public void setProtocolList(List<String> protocolList) {
		this.protocolList = protocolList;
	}

	public List<String> getFormatList() {
		return formatList;
	}

	public void setFormatList(List<String> formatList) {
		this.formatList = formatList;
	}

	public List<String> getPatternList() {
		return patternList;
	}

	public void setPatternList(List<String> patternList) {
		this.patternList = patternList;
	}

	public List<String> getActiveList() {
		return activeList;
	}

	public void setActiveList(List<String> activeList) {
		this.activeList = activeList;
	}

	public TestCaseDTO getNewTestCase() {
		return newTestCase;
	}

	public void setNewTestCase(TestCaseDTO newTestCase) {
		this.newTestCase = newTestCase;
	}

	public String getNewIgnoreField() {
		return newIgnoreField;
	}

	public void setNewIgnoreField(String newIgnoreField) {
		this.newIgnoreField = newIgnoreField;
	}

	public boolean isAdded() {
		return added;
	}

	public void setAdded(boolean added) {
		this.added = added;
	}

	public List<String> getIgnoreFields() {
		return ignoreFields;
	}

	public void setIgnoreFields(List<String> ignoreFields) {
		this.ignoreFields = ignoreFields;
	}

	public String getLogMessage() {
		return logMessage;
	}

	public void setLogMessage(String logMessage) {
		this.logMessage = logMessage;
	}

	public String getProfileRoot() {
		return profileRoot;
	}

	public void setProfileRoot(String profileRoot) {
		this.profileRoot = profileRoot;
	}

	public String getCsvReportName() {
		return csvReportName;
	}

	public void setCsvReportName(String csvReportName) {
		this.csvReportName = csvReportName;
	}

	public String getXmlReportName() {
		return xmlReportName;
	}

	public void setXmlReportName(String xmlReportName) {
		this.xmlReportName = xmlReportName;
	}

	public String getQuickReportName() {
		return quickReportName;
	}

	public void setQuickReportName(String quickReportName) {
		this.quickReportName = quickReportName;
	}

	public String getCsvReportPath() {
		return csvReportPath;
	}

	public void setCsvReportPath(String csvReportPath) {
		this.csvReportPath = csvReportPath;
	}

	public String getXmlReportPath() {
		return xmlReportPath;
	}

	public void setXmlReportPath(String xmlReportPath) {
		this.xmlReportPath = xmlReportPath;
	}

	public String getQuickReportPath() {
		return quickReportPath;
	}

	public void setQuickReportPath(String quickReportPath) {
		this.quickReportPath = quickReportPath;
	}

	public String getDownloadReportName() {
		return downloadReportName;
	}

	public void setDownloadReportName(String downloadReportName) {
		this.downloadReportName = downloadReportName;
	}

	public FileInputStream getReportInputStream() {
		return reportInputStream;
	}

	public void setReportInputStream(FileInputStream reportInputStream) {
		this.reportInputStream = reportInputStream;
	}

	public List<String> getReportList() {
		return reportList;
	}

	public void setReportList(List<String> reportList) {
		this.reportList = reportList;
	}

	/*
	 * public SessionMap<String, Object> getSessionMap() { return sessionMap; }
	 * public void setSessionMap(SessionMap<String, Object> sessionMap) {
	 * this.sessionMap = sessionMap; }
	 */
	public String getInfoContent() {
		return infoContent;
	}

	public void setInfoContent(String infoContent) {
		this.infoContent = infoContent;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	

	public List addprofile(String username) {
		
		List list = new ArrayList();

		File dir = new File(UIConstants.WEBROOT);
		File[] files = dir.listFiles();
		boolean addprofile = false;

		if (files.length < 1) {
			File newfile = new File(UIConstants.WEBROOT + File.separator + "Sample");
			newfile.mkdir();
		}

		try {
			for (File file : files) {
				if (file.isDirectory() && file.getName().equals(username)) {
					addprofile = false;
					System.out.println("Profile exists " + file.exists());
					System.out.println("Profile localtion " + file.getAbsolutePath());
					// addActionError(getText("error.addprofile"));
					list.add("error");
					list.add("error  addprofile profile exists");
				}

				else {
					addprofile = true;
					File newProflie = new File(UIConstants.WEBROOT + File.separator + username);
					newProflie.mkdir();
					System.out.println("Created New profile " + newProflie.exists());
				}
			}

			if (addprofile) {
				
				list.add("success");
				ServiceValidatorActionService serviceValidatorActionService = new ServiceValidatorActionService();
				serviceValidatorActionService.setUsername(username);
				
				ObjectMapper mapper = new ObjectMapper();
				String jsonString = mapper.writeValueAsString(serviceValidatorActionService);

				JSONParser parser = new JSONParser();
				JSONObject json = (JSONObject) parser.parse(jsonString);
				
				list.add(json);
				
			} else {

				//// addActionError(getText("error.add"));
				list.add("error");
				list.add("error adding new profile");

			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			//// addActionError("System error"+e.getMessage());
			list.add("error");
			list.add("System error"+e.getMessage());
		}
		
		return list;
	}

	public List profilelogin(String profilename) {

		List forward = new ArrayList();

		// System.out.println(this.username);

		File dir = new File(UIConstants.WEBROOT);
		File[] files = dir.listFiles();
		if (files.length < 1) {
			File newfile = new File(UIConstants.WEBROOT + File.separator + "Sample");
			newfile.mkdir();
		}
		boolean foundprofile = false;
		System.setProperty("javax.net.ssl.trustStore",
				"C:\\Program Files (x86)\\Java\\jre1.8.0_191\\lib\\security\\cacerts");
		System.out.println("Trust store =>" + System.getProperty("javax.net.ssl.trustStore"));
		System.out.println("Profile Path => " + UIConstants.WEBROOT);
		try {
			for (File file : files) {
				if (file.isDirectory() && file.getName().equals(profilename)) {
					foundprofile = true;
					String tesPlanFile = UIConstants.WEBROOT + File.separator + profilename + File.separator
							+ IJunitConstants.DEFAULT_TEST_INPUT_EXCEL;
					File testPlan = new File(tesPlanFile);
					if (testPlan.exists()) {
						testCases = ExcelUtil.readExcel(tesPlanFile);
						if (testCases.size() > 0) {

							for (int i = 1; i < testCases.size(); i++) {
								List<String> ignoredList = testCases.get(i).getIgnoreList();
								StringBuffer sb = new StringBuffer();
								int count = 0;
								for (String element : ignoredList) {
									if (count == 0) {
										sb.append(element);
									} else {
										sb.append(",");
										sb.append(element);
									}
									count++;
								}
								ignoreFields.add(sb.toString());
							}

							// removing excel header
							testCases.remove(0);
						}
					}

					if (testCases.size() == 0) {
						// adding empty first row
						TestCaseDTO emptyTest = new TestCaseDTO();
						testCases.add(emptyTest);
					}

					System.out.println("No of test cases " + testCases.size());
					break;
				}
			}
			ServiceValidatorActionService serviceValidatorActionService = new ServiceValidatorActionService();
			serviceValidatorActionService.setTestCases(testCases);
			serviceValidatorActionService.setIgnoreFields(ignoreFields);
			serviceValidatorActionService.setUsername(profilename);
			serviceValidatorActionService.setPassword(password);

			ObjectMapper mapper = new ObjectMapper();
			String jsonString = mapper.writeValueAsString(serviceValidatorActionService);

			JSONParser parser = new JSONParser();
			JSONObject json = (JSONObject) parser.parse(jsonString);

			System.out.println(json);

			if (foundprofile == true) {

				forward.add("success");
				forward.add(json);

				return forward;

			} else {
				// addActionError(getText("error.profile"));

				forward.add("error");
				return forward;
			}
		} catch (Exception e) {

			e.printStackTrace();
			//// addActionError("System error"+e.getMessage());
			forward.add("error");
			return forward;
		}
	}

	public String existinguserlogin(String username, String password) {

		boolean foundUser = false;
		Properties prop = new Properties();
		String key = null, value = null;
		ArrayList objList = new ArrayList();
		HashMap<String, String> map = new HashMap<String, String>();

		this.username = username;
		this.password = password;

		String propertiesFileLocation = UIConstants.WEBROOT + File.separator + UIConstants.DEFAULT_USER_FILE;

		try {
			System.out.println("Loading properties file .............. " + propertiesFileLocation);
			FileInputStream input = new FileInputStream(propertiesFileLocation);
			prop.load(input);

			Enumeration objEn = prop.keys();
			while (objEn.hasMoreElements()) {
				key = objEn.nextElement().toString();
				value = prop.getProperty(key.toString());

				if ((this.username.contentEquals(key)) && (this.password.contentEquals(value)))

				{
					foundUser = true;
					System.out.println("User is Authorized .............. ");
					return "success";
				} else {
					foundUser = false;
					System.out.println("User is UnAuthorized .............. ");
				}

			}

		} catch (Exception e) {
			System.out.println("Error while loading the UserProfile propertyfile " + e.getMessage());

		}

		if (foundUser == true) {
			return "success";
		} else {
			//// addActionError(getText("error.login"));
			return "error";
		}

	}

	public String newuserlogin(String username, String password) {

		boolean useradded = false;
		Properties prop = new Properties();
		String key = null, value = null;

		String propertiesFileLocation = UIConstants.WEBROOT + File.separator + UIConstants.DEFAULT_USER_FILE;

		try {
			System.out.println("Loading properties file .............. " + propertiesFileLocation);
			FileInputStream input = new FileInputStream(propertiesFileLocation);

			prop.load(input);
			System.out.println("Completed properties file loading .............. ");

			Enumeration objEn = prop.keys();
			while (objEn.hasMoreElements()) {
				key = objEn.nextElement().toString();
				value = prop.getProperty(key.toString());

				if ((username.contentEquals(key)) && (password.contentEquals(value)))

				{
					useradded = false;
					return "error";

				} else {
					useradded = true;

				}

			}

			if (useradded == true) {
				FileOutputStream output = new FileOutputStream(propertiesFileLocation, true);
				DataActionService.appendToFile(propertiesFileLocation, username + "=" + password, output);
				System.out.println("Created User .............. ");
			} else {
				System.out.println(" User is already exists.............. ");
			}

		} catch (Exception e) {
			System.out.println("Error while loading the UserProfile propertyfile " + e.getMessage());

		}

		if (useradded == true) {
			return "success";
		} else {
			// addActionError(getText("error.create"));
			return "error";
		}

	}

	public List<Object> save(Map<String, String> requestParams) {

		List forward = new ArrayList();

		System.out.println("List size " + testCases.size());
		try {
			// System.out.println("name :"+testCases.get(0).getTestCase());

			String classObject = requestParams.get("serviceValidatorModel");
			ServiceValidatorActionService serviceValidatorActionService = new ObjectMapper().readValue(classObject,
					ServiceValidatorActionService.class);

			writeXLSXFile(serviceValidatorActionService);
			serviceValidatorActionService.setAdded(false);

			forward.add("success");

			ObjectMapper mapper = new ObjectMapper();
			String jsonString = mapper.writeValueAsString(serviceValidatorActionService);

			JSONParser parser = new JSONParser();
			JSONObject json = (JSONObject) parser.parse(jsonString);

			forward.add(json);
			return forward;

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			//// addActionError("System error"+e.getMessage());

			forward.add("error");
			return forward;
		}
	}

	public List add(Map<String, String> requestParams) throws JsonParseException, JsonMappingException, IOException {

		List forward = new ArrayList();

		String classObject = requestParams.get("serviceValidatorModel");
		ServiceValidatorActionService serviceValidatorActionService = new ObjectMapper().readValue(classObject,
				ServiceValidatorActionService.class);

		testCases = serviceValidatorActionService.getTestCases();

		newIgnoreField = requestParams.get("newTestCase.ignoreField");

		List<String> ignoreFields = serviceValidatorActionService.getIgnoreFields();
		ignoreFields.add(newIgnoreField);
		serviceValidatorActionService.setIgnoreFields(ignoreFields);

		this.username = requestParams.get("username");

		newTestCase.setTestCase(requestParams.get("newTestCase.testCase"));
		newTestCase.setDescription(requestParams.get("newTestCase.description"));
		newTestCase.setPattern(requestParams.get("newTestCase.pattern"));
		newTestCase.setSourceProtocol(requestParams.get("newTestCase.sourceProtocol"));
		newTestCase.setSourceFormat(requestParams.get("newTestCase.sourceFormat"));
		newTestCase.setTargetProtocol(requestParams.get("newTestCase.targetProtocol"));
		newTestCase.setTargetFormat(requestParams.get("newTestCase.targetFormat"));
		newTestCase.setEndpoint(requestParams.get("newTestCase.endpoint"));
		newTestCase.setLegacyEndPont(requestParams.get("newTestCase.legacyEndPont"));
		newTestCase.setIsActive("ACTIVE");

		try {
			serviceValidatorActionService.setAdded(true);
			if (newTestCase.getTestCase() != null && newTestCase.getTestCase().trim().length() > 0) {
				testCases.add(newTestCase);
				ignoreFields.add(newIgnoreField);
				if (newIgnoreField != null && newIgnoreField.trim().length() > 0) {
					String ignoreSplits[] = newIgnoreField.split(",");
					newTestCase.setIgnoreList(Arrays.asList(ignoreSplits));
				}
				newIgnoreField = new String();
				File testDir = new File(UIConstants.WEBROOT + File.separator + this.username + File.separator
						+ newTestCase.getTestCase());
				System.out.println("directory exists " + testDir.exists());
				System.out.println("directory localtion " + testDir.getAbsolutePath());
				if (!testDir.exists()) {
					testDir.mkdir();
				}
			}
			newTestCase = new TestCaseDTO();
			System.out.println(" List size " + testCases.size());

			serviceValidatorActionService.setTestCases(testCases);
			serviceValidatorActionService.setNewTestCase(newTestCase);

			ObjectMapper mapper = new ObjectMapper();
			String jsonString = mapper.writeValueAsString(serviceValidatorActionService);

			JSONParser parser = new JSONParser();
			JSONObject json = (JSONObject) parser.parse(jsonString);

			forward.add("success");
			forward.add(json);

			return forward;

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			//// addActionError("System error"+e.getMessage());
			forward.add("error");
			return forward;
		}
	}

	public List delete(Map<String, String> requestParams) {

		List forward = new ArrayList();

		try {
			/// System.out.println("invoked delete for : "+checkLists );

			String classObject = requestParams.get("serviceValidatorModel");
			ServiceValidatorActionService serviceValidatorActionService = new ObjectMapper().readValue(classObject,
					ServiceValidatorActionService.class);
			String deletedTestCaseName = requestParams.get("deletedTestCaseName");

			System.out.println("no of test cases : " + testCases.size());
			System.out.println("deletedTestCaseName index : " + deletedTestCaseName);
			serviceValidatorActionService.getTestCases().remove(Integer.parseInt(deletedTestCaseName));
			// System.out.println("checkiList size : "+checkLists.size() );
			/*
			 * List<TestCaseDTO> copyTestCases = new ArrayList<TestCaseDTO>(); int i=0;
			 * for(Boolean check:checkLists){ if(!check.booleanValue()){
			 * copyTestCases.add(testCases.get(i)); } i++;
			 * 
			 * 
			 * } testCases=copyTestCases; checkLists.clear();
			 */
			System.out.println("Returning success");
			ObjectMapper mapper = new ObjectMapper();
			String jsonString = mapper.writeValueAsString(serviceValidatorActionService);

			JSONParser parser = new JSONParser();
			JSONObject json = (JSONObject) parser.parse(jsonString);

			forward.add("success");
			forward.add(json);

			return forward;

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			//// addActionError("System error"+e.getMessage());
			forward.add("error");
			return forward;
		}
	}

	public void writeXLSXFile(ServiceValidatorActionService serviceValidatorActionService) throws Exception {

		this.username = serviceValidatorActionService.getUsername();
		testCases = serviceValidatorActionService.getTestCases();
		ignoreFields = serviceValidatorActionService.getIgnoreFields();

		XSSFWorkbook wb = null;
		FileOutputStream fileOut = null;
		try {
			System.out.println("Entered writeXLSXFile() : ");
			String excelFileName = UIConstants.WEBROOT + File.separator + this.username + File.separator
					+ IJunitConstants.DEFAULT_TEST_INPUT_EXCEL;// name of excel file

			System.out.println("ExcelSheet Name: " + excelFileName);

			String sheetName = ExcelColumnConstants.DEFAULT_SHEET_NAME;// name of sheet

			System.out.println("Excelsheet Tab Name: " + sheetName);

			wb = new XSSFWorkbook();
			XSSFSheet sheet = wb.createSheet(sheetName);
			int noOfrows = testCases.size();
			// create header
			XSSFRow row = sheet.createRow(0);
			XSSFCell cell = row.createCell(0);
			cell.setCellValue("Sl No");
			cell = row.createCell(1);
			cell.setCellValue("Test Case");
			cell = row.createCell(2);
			cell.setCellValue("Description");
			cell = row.createCell(3);
			cell.setCellValue("Pattern");
			cell = row.createCell(4);
			cell.setCellValue("Source Protocol");
			cell = row.createCell(5);
			cell.setCellValue("Source Format");
			cell = row.createCell(6);
			cell.setCellValue("Target Protocol");
			cell = row.createCell(7);
			cell.setCellValue("Target Format");
			cell = row.createCell(8);
			cell.setCellValue("Security Info");
			cell = row.createCell(9);
			cell.setCellValue("End Point");
			cell = row.createCell(10);
			cell.setCellValue("Legacy End Point");
			cell = row.createCell(11);
			cell.setCellValue("Source Info");
			cell = row.createCell(12);
			cell.setCellValue("Target Info");
			cell = row.createCell(13);
			cell.setCellValue("Input");
			cell = row.createCell(14);
			cell.setCellValue("Expected Output");
			cell = row.createCell(15);
			cell.setCellValue("Actual Output");
			cell = row.createCell(16);
			cell.setCellValue("Digital Signature");
			cell = row.createCell(17);
			cell.setCellValue("Ignore List");
			cell = row.createCell(18);
			cell.setCellValue("Active");
			cell = row.createCell(19);
			cell.setCellValue("Header Info");

			System.out.println(testCases.toString());
			// iterating r number of rows
			for (int r = 0; r < noOfrows; r++) {
				row = sheet.createRow(r + 1);
				cell = row.createCell(0);
				cell.setCellValue(r + 1);
				cell = row.createCell(1);
				cell.setCellValue(testCases.get(r).getTestCase().trim());
				cell = row.createCell(2);
				cell.setCellValue(testCases.get(r).getDescription().trim());
				cell = row.createCell(3);
				cell.setCellValue(testCases.get(r).getPattern().trim());
				cell = row.createCell(4);
				cell.setCellValue(testCases.get(r).getSourceProtocol().trim());
				cell = row.createCell(5);
				cell.setCellValue(testCases.get(r).getSourceFormat().trim());
				cell = row.createCell(6);
				cell.setCellValue(testCases.get(r).getTargetProtocol().trim());
				cell = row.createCell(7);
				cell.setCellValue(testCases.get(r).getTargetFormat().trim());
				cell = row.createCell(8);
				// cell.setCellValue(r+1);
				cell = row.createCell(9);
				cell.setCellValue(testCases.get(r).getEndpoint().trim());
				cell = row.createCell(10);
				cell.setCellValue(testCases.get(r).getLegacyEndPont().trim());
				cell = row.createCell(11);
				// cell.setCellValue(r+1);
				cell = row.createCell(12);
				// cell.setCellValue(r+1);
				cell = row.createCell(13);
				// cell.setCellValue(r+1);
				cell = row.createCell(14);
				// cell.setCellValue(r+1);
				cell = row.createCell(15);
				// cell.setCellValue(r+1);
				cell = row.createCell(16);
				// cell.setCellValue(r+1);
				cell = row.createCell(17);
				cell.setCellValue(ignoreFields.get(r).trim());
				cell = row.createCell(18);
				System.out.println("**" + r + "**");
				System.out.println(testCases.get(r).getIsActive());
				cell.setCellValue(testCases.get(r).getIsActive().trim());

			}

			fileOut = new FileOutputStream(excelFileName);

			// write this workbook to an Outputstream.

		} catch (Exception e) {
			throw e;

		} finally {
			try {
				wb.write(fileOut);
				fileOut.flush();
				fileOut.close();
				wb.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	public Map executeDisplay(String userName,String rand) {
		// username = ServletActionContext.getRequest().getParameter("username");
	
		Map map = new HashMap();
		
		this.username = userName;
		profileRoot = UIConstants.WEBROOT + File.separator + this.username + File.separator;

		map.put("success","success");
		map.put("username",userName);
		map.put("profileRoot",profileRoot);
		
		return map;
	}

	public List executeTest(String username, HttpServletRequest request) {
		
		List list =  new ArrayList();
		logMessage = "";
		
		HttpSession session=request.getSession(); 
		
		// log.info("================Testing initiated=================");
		// HttpSession session=ServletActionContext.getRequest().getSession(false);
		IJunitExecuter ex = new IJunitExecuter();
		String ls = System.getProperty("line.separator");
		StringBuffer sb = new StringBuffer();
		System.out.println("================Testing initiated=================");
		sb.append(logMessage + "================Testing initiated=================" + ls);
		PrintWriter writer = null;
		PrintWriter csvWriter = null;
		JUnitCore junit = new JUnitCore();
		boolean hasFailure = false;
		boolean hasRerunFailure = false;
		Calendar now = Calendar.getInstance();
		String yymmddhhmmss = new Integer(now.get(Calendar.YEAR)).toString()
				+ new Integer(now.get(Calendar.MONTH) + 1).toString()
				+ new Integer(now.get(Calendar.DAY_OF_MONTH)).toString()
				+ new Integer(now.get(Calendar.HOUR)).toString() + new Integer(now.get(Calendar.MINUTE)).toString()
				+ new Integer(now.get(Calendar.SECOND)).toString();

		try {
			String csvHeader = "testCase,description,pattern,"
					+ "sourceProtocol,sourceFormat,targetProtocol,targetFormat,"
					+ "securityInfo,headerInfo,endpoint,legacyEndPont,sourceInfo,input,"
					+ "expectedOutput,actualOutput,passed,executedAt,rerun,reason";
			String source;
			String inputFileLocation;
			String configFileLocation;
			List<TestCaseDTO> testCases = new ArrayList<TestCaseDTO>();
			List<String> failedCases = new ArrayList<String>();
			List<TestCaseDTO> failedTestCases = new ArrayList<TestCaseDTO>();
			List<TestCaseDTO> testCaseReports = new ArrayList<TestCaseDTO>();
			List<String> testCaseXMLReports = new ArrayList<String>();
			TestConfDTO confDTO = null;

			source = UIConstants.WEBROOT + File.separator + username + File.separator;

			System.out.println("Root directory -> " + source);
			quickReportName = "QuickReport.txt";
			quickReportPath = source + "QuickReport.txt";
			csvReportName = "Report" + yymmddhhmmss + ".csv";
			csvReportPath = source + "Report" + yymmddhhmmss + ".csv";
			xmlReportName = "Report.xml";
			xmlReportPath = source + "Report.xml";
			writer = new PrintWriter(source + "QuickReport.txt", "UTF-8");
			csvWriter = new PrintWriter(source + "Report" + yymmddhhmmss + ".csv", "UTF-8");
			csvWriter.println(csvHeader);

			inputFileLocation = source + IJunitConstants.DEFAULT_TEST_INPUT_EXCEL;
			configFileLocation = source + IJunitConstants.DEFAULT_TEST_CONF_PROPERTIES;
			System.out.println("Loading configFile -> " + configFileLocation);
			confDTO = ex.loadTestConf(configFileLocation);
			System.out.println("Loading TestCaseInputFile -> " + inputFileLocation);
			testCases = ExcelUtil.readExcel(inputFileLocation);
			int noOfTests = testCases.size();
			System.out.println("Total Test cases to be executed -> " + (noOfTests - 1));
			sb.append("Total Test cases to be executed -> " + (noOfTests - 1) + ls);
			for (int testIndex = 1; testIndex < noOfTests; testIndex++) {
				TestCaseDTO testCase = testCases.get(testIndex);
				if (!IJunitConstants.VALUE_INACTIVE.equalsIgnoreCase(testCase.getIsActive())) {
					System.out.println("==Intialising Test case -> " + testCase.getTestCase());
					testCase.setSource(source);
					ex.setDefault(testCase, source);
					// IJunitTestCase.testCase = testCase;
					// Result result =
					// junit.run(TestCaseFactory.getTestClass(testCase.getPattern(),testCase));
					// Result result=null;
					TestCase tc = TestCaseFactory.getTestClass(testCase.getPattern(), testCase);
					List<String> testCaseList = new ArrayList<String>(Arrays.asList(testCase.toString().split(",")));
					System.out.println(" Test Case Details Befor running testcase: " + testCaseList.toString());
					if (testCaseList.get(3).equals("HTTPGET")) {
						File inputFile = new File(testCaseList.get(11));
						System.out.println(testCaseList.get(11));
						if (!(inputFile.exists())) {
							inputFile.createNewFile();
						}
					}

					TestResult tr = tc.run();
					System.out.println(" Test Case Results after running testcase: " + tr.toString());
					System.out.println(testCase.getTestCase() + " : " + testCase.translateResult(tr.wasSuccessful()));
					System.out.println("Test case result for : " + testCase.getTestCase() + " result "
							+ testCase.translateResult(tr.wasSuccessful()));
					testCase.setPassed(tr.wasSuccessful());
					testCase.setExecutedAt(System.currentTimeMillis());
					writer.println("Test Case : " + testCase.getTestCase() + "| Result : "
							+ testCase.translateResult(tr.wasSuccessful()));
					if (!tr.wasSuccessful()) {
						// System.out.println("Reason for failure : "+tr.getFailures());
						if (tr.failures().hasMoreElements()) {
							System.out.println(" Failure reason " + tr.failures().nextElement());
							String reason = tr.failures().nextElement().toString().replaceAll("\\r\\n|\\r|\\n", " ");
							writer.println("Failure :" + tr.failures().nextElement().toString());
							String exMessage = tr.failures().nextElement().exceptionMessage()
									.replaceAll("\\r\\n|\\r|\\n", " ");
							exMessage = exMessage.substring(0, exMessage.indexOf(" "));
							testCase.setReason(reason);
							testCase.setExceptionName(exMessage);
							testCase.setDescription(reason);
						} else {
							System.out.println("no failure info");
						}

						// System.out.println(" error "+tr.errors());
						if (tr.errors().hasMoreElements()) {
							System.out.println(" Failure reason " + tr.errors().nextElement());
							String reason = tr.errors().nextElement().toString().replaceAll("\\r\\n|\\r|\\n", " ");
							writer.println("Failure :" + tr.errors().nextElement().toString());
							String exMessage = tr.errors().nextElement().getClass().getName();
							// exMessage = exMessage.substring(0,exMessage.indexOf(" "));
							// System.out.println(" exMessage "+exMessage);
							testCase.setReason(reason);
							testCase.setExceptionName(exMessage);
							testCase.setDescription(reason);
						} else {
							System.out.println("No error info");
						}

						/*
						 * if(tr.failureCount()>0){ if(tr..get(0).getException()!=null){
						 * testCase.setExceptionName(result.getFailures().get(0).getException().getClass
						 * ().toString()); }
						 * testCase.setErrorDescription(result.getFailures().get(0).getDescription().
						 * toString()); }
						 */
						hasFailure = true;
						// failedCases.add(testCase.getTestCase());
						failedTestCases.add(testCase);
						if (!IJunitConstants.VALUE_TRUE.equalsIgnoreCase(confDTO.getRetry())) {
							failedCases.add(testCase.getTestCase());
						}

					}
					csvWriter.println(testCase.toString());
					testCaseReports.add(new TestCaseDTO(testCase));
					if (tr.wasSuccessful() || (!tr.wasSuccessful()
							&& !IJunitConstants.VALUE_TRUE.equalsIgnoreCase(confDTO.getRetry()))) {
						testCaseXMLReports.add(new TestCaseDTO(testCase).toXML());
					}
					System.out.println("==Completed Test Case : " + testCase.getTestCase());
				}
			}

			// rerun failed test cases
			if (IJunitConstants.VALUE_TRUE.equalsIgnoreCase(confDTO.getRetry()) && hasFailure) {
				System.out.println("==Rerunning failed test cases");
				int failedCasesSize = failedTestCases.size();
				for (int testIndex = 0; testIndex < failedCasesSize; testIndex++) {
					TestCaseDTO testCase = failedTestCases.get(testIndex);
					System.out.println("==Rerunning Test case -> " + testCase.getTestCase());
					testCase.setRerun(true);
					// IJunitTestCase.testCase = testCase;
					// Result result =
					// junit.run(TestCaseFactory.getTestClass(testCase.getPattern()));
					// Result result=null;
					TestCase tc = TestCaseFactory.getTestClass(testCase.getPattern(), testCase);
					TestResult tr = tc.run();
					System.out.println(
							testCase.getTestCase() + " Rerun : " + testCase.translateResult(tr.wasSuccessful()));
					System.out.println("Rerun Test case result for : " + testCase.getTestCase() + " result "
							+ testCase.translateResult(tr.wasSuccessful()));
					testCase.setPassed(tr.wasSuccessful());
					testCase.setExecutedAt(System.currentTimeMillis());
					writer.println("Rerun Test Case : " + testCase.getTestCase() + "| Result : "
							+ testCase.translateResult(tr.wasSuccessful()));
					if (!tr.wasSuccessful()) {
						if (tr.failures().hasMoreElements()) {
							System.out.println(" Failure reason " + tr.failures().nextElement());
							String reason = tr.failures().nextElement().toString().replaceAll("\\r\\n|\\r|\\n", " ");
							writer.println("Failure :" + tr.failures().nextElement().toString());
							String exMessage = tr.failures().nextElement().exceptionMessage()
									.replaceAll("\\r\\n|\\r|\\n", " ");
							exMessage = exMessage.substring(0, exMessage.indexOf(" "));
							testCase.setReason(reason);
							testCase.setExceptionName(exMessage);
							testCase.setDescription(reason);
						} else {
							System.out.println("no failure info");
						}

						// System.out.println(" error "+tr.errors());
						if (tr.errors().hasMoreElements()) {
							System.out.println(" Failure reason " + tr.errors().nextElement());
							String reason = tr.errors().nextElement().toString().replaceAll("\\r\\n|\\r|\\n", " ");
							writer.println("Failure :" + tr.errors().nextElement().toString());
							String exMessage = tr.errors().nextElement().getClass().getName();
							// exMessage = exMessage.substring(0,exMessage.indexOf(" "));
							// System.out.println(" exMessage "+exMessage);
							testCase.setReason(reason);
							testCase.setExceptionName(exMessage);
							testCase.setDescription(reason);
						} else {
							System.out.println("No error info");
						}
						hasRerunFailure = true;
						failedCases.add(testCase.getTestCase());
					}
					csvWriter.println(testCase.toString());
					testCaseReports.add(new TestCaseDTO(testCase));
					testCaseXMLReports.add(new TestCaseDTO(testCase).toXML());
					System.out.println("==Completed Test Case rerun : " + testCase.getTestCase());
				}

			}
			System.out.println("Creating XMLReport");
			sb.append("Creating XMLReport" + ls);
			ex.createXMLReport(testCaseXMLReports, source, failedCases.size(), yymmddhhmmss);
			if (IJunitConstants.VALUE_TRUE.equalsIgnoreCase(confDTO.getDbReporting())) {
				DBUtil.reportToDB(confDTO, testCaseReports);
			}

			session.setAttribute("currentReport", testCaseReports);
			session.setAttribute("xmlReportName", xmlReportName);
			session.setAttribute("quickReportName", quickReportName);
			session.setAttribute("csvReportName", csvReportName);
			
		
			// session.setAttribute("currentReport",testCaseReports);
			if ((hasRerunFailure && IJunitConstants.VALUE_TRUE.equalsIgnoreCase(confDTO.getRetry()))) {
				// throw new Exception("One or more test cases have failed with rerun attempt.
				// Please check report. Falied Test cases are "+failedCases.toString());
				sb.append(
						"One or more test cases have failed with rerun attempt. Please check report. Falied Test cases are "
								+ failedCases.toString() + ls);
			} else if (hasFailure && !IJunitConstants.VALUE_TRUE.equalsIgnoreCase(confDTO.getRetry())) {
				// throw new Exception("One or more test cases have failed. Please check report.
				// Falied Test cases are "+failedCases.toString());
				sb.append("One or more test cases have failed. Please check report. Falied Test cases are "
						+ failedCases.toString() + ls);
			}
			logMessage = sb.toString();
			
			list.add("success");
			list.add(logMessage);
			list.add(csvReportName);
			
			return list;

		} catch (Exception e) {
			logMessage = sb.toString();
			// addActionError(e.getMessage());
			
			list.add("error");
			list.add(logMessage);
			list.add(csvReportName);
			
			return list;
			
		} finally {

			if (writer != null) {
				writer.close();
			}
			if (csvWriter != null) {
				csvWriter.close();
			}

		}

	}

	public String downloadReport(String reportPath) {
		try {

			String path = reportPath; // ServletActionContext.getRequest().getParameter("reportPath");
			reportInputStream = new FileInputStream(path);
			return "success";
		} catch (Exception e) {
			e.printStackTrace();
			// addActionError("System error "+e.getMessage());
			return "error";
		}
	}

	public List downloadReportByName(String username, String downloadReportName) {
		
		List list = new ArrayList();
		
		try {
			
			this.username = username;
			FileInputStream fileReportInputStream;
			/*
			 * String name=ServletActionContext.getRequest().getParameter("reportName");
			 * if(this.username==null||this.username.trim().length()==0){
			 * System.out.println("Username not obtained");
			 * this.username=ServletActionContext.getRequest().getParameter("username");
			 * System.out.println("Username obtained from query"+username); }
			 */
			//reportInputStream = new FileInputStream(UIConstants.WEBROOT + File.separator + this.username + File.separator + downloadReportName);
			
			fileReportInputStream = new FileInputStream(UIConstants.WEBROOT + File.separator + this.username + File.separator + downloadReportName);
			
			
			list.add("success");
			list.add(fileReportInputStream);
			
			return list;
			
		} catch (Exception e) {
			e.printStackTrace();
			// addActionError("System error "+e.getMessage());
			list.add("error");
			
			return list;
		}
	}

	public List displayReportPage(String Username, String rand) {
		
		List list = new ArrayList();
		List reportListTemp = new ArrayList();
		
		try {
			this.username = Username; // ServletActionContext.getRequest().getParameter("username");
			File rootDir = new File(UIConstants.WEBROOT + File.separator + this.username + File.separator);
			String fileList[] = rootDir.list();
			for (String fileName : fileList) {
				// System.out.println(" name : "+fileName);
				if (fileName.endsWith(".csv")) {
					// System.out.println(" csv : "+fileName);
					reportListTemp.add(fileName);
				}
			}
			
			list.add("success");
			list.add(reportListTemp);
			return list;
		} catch (Exception e) {
			e.printStackTrace();
			// addActionError("System error "+e.getMessage());
			
			list.add("error");
			
			return list;
		}
	}

	public List currentReport(HttpServletRequest request) {
		
		List list = new ArrayList();
		
		try {
			// HttpSession session=request
			HttpSession session=request.getSession(false); 
			testReports = (List<TestCaseDTO>) session.getAttribute("currentReport");
			xmlReportName = (String) session.getAttribute("xmlReportName");
			quickReportName = (String) session.getAttribute("quickReportName");
			csvReportName = (String) session.getAttribute("csvReportName");
			
			list.add("success");
			list.add(testCases);
			list.add(xmlReportName);
			list.add(quickReportName);
			list.add(csvReportName);
			
		} catch (Exception e) {
			e.printStackTrace();
			// addActionError("System error "+e.getMessage());
			list.add("error");
			list.add("System error "+e.getMessage());
			
		}
		
		return list;
	}

	public List showInfo(String testName, String type,String count,String rand, HttpServletRequest request) {
		
		List list = new ArrayList();
		
		try {
			System.out.println("Show Info Invoked");

			HttpSession session=request.getSession(false);
			testReports = (List<TestCaseDTO>) session.getAttribute("currentReport");
			TestCaseDTO testCase = testReports.get(Integer.parseInt(count));
			if ("desc".equalsIgnoreCase(type)) {
				infoContent = testCase.getDescription();
			} else {
				infoContent = testCase.getReason();
			}
			System.out.println("Retruning success");

			list.add("success");
			list.add(infoContent);
		} catch (Exception e) {
			e.printStackTrace();
			// addActionError("System error "+e.getMessage());
			list.add("error");
			list.add("System error "+e.getMessage());
		}
		
		return list;
	}
}
