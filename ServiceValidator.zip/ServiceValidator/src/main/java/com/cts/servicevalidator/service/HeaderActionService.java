package com.cts.servicevalidator.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

//import org.apache.struts2.ServletActionContext;
//import org.apache.struts2.ServletActionContext;
import org.springframework.stereotype.Service;

import com.cts.servicevalidator.contants.*;
import com.cts.servicevalidator.model.HeaderActionModel;
import com.cts.integration.util.FileUtil;

@Service
public class HeaderActionService {
	
	String confContent;
	String username;
	String testName;
	String targetPath;
	File headerFile;
	
	public String getConfContent() {
		return confContent;
	}
	public void setConfContent(String confContent) {
		this.confContent = confContent;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getTestName() {
		return testName;
	}
	public void setTestName(String testName) {
		this.testName = testName;
	}
	public String getTargetPath() {
		return targetPath;
	}
	public void setTargetPath(String targetPath) {
		this.targetPath = targetPath;
	}
	public File getHeaderFile() {
		return headerFile;
	}
	public void setHeaderFile(File headerFile) {
		this.headerFile = headerFile;
	}
	
	
	HeaderActionModel headerActionModel = new HeaderActionModel();

	public List loadHeaderProperties(String username ,String testName, String rand) {
		
		List list = new ArrayList();
		
		FileInputStream fis = null;
		
		 try {
			
			//username = ServletActionContext.getRequest().getParameter("username");
			//testName = ServletActionContext.getRequest().getParameter("testName");
			
			
			targetPath=UIConstants.WEBROOT+File.separator+username+File.separator+testName+File.separator+testName+"Header.properties";
			String samplePath=UIConstants.WEBROOT+File.separator+"Header.properties";
			System.out.println("path --"+targetPath);
			File sourcePropertiesFile = new File(targetPath);
			if(!sourcePropertiesFile.exists()){
				sourcePropertiesFile = new File(samplePath);
				confContent=new String(Files.readAllBytes(Paths.get(samplePath)),Charset.defaultCharset());
				//confContent= FileUtil.readFileAsString(samplePath);
			}else{
				confContent=new String(Files.readAllBytes(Paths.get(targetPath)),Charset.defaultCharset());
				//confContent= FileUtil.readFileAsString(targetPath);
			}
			
			//confContent=protocolProperties.toString();
	    	list.add("success");
	    	list.add(targetPath);
	    	list.add(confContent);
			
		} catch (Exception e) {
			e.printStackTrace();
			list.add("error");
			list.add("System error "+e.getMessage());
		}finally{
			try {
				if(fis!=null){
					
						fis.close();
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		 
		return list;
	}
	
	public List saveHeaderProperties(String username, String testName, String targetPath, String confContent) {
		
		List list = new ArrayList();
		
		FileInputStream fis = null; 
		try {
			
			
			FileUtil.writeToFile(targetPath, confContent);
			
			String targetDir = UIConstants.WEBROOT+File.separator+username+File.separator+testName+File.separator;
			String headerFileName=null;
			System.out.println("Header "+headerFile);
			if(headerFile!=null){
				fis=new FileInputStream(new File(targetPath));
				Properties securityProperties= new Properties();
				securityProperties.load(fis);
				
				headerFileName=securityProperties.getProperty("HEADER");
				System.out.println("certFileName "+headerFileName);
				File targetFile = new File(targetDir+headerFileName);
				org.apache.commons.io.FileUtils.copyFile(headerFile, targetFile);
			}
			
			list.add("success");
			
		} catch (Exception e) {
			e.printStackTrace();
			list.add("error");
			list.add("System error"+e.getMessage());
		}finally{
			try {
				if(fis!=null){
					fis.close();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		
		return list;
	}
	
	public List reloadHeaderProperties(String username,String testName) {
		
		List list = new ArrayList();
		
		 try {
			
			 String samplePath=UIConstants.WEBROOT+File.separator+testName+File.separator+testName+File.separator+testName+"Header.properties";
			 System.out.println(" reloading from "+samplePath);
			 confContent=new String(Files.readAllBytes(Paths.get(samplePath)),Charset.defaultCharset());
			
			 list.add("success");
			 list.add(confContent);
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			//addActionError("System error"+e.getMessage());
			list.add("error");
			list.add("System error"+e.getMessage());
		}finally{
			
			
		}
		 return list;
	}
	
	
}
