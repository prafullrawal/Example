package com.cts.servicevalidator.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Properties;

import org.apache.struts2.ServletActionContext;
import org.springframework.stereotype.Service;

import com.cts.servicevalidator.contants.*;
import com.cts.integration.util.FileUtil;

@Service
public class HeaderActionService {

	public void loadHeaderProperties() {
		FileInputStream fis = null;
		
		 try {
			
			
			username = ServletActionContext.getRequest().getParameter("username");
			testName = ServletActionContext.getRequest().getParameter("testName");
			
			
			targetPath=UIConstants.WEBROOT+File.separator+username+File.separator+testName+File.separator+testName+"Header.properties";
			String samplePath=UIConstants.WEBROOT+File.separator+"Header.properties";
			System.out.println("path --"+targetPath);
			File sourcePropertiesFile = new File(targetPath);
			if(!sourcePropertiesFile.exists()){
				sourcePropertiesFile = new File(samplePath);
				confContent=new String(Files.readAllBytes(Paths.get(samplePath)),Charset.defaultCharset());
				//confContent= FileUtil.readFileAsString(samplePath);
			}else{
				confContent=new String(Files.readAllBytes(Paths.get(targetPath)),Charset.defaultCharset());
				//confContent= FileUtil.readFileAsString(targetPath);
			}
			
			//confContent=protocolProperties.toString();
	    	return "success";
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			addActionError("System error "+e.getMessage());
			return "error";
		}finally{
			try {
				if(fis!=null){
					
						fis.close();
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		
	}

	public void saveHeaderProperties() {
		
		FileInputStream fis = null; 
		try {
			
			
			FileUtil.writeToFile(targetPath, confContent);
			
			String targetDir = UIConstants.WEBROOT+File.separator+username+File.separator+testName+File.separator;
			String headerFileName=null;
			System.out.println("Header "+headerFile);
			if(headerFile!=null){
				fis=new FileInputStream(new File(targetPath));
				Properties securityProperties= new Properties();
				securityProperties.load(fis);
				
				headerFileName=securityProperties.getProperty("HEADER");
				System.out.println("certFileName "+headerFileName);
				File targetFile = new File(targetDir+headerFileName);
				org.apache.commons.io.FileUtils.copyFile(headerFile, targetFile);
			}
			
	    	return "success";
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			addActionError("System error"+e.getMessage());
			return "error";
		}finally{
			try {
				if(fis!=null){
					fis.close();
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		
	}

	public void reloadHeaderProperties() {
		
		try {
			
			 String samplePath=UIConstants.WEBROOT+File.separator+"Header.properties";
			 System.out.println(" reloading from "+samplePath);
			confContent=new String(Files.readAllBytes(Paths.get(samplePath)),Charset.defaultCharset());
			
	    	return "success";
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			addActionError("System error"+e.getMessage());
			return "error";
		}finally{
			
			
		}
		
	}

}
