package com.cts.servicevalidator.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Properties;

//import org.apache.struts2.ServletActionContext;
import org.springframework.stereotype.Service;

import com.cts.servicevalidator.contants.*;
import com.cts.servicevalidator.model.HeaderActionModel;
import com.cts.integration.util.FileUtil;

@Service
public class HeaderActionService {
	
	
	HeaderActionModel headerActionModel = new HeaderActionModel();

	public String loadHeaderProperties(String username,String testName) {
		FileInputStream fis = null;
		
		 try {
			
			
//			username = ServletActionContext.getRequest().getParameter("username");
//			testName = ServletActionContext.getRequest().getParameter("testName");
			
			
			 headerActionModel.setTargetPath(UIConstants.WEBROOT+File.separator+username+File.separator+testName+File.separator+testName+"Header.properties");
			String samplePath=UIConstants.WEBROOT+File.separator+"Header.properties";
			System.out.println("path --"+headerActionModel.getTargetPath());
			File sourcePropertiesFile = new File(headerActionModel.getTargetPath());
			if(!sourcePropertiesFile.exists()){
				sourcePropertiesFile = new File(samplePath);
				headerActionModel.setConfContent(new String(Files.readAllBytes(Paths.get(samplePath)),Charset.defaultCharset()));
				//confContent= FileUtil.readFileAsString(samplePath);
			}else{
				
				headerActionModel.setConfContent(new String(Files.readAllBytes(Paths.get(samplePath)),Charset.defaultCharset()));
				//confContent= FileUtil.readFileAsString(targetPath);
			}
			
			//confContent=protocolProperties.toString();
	    	return "success";
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			//addActionError("System error "+e.getMessage());
			return "error";
		}finally{
			try {
				if(fis!=null){
					
						fis.close();
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		
	}

	public String saveHeaderProperties() {
		
		FileInputStream fis = null; 
		try {
			
			
			FileUtil.writeToFile(headerActionModel.getTargetPath(), headerActionModel.getConfContent());
			
			String targetDir = UIConstants.WEBROOT+File.separator+headerActionModel.getUsername()+File.separator+headerActionModel.getTestName()+File.separator;
			String headerFileName=null;
			System.out.println("Header "+headerActionModel.getHeaderFile());
			if(headerActionModel.getHeaderFile()!=null){
				fis=new FileInputStream(new File(headerActionModel.getTargetPath()));
				Properties securityProperties= new Properties();
				securityProperties.load(fis);
				
				headerFileName=securityProperties.getProperty("HEADER");
				System.out.println("certFileName "+headerFileName);
				File targetFile = new File(targetDir+headerFileName);
				org.apache.commons.io.FileUtils.copyFile(headerActionModel.getHeaderFile(), targetFile);
			}
			
	    	return "success";
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			//addActionError("System error"+e.getMessage());
			return "error";
		}finally{
			try {
				if(fis!=null){
					fis.close();
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		
	}

	public String reloadHeaderProperties() {
		
		try {
			
		 String samplePath=UIConstants.WEBROOT+File.separator+"Header.properties";
		 System.out.println(" reloading from "+samplePath);
		 headerActionModel.setConfContent(new String(Files.readAllBytes(Paths.get(samplePath)),Charset.defaultCharset()));
			
	    	return "success";
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			//addActionError("System error"+e.getMessage());
			return "error";
		}finally{
			
			
		}
		
	}

}
